"""FastAPI backend exposing the password-audit pipeline to the web UI.

Run:  python -m osintpwd web        (or)   uvicorn osintpwd.web.app:app
Then open http://localhost:7020

The dashboard uses persisted local discovery jobs for public-source retrieval.
Legacy synchronous discovery endpoints remain available for integrations.
"""

from __future__ import annotations

import io
import os
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel, Field, HttpUrl, field_validator

from ..env import load_env
from ..evaluator import evaluate_password

load_env()  # so SEARXNG_URL / IG_USERNAME work when run via `uvicorn` directly
from ..generator import generate_wordlist
from ..models import Config, Profile

@asynccontextmanager
async def lifespan(app):
    from .discovery_jobs import job_store
    store = job_store()
    store.start()
    yield
    store.close()


app = FastAPI(title="Password Audit Dashboard", lifespan=lifespan)

_STATIC = os.path.join(os.path.dirname(__file__), "static")
_PROJECT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_MODELS_DIR = os.path.join(_PROJECT, "models")

# Active behavioural password model (set after the user trains one).
_active_model_path: str | None = None
_active_model_meta: dict = {}


# --------------------------------------------------------------------------- #
# request models
# --------------------------------------------------------------------------- #
class ProfileIn(BaseModel):
    first_name: str = ""
    last_name: str = ""
    nickname: str = ""
    birth_year: int | None = None
    city: str = ""
    country: str = ""
    employer: str = ""
    job_title: str = ""
    spouse: str = ""
    children: list[str] = []
    pets: list[str] = []
    interests: list[str] = []
    custom: list[str] = []
    significant_years: list[int] = []
    phone_digits: str = ""

    def to_profile(self) -> Profile:
        return Profile(**self.model_dump())


class CheckIn(BaseModel):
    password: str
    profile: ProfileIn


class DiscoverIn(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    city: str = Field(default="", max_length=300)
    country: str = Field(default="", max_length=300)
    employer: str = Field(default="", max_length=300)
    job_title: str = Field(default="", max_length=300)
    school: str = Field(default="", max_length=300)
    search_mode: Literal['auto', 'keyless'] | None = None
    platforms: list[str] | None = Field(default=None, min_length=1, max_length=18)

    @field_validator('platforms')
    @classmethod
    def validate_platforms(cls, value):
        from ..discovery.candidates import PLATFORMS
        if value is not None:
            if any(platform not in PLATFORMS for platform in value):
                raise ValueError('Unsupported platform')
            return list(dict.fromkeys(value))
        return value

    @field_validator('name')
    @classmethod
    def normalize_name(cls, value):
        value = ' '.join(value.split())
        if len(value) < 2:
            raise ValueError('Enter a name with at least two characters')
        return value


class EnrichIn(BaseModel):
    profile: ProfileIn
    text: str = ""


class WordlistIn(BaseModel):
    profile: ProfileIn


class TrainIn(BaseModel):
    passwords: list[str] = []
    epochs: int = 40


class CandidateIn(BaseModel):
    platform: str = ""
    url: str = ""
    handle: str = ""


class AnalyzeIn(BaseModel):
    name: str = ""
    candidates: list[CandidateIn] = []


# --------------------------------------------------------------------------- #
# routes
# --------------------------------------------------------------------------- #
@app.get("/", response_class=HTMLResponse)
def index() -> str:
    with open(os.path.join(_STATIC, "index.html"), encoding="utf-8") as fh:
        return fh.read()


def _score_with_model(password: str) -> dict | None:
    """Neural behavioural-model score for a password, if a model is active."""
    if not _active_model_path:
        return None
    try:
        from ..ml.pwmodel import PasswordScorer
        scorer = PasswordScorer(_active_model_path)
        s = scorer.score(password)
        if s is None:
            return None
        return {"avg_neg_logp": s.avg_neg_logp, "bits": s.bits,
                "guesses": s.guesses}
    except Exception:  # noqa: BLE001
        return None


@app.post("/api/check")
def api_check(body: CheckIn) -> dict:
    v = evaluate_password(body.password, body.profile.to_profile())
    return {
        "allowed": v.allowed,
        "score": v.score,
        "reasons": v.reasons,
        "matched_tokens": v.matched_tokens,
        "model": _score_with_model(body.password),
        "model_active": bool(_active_model_path),
    }


@app.get("/api/pwmodel/status")
def api_pwmodel_status() -> dict:
    return {"active": bool(_active_model_path), "meta": _active_model_meta}


@app.post("/api/pwmodel/upload")
async def api_pwmodel_upload(file: UploadFile = File(...)) -> dict:
    """Parse an uploaded CSV/TXT/XLSX/DOCX into a password list for review."""
    from ..ml.pwfile import parse_passwords
    data = await file.read()
    try:
        pwds = parse_passwords(file.filename or "", data)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    return {"ok": True, "count": len(pwds), "passwords": pwds[:5000],
            "filename": file.filename}


@app.post("/api/pwmodel/train")
def api_pwmodel_train(body: TrainIn) -> dict:
    global _active_model_path, _active_model_meta
    from ..ml.pwmodel import _DEFAULT_PATH
    from ..ml.pwtrain import fine_tune

    pwds = [p.strip() for p in body.passwords if p and p.strip()]
    if len(pwds) < 3:
        return {"ok": False, "error": "need at least 3 passwords"}
    if not os.path.exists(_DEFAULT_PATH):
        return {"ok": False, "error": "base model personal_adapted_poe_mtl.pth not found"}

    os.makedirs(_MODELS_DIR, exist_ok=True)
    out = os.path.join(_MODELS_DIR, "personal_web.pth")
    epochs = max(5, min(body.epochs, 80))
    try:
        h = fine_tune(pwds, _DEFAULT_PATH, out, epochs=epochs)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    _active_model_path = out
    _active_model_meta = {"n": h["n"], "epochs": epochs,
                          "loss_start": h["loss"][0], "loss_end": h["loss"][-1],
                          "trainable": h["trainable"]}
    return {"ok": True, "meta": _active_model_meta, "loss_curve": h["loss"]}


_RANK_CAP = 40000   # how many candidates the neural model re-ranks (CPU-bound)


def _rank_words(words: list[str]) -> tuple[list[str], bool]:
    """If a behavioural model is active, sort the most-likely candidates first.

    Ranks up to _RANK_CAP words by the model's neg-log-prob (ascending =
    most-in-style first); any remainder is appended unranked. Returns
    (ordered_words, ranked?).
    """
    if not _active_model_path:
        return words, False
    try:
        from ..ml.pwmodel import PasswordScorer
        scorer = PasswordScorer(_active_model_path)
        if not scorer.available():
            return words, False
        head, tail = words[:_RANK_CAP], words[_RANK_CAP:]
        scores = scorer.score_batch(head)
        order = sorted(range(len(head)),
                       key=lambda i: (scores[i] is None, scores[i] if scores[i] is not None else 1e9))
        ranked = [head[i] for i in order]
        return ranked + tail, True
    except Exception:  # noqa: BLE001
        return words, False


@app.post("/api/wordlist")
def api_wordlist(body: WordlistIn) -> dict:
    words = generate_wordlist(body.profile.to_profile(), Config())
    words, ranked = _rank_words(words)
    return {"count": len(words), "preview": words[:200], "ranked": ranked,
            "rank_cap": _RANK_CAP if ranked else 0}


@app.post("/api/wordlist/download")
def api_wordlist_download(body: WordlistIn) -> StreamingResponse:
    words = generate_wordlist(body.profile.to_profile(), Config())
    words, _ = _rank_words(words)
    buf = io.BytesIO(("\n".join(words) + "\n").encode("utf-8"))
    return StreamingResponse(
        buf, media_type="text/plain",
        headers={"Content-Disposition": "attachment; filename=wordlist.txt"},
    )


@app.post("/api/enrich")
def api_enrich(body: EnrichIn) -> dict:
    from ..ml import enrich_profile
    profile = body.profile.to_profile()
    res = enrich_profile(profile, text=body.text, use_spacy=True)
    p = res.profile
    return {
        "profile": {
            "first_name": p.first_name, "last_name": p.last_name,
            "city": p.city, "employer": p.employer,
            "interests": p.interests, "custom": p.custom,
            "significant_years": p.significant_years,
        },
        "found": {
            "interests": res.interests,
            "proper_nouns": res.proper_nouns,
            "years": res.years,
        },
        "notes": res.notes,
    }


def _discovery_response(result) -> dict:
    from dataclasses import asdict
    from ..discovery.pipeline import candidates_to_profile
    # Discovery suggestions are unconfirmed. Only explicit selection in /analyze
    # should populate personal tokens from third-party profiles.
    profile = candidates_to_profile(result.query_name, [], result.hints)
    candidates = [c for c in result.candidates if c.name_match or c.confirmed]
    uncertain = [c for c in result.candidates if not (c.name_match or c.confirmed)]
    stats = {**result.stats,
             "retrieved_candidate_count": len(result.candidates),
             "candidate_count": len(candidates),
             "uncertain_count": len(uncertain),
             "linkedin_candidates": sum(c.platform == "linkedin" for c in candidates),
             "linkedin_name_matches": sum(c.platform == "linkedin" and c.name_match
                                          for c in candidates)}
    return {
        "candidates": [asdict(c) for c in candidates],
        "uncertain_candidates": [asdict(c) for c in uncertain],
        "related_people": result.related_people,
        "related_accounts": [asdict(c) for c in result.related_accounts],
        "related_searched": result.related_searched,
        "related_evidence": result.related_evidence,
        "web_info": result.web_info,
        "stats": stats,
        "excluded_profile_urls": result.excluded_profile_urls,
        "profile": {"first_name": profile.first_name, "last_name": profile.last_name,
                    "city": profile.city, "employer": profile.employer,
                    "interests": [], "custom": []},
        "notes": result.errors,
    }


def _discovery_hints(body: DiscoverIn) -> dict:
    return {key: getattr(body, key) for key in
            ("city", "country", "employer", "job_title", "school") if getattr(body, key)}


@app.post("/api/discover")
def api_discover(body: DiscoverIn) -> dict:
    from ..discovery import discover
    from ..discovery.config import discovery_query_budget
    options = {'search_mode': body.search_mode or 'keyless'}
    if body.platforms is not None:
        options['platforms'] = tuple(body.platforms)
    return _discovery_response(discover(body.name, _discovery_hints(body), username_scan=True,
                                        username_provider='maigret', enrich_profiles=4,
                                        query_budget=discovery_query_budget(), **options))


@app.post('/api/discovery-jobs', status_code=202)
def create_discovery_job(body: DiscoverIn) -> dict:
    from .discovery_jobs import job_store, QueueFull
    from ..discovery.config import discovery_query_budget
    store = job_store()
    try:
        job = store.submit({**body.model_dump(), 'search_mode': 'keyless',
                            'query_budget': discovery_query_budget()})
    except QueueFull as exc:
        raise HTTPException(429, detail='В очереди уже три анализа. Дождитесь завершения.') from exc
    store.start()
    return job


@app.get('/api/discovery-jobs/{job_id}')
def get_discovery_job(job_id: str) -> dict:
    from .discovery_jobs import job_store
    job = job_store().get(job_id)
    if job is None:
        raise HTTPException(404, detail='Анализ не найден или срок хранения истёк.')
    return job


class WebSourceIn(BaseModel):
    url: HttpUrl
    title: str = Field(default='', max_length=4000)
    snippet: str = Field(default='', max_length=4000)
    excerpt: str = Field(default='', max_length=24000)


class RelatedIn(DiscoverIn):
    web_info: list[WebSourceIn] = Field(default_factory=list, max_length=25)


@app.post("/api/discover/related")
def api_discover_related(body: RelatedIn) -> dict:
    from ..discovery.pipeline import discover_related
    options = {'search_mode': body.search_mode} if body.search_mode is not None else {}
    return _discovery_response(discover_related(body.name, _discovery_hints(body),
                              [w.model_dump(mode='json') for w in body.web_info], **options))


class ExpandIn(BaseModel):
    handle: str = ""
    excluded_profile_urls: list[HttpUrl] = Field(default_factory=list, max_length=2000)


@app.post("/api/expand")
def api_expand(body: ExpandIn) -> dict:
    """Expand a CONFIRMED handle into the person's accounts on other networks."""
    from ..discovery.username import check_username, valid_handle
    from ..discovery.candidates import canonical_profile_url
    h = valid_handle(body.handle)
    if not h:
        return {"ok": False, "error": "некорректный хэндл для раскрутки", "accounts": []}
    hits = check_username(h)
    excluded_by_site = {
        site: {canonical_profile_url(site, str(url)) for url in body.excluded_profile_urls}
        for site in {hit["site"] for hit in hits}
    }
    hits = [{**hit, "url": canonical_profile_url(hit["site"], hit["url"])} for hit in hits
            if canonical_profile_url(hit["site"], hit["url"]) not in excluded_by_site[hit["site"]]]
    return {"ok": True, "handle": h, "count": len(hits), "accounts": hits}


class ReportIn(BaseModel):
    name: str = ""
    tokens: list[str] = []
    candidates: list[dict] = []
    profile: dict = {}


@app.post("/api/report")
def api_report(body: ReportIn) -> StreamingResponse:
    from .report import build_report_html
    html_str = build_report_html(
        body.name, body.tokens, body.candidates, body.profile,
        rank_words=_rank_words,
    )
    safe = "".join(ch if ch.isalnum() else "_" for ch in (body.name or "target"))[:40]
    buf = io.BytesIO(html_str.encode("utf-8"))
    return StreamingResponse(
        buf, media_type="text/html",
        headers={"Content-Disposition": f'attachment; filename=report_{safe}.html'},
    )


@app.post("/api/analyze")
def api_analyze(body: AnalyzeIn) -> dict:
    """Fetch public text from the discovered profiles and run the ML layer."""
    from ..discovery.enrich import enrich_candidate
    from ..discovery.http import PoliteClient
    from ..discovery.models import Candidate
    from ..ml import enrich_profile

    cands = [Candidate(platform=c.platform, url=c.url, handle=c.handle)
             for c in body.candidates]

    from ..discovery import facebook as fb
    from ..discovery.instagram import (
        fetch_profile_text, load_loader, session_available,
    )
    from ..discovery.enrich import naive_keywords

    ig_loader = load_loader() if session_available() else None
    fb_ready = fb.session_available()

    per_profile = []
    # direct profile fetches (not search) — be snappy, don't hammer-retry
    client = PoliteClient(min_interval=0.3, max_retries=1, timeout=12.0)
    try:
        for c in cands:
            status = ""
            if c.platform == "instagram" and ig_loader is not None:
                ig = fetch_profile_text(c.handle, ig_loader)
                if ig["ok"]:
                    c.public_text = ig["text"]
                    c.keywords = naive_keywords(ig["text"])
                    status = f"IG session · {ig['n_captions']} caption(s)"
                else:
                    status = ig["error"]
            elif c.platform == "instagram":
                # anonymous IG yields nothing and is slow — skip the fetch
                status = "no IG session — run: python -m osintpwd ig-login <user>"
            elif c.platform == "facebook" and fb_ready:
                fbres = fb.fetch_profile_text(c.url)
                if fbres["ok"]:
                    c.public_text = fbres["text"]
                    c.keywords = naive_keywords(fbres["text"])
                    status = "FB session"
                else:
                    status = fbres["error"]
            elif c.platform == "facebook":
                status = "no FB session — run: python -m osintpwd fb-login"
            else:
                enrich_candidate(c, client)

            per_profile.append({
                "platform": c.platform, "handle": c.handle,
                "keywords": c.keywords[:20],
                "has_text": bool(c.public_text),
                "image_url": c.image_url,
                "status": status,
            })
    finally:
        client.close()

    parts = body.name.split()
    profile = Profile(first_name=parts[0] if parts else "",
                      last_name=parts[-1] if len(parts) > 1 else "")
    for c in cands:
        if c.handle:
            profile.custom.append(c.handle)

    blob = " . ".join(c.public_text for c in cands if c.public_text)
    res = enrich_profile(profile, text=blob, use_spacy=True) if blob else None
    p = res.profile if res else profile

    return {
        "per_profile": per_profile,
        "profile": {
            "first_name": p.first_name, "last_name": p.last_name,
            "city": p.city, "employer": p.employer,
            "interests": p.interests, "custom": p.custom,
            "significant_years": p.significant_years,
        },
        "found": {
            "interests": res.interests if res else [],
            "proper_nouns": res.proper_nouns if res else [],
            "years": res.years if res else [],
        } if res else {"interests": [], "proper_nouns": [], "years": []},
        "analyzed": len(cands),
        "with_text": sum(1 for c in cands if c.public_text),
    }


def run(host: str = "127.0.0.1", port: int = 7020) -> None:
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="info")
