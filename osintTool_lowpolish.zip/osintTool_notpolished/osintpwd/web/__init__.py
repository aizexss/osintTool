"""Local web dashboard for the password-audit tool (FastAPI)."""
