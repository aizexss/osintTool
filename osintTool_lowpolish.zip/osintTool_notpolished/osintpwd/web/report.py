"""Self-contained HTML report builder for a single target.

Pulls together everything the tool gathered — discovered profiles, harvested
OSINT signals, and the password-risk analysis — into one printable HTML file
the analyst downloads. No external assets (inline CSS), safe to archive or
hand off. Defensive/authorized use only; the report says so.
"""

from __future__ import annotations

import html
from datetime import datetime

from ..generator import generate_wordlist
from ..models import Config, Profile


def _esc(s) -> str:
    return html.escape(str(s or ""))


def _chip(text: str) -> str:
    return f'<span class="chip">{_esc(text)}</span>'


def build_report_html(name: str, tokens: list[str], candidates: list[dict],
                      profile_dict: dict | None = None,
                      model_ranked: bool = False,
                      rank_words=None) -> str:
    """Render the report. `rank_words(words)->(ordered, ranked)` optionally
    re-orders the wordlist preview by the active behavioural model."""
    profile = Profile(**{k: v for k, v in (profile_dict or {}).items()
                         if k in Profile.__dataclass_fields__})
    if tokens:
        profile.interests = list(dict.fromkeys(list(profile.interests) + tokens))

    # --- password audit ---
    words = generate_wordlist(profile, Config())
    ranked = False
    if rank_words is not None:
        words, ranked = rank_words(words)
    top = words[:40]

    # only the profiles that were actually analysed
    analysed = [c for c in candidates if c.get("analyzed") or c.get("keywords")
                or c.get("status")]

    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    # --- sections ---
    prof_rows = ""
    for label, val in [("Имя", name), ("Город", profile.city),
                       ("Работа", profile.employer), ("Должность", profile.job_title),
                       ("Год рождения", profile.birth_year or "")]:
        if val:
            prof_rows += f"<tr><td class='k'>{_esc(label)}</td><td>{_esc(val)}</td></tr>"

    cand_html = ""
    for c in analysed:
        kw = ", ".join(c.get("keywords", [])[:15])
        status = c.get("status", "")
        cand_html += f"""
        <div class="card">
          <div class="cardhead"><span class="plat">{_esc(c.get('platform',''))}</span>
            <span class="score">score {_esc(c.get('score',''))}</span></div>
          <a href="{_esc(c.get('url',''))}">@{_esc(c.get('handle','?'))}</a>
          <div class="kw">{_esc(kw) if kw else _esc(status) or 'нет данных'}</div>
        </div>"""
    if not cand_html:
        cand_html = "<p class='muted'>проанализированные профили отсутствуют</p>"

    tokens_html = "".join(_chip(t) for t in profile.base_tokens()[:60]) or \
        "<span class='muted'>нет токенов</span>"

    top_html = "".join(f"<li>{_esc(w)}</li>" for w in top)

    rank_note = ("Топ отранжирован поведенческой моделью — самые вероятные пароли цели сверху."
                 if ranked else
                 "Порядок правиловый (поведенческая модель не обучена).")

    return f"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>OSINT-отчёт — {_esc(name)}</title>
<style>
  :root{{--bg:#f6f8fa;--card:#fff;--bd:#d0d7de;--tx:#1f2328;--mut:#656d76;--ac:#0969da}}
  *{{box-sizing:border-box}}
  body{{margin:0;background:var(--bg);color:var(--tx);font:14px/1.55 system-ui,Segoe UI,Roboto,sans-serif}}
  .wrap{{max-width:900px;margin:0 auto;padding:32px 24px}}
  header{{border-bottom:3px solid var(--ac);padding-bottom:16px;margin-bottom:24px}}
  h1{{font-size:24px;margin:0 0 4px}} .sub{{color:var(--mut);font-size:13px}}
  .risk{{display:inline-block;color:#fff;padding:4px 14px;border-radius:20px;font-weight:700;font-size:13px}}
  section{{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:18px 20px;margin-bottom:18px}}
  h2{{font-size:14px;text-transform:uppercase;letter-spacing:.5px;color:var(--mut);margin:0 0 12px}}
  table{{width:100%;border-collapse:collapse}} td{{padding:6px 8px;border-bottom:1px solid var(--bd);vertical-align:top}}
  td.k{{color:var(--mut);width:150px}} .mono{{font-family:ui-monospace,Consolas,monospace}}
  .ok{{color:#1a7f37;font-weight:700}} .bad{{color:#cf222e;font-weight:700}} .muted{{color:var(--mut)}}
  .chip{{display:inline-block;background:#eaeef2;border-radius:20px;padding:2px 10px;margin:2px;font-size:12px}}
  .grid{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}
  .card{{background:#f6f8fa;border:1px solid var(--bd);border-radius:8px;padding:10px 12px}}
  .cardhead{{display:flex;justify-content:space-between;font-size:11px}}
  .plat{{color:var(--ac);text-transform:uppercase;font-weight:700}} .score{{color:var(--mut)}}
  .card a{{color:var(--tx);text-decoration:none;word-break:break-all;font-size:13px}}
  .kw{{color:var(--mut);font-size:12px;margin-top:4px}}
  ol.wl{{columns:2;font-family:ui-monospace,Consolas,monospace;font-size:12.5px;color:#57606a}}
  .disc{{font-size:11.5px;color:var(--mut);border-top:1px solid var(--bd);padding-top:14px;margin-top:8px}}
  @media print{{body{{background:#fff}} section{{break-inside:avoid}}}}
</style></head><body><div class="wrap">
  <header>
    <h1>OSINT-отчёт: {_esc(name) or '—'}</h1>
    <div class="sub">Сформирован {now}</div>
  </header>

  <section><h2>Профиль цели</h2>
    <table>{prof_rows or "<tr><td class='muted'>нет данных</td></tr>"}</table>
    <div style="margin-top:10px">{tokens_html}</div>
  </section>

  <section><h2>Проанализированные соцсети</h2><div class="grid">{cand_html}</div></section>

  <section><h2>Аудит паролей — самые вероятные кандидаты</h2>
    <p class="muted">Словарь: {len(words):,} кандидатов. {_esc(rank_note)}</p>
    <ol class="wl">{top_html}</ol>
  </section>

  <div class="disc">
    Отчёт сформирован автоматизированным инструментом аудита парольной гигиены на основе
    открытых источников. Предназначен исключительно для авторизованной защитной проверки
    (аудит собственной организации с разрешения). Данные отражают состояние на момент сбора.
  </div>
</div></body></html>"""
