"""Single local discovery worker with SQLite checkpoints and a renewable lease.

Only public discovery input/results are stored. No account credentials are used.
Completed jobs expire after seven days; interrupted searches replay their plan
using successful query checkpoints, while failed/partial queries remain retryable.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, replace
import hashlib
import json
import logging
import os
from pathlib import Path
import sqlite3
import threading
import time
import uuid

from ..discovery.models import SearchResult

LOG = logging.getLogger(__name__)
LEASE_SECONDS = 20
RETENTION = 7 * 86400


class QueueFull(ValueError):
    pass


class QueryJournal:
    def __init__(self, store, job_id):
        self.store, self.job_id = store, job_id

    def lookup(self, key):
        with self.store.connect() as db:
            row = db.execute('SELECT saved, hits FROM queries WHERE job_id=? AND query_key=?',
                             (self.job_id, json.dumps(key))).fetchone()
        if row is None or time.time() - row[0] >= RETENTION:
            return None
        age = max(0, int(time.time() - row[0]))
        return [replace(SearchResult(**h), cached=True,
                        cache_age_seconds=h.get('cache_age_seconds', 0) + age) for h in json.loads(row[1])]

    def save(self, key, record, hits):
        # An interrupted run must not memorialize a CAPTCHA as an empty result.
        reusable = (record['status'] in ('ok', 'empty') and not record.get('partial_query')
                    and not any(h.partial or h.stale for h in hits))
        with self.store.connect() as db:
            if reusable:
                db.execute('INSERT OR REPLACE INTO queries VALUES (?, ?, ?, ?)',
                           (self.job_id, json.dumps(key), time.time(),
                            json.dumps([asdict(h) for h in hits], ensure_ascii=False)))
            db.execute('UPDATE jobs SET completed_queries=MAX(completed_queries,?), updated=? WHERE id=? AND owner=?',
                       (record['sequence'], time.time(), self.job_id, self.store.owner))


class JobStore:
    def __init__(self, path: Path, runner):
        self.path, self.runner = path, runner
        self.owner = uuid.uuid4().hex
        self.stop = threading.Event()
        self.thread = None
        self.lock = threading.Lock()
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript('''
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY, fingerprint TEXT, input TEXT, status TEXT,
                    phase TEXT, result TEXT, error TEXT, created REAL, updated REAL,
                    owner TEXT, lease REAL DEFAULT 0, attempts INTEGER DEFAULT 0,
                    completed_queries INTEGER DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS queries (
                    job_id TEXT REFERENCES jobs(id) ON DELETE CASCADE,
                    query_key TEXT, saved REAL, hits TEXT, PRIMARY KEY(job_id, query_key)
                );
            ''')

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=5)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            with db:
                yield db
        finally:
            db.close()

    def submit(self, payload):
        encoded = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        fingerprint = hashlib.sha256(encoded.encode()).hexdigest()
        now = time.time()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute("DELETE FROM jobs WHERE status IN ('completed','failed') AND updated < ?",
                       (now - RETENTION,))
            row = db.execute("SELECT id FROM jobs WHERE fingerprint=? AND status IN ('queued','running')",
                             (fingerprint,)).fetchone()
            if row:
                job_id = row['id']
            else:
                count = db.execute("SELECT count(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0]
                if count >= 3:
                    raise QueueFull('Local discovery queue is full')
                job_id = uuid.uuid4().hex
                db.execute('INSERT INTO jobs (id,fingerprint,input,status,phase,created,updated) '
                           'VALUES (?,?,?,?,?,?,?)', (job_id, fingerprint, encoded, 'queued', 'queued', now, now))
                db.execute("DELETE FROM jobs WHERE id IN (SELECT id FROM jobs WHERE status IN ('completed','failed') "
                           'ORDER BY updated DESC LIMIT -1 OFFSET 30)')
        return self.get(job_id)

    def get(self, job_id):
        with self.connect() as db:
            row = db.execute('SELECT * FROM jobs WHERE id=?', (job_id,)).fetchone()
        if not row:
            return None
        return {key: row[key] for key in ('id', 'status', 'phase', 'error', 'created', 'updated',
                                         'attempts', 'completed_queries')} | {
            'input': json.loads(row['input']), 'result': json.loads(row['result']) if row['result'] else None,
            'result_revision': hashlib.sha256((row['result'] or '').encode()).hexdigest()[:16]}

    def claim(self):
        now = time.time()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute("SELECT 1 FROM jobs WHERE status='running' AND lease>=?", (now,)).fetchone():
                return None
            db.execute("UPDATE jobs SET status='failed', error='interrupted_repeatedly', updated=? "
                       "WHERE status='running' AND lease<? AND attempts>=3", (now, now))
            row = db.execute("SELECT id FROM jobs WHERE status='queued' OR "
                             "(status='running' AND lease<? AND attempts<3) ORDER BY created LIMIT 1", (now,)).fetchone()
            if row:
                db.execute("UPDATE jobs SET status='running', phase='search', owner=?, lease=?, "
                           'attempts=attempts+1, updated=? WHERE id=?',
                           (self.owner, now + LEASE_SECONDS, now, row['id']))
        return self.get(row['id']) if row else None

    def checkpoint(self, job_id, result, phase):
        with self.connect() as db:
            db.execute('UPDATE jobs SET result=?, phase=?, updated=? WHERE id=? AND owner=?',
                       (json.dumps(result, ensure_ascii=False), phase, time.time(), job_id, self.owner))

    def execute(self, job):
        job_id = job['id']
        try:
            result = self.runner(job['input'], QueryJournal(self, job_id),
                                 lambda result, phase: self.checkpoint(job_id, result, phase))
            result.setdefault('stats', {}).update(analysis_attempts=job['attempts'],
                                                  analysis_total_seconds=round(time.time() - job['created'], 1))
            with self.connect() as db:
                db.execute("UPDATE jobs SET result=?, status='completed', phase='completed', updated=?, lease=0 "
                           'WHERE id=? AND owner=?', (json.dumps(result, ensure_ascii=False), time.time(), job_id, self.owner))
        except Exception:
            LOG.exception('Local discovery job failed: %s', job_id)
            with self.connect() as db:
                db.execute("UPDATE jobs SET status='failed', error='analysis_failed', updated=?, lease=0 "
                           'WHERE id=? AND owner=?', (time.time(), job_id, self.owner))

    def _loop(self):
        worker, active_id = None, None
        while not self.stop.is_set():
            try:
                if worker and worker.is_alive():
                    with self.connect() as db:
                        db.execute("UPDATE jobs SET lease=? WHERE id=? AND owner=? AND status='running'",
                                   (time.time() + LEASE_SECONDS, active_id, self.owner))
                else:
                    job = self.claim()
                    if job:
                        active_id = job['id']
                        worker = threading.Thread(target=self.execute, args=(job,), daemon=True,
                                                  name='local-discovery')
                        worker.start()
            except sqlite3.Error:
                LOG.exception('Local discovery queue temporarily unavailable')
            self.stop.wait(2)

    def start(self):
        with self.lock:
            if self.thread and self.thread.is_alive():
                return
            self.stop.clear()
            self.thread = threading.Thread(target=self._loop, daemon=True, name='discovery-queue')
            self.thread.start()

    def close(self):
        self.stop.set()
        if self.thread:
            self.thread.join(timeout=3)


def run_discovery(payload, journal, progress):
    from .app import DiscoverIn, _discovery_hints, _discovery_response
    from ..discovery import discover
    body = DiscoverIn.model_validate(payload)
    options = {'platforms': tuple(body.platforms)} if body.platforms else {}
    result = discover(body.name, _discovery_hints(body), username_scan=True,
                      username_provider='maigret', enrich_profiles=4, fetch_pages=6, search_mode='keyless',
                      query_budget=payload['query_budget'], journal=journal,
                      progress=lambda result, phase: progress(_discovery_response(result), phase), **options)
    return _discovery_response(result)


_store = None
_store_lock = threading.Lock()


def job_store():
    global _store
    with _store_lock:
        if _store is None:
            default = Path(__file__).resolve().parents[2] / '.cache' / 'discovery-jobs.sqlite3'
            _store = JobStore(Path(os.environ.get('OSINT_DISCOVERY_JOBS_PATH', str(default))), run_discovery)
        return _store
