"""Transformation primitives shared by the generator and the evaluator.

The same rules that *expand* a token into password variants also run in
reverse (de-leet, strip affixes) so the evaluator can recognise a password
built from a personal token even when we did not enumerate that exact form.

Pure stdlib, no network, no state — safe to embed anywhere.
"""

from __future__ import annotations

import itertools

# Canonical leet map used when *generating* variants.
LEET_MAP: dict[str, str] = {
    "a": "@", "e": "3", "i": "1", "o": "0",
    "s": "$", "t": "7", "l": "1", "g": "9", "b": "8",
}

# Reverse map used when *normalising* a candidate password back toward letters.
# A digit/symbol can map to several letters; we keep the most common reading.
UNLEET_MAP: dict[str, str] = {
    "@": "a", "4": "a",
    "3": "e",
    "1": "i", "!": "i",
    "0": "o",
    "$": "s", "5": "s",
    "7": "t",
    "9": "g",
    "8": "b",
}


def case_variants(token: str, lower: bool, upper: bool, capitalized: bool) -> list[str]:
    """Return the requested case forms of a token, de-duplicated."""
    out: list[str] = []
    if lower:
        out.append(token.lower())
    if upper:
        out.append(token.upper())
    if capitalized:
        out.append(token.capitalize())
    seen: set[str] = set()
    return [t for t in out if not (t in seen or seen.add(t))]


def leet_variant(token: str) -> str:
    """Full-substitution leet form of a token (khabib -> kh@818)."""
    return "".join(LEET_MAP.get(ch, ch) for ch in token.lower())


def unleet(token: str) -> str:
    """Best-effort reverse: turn leet chars back into letters for matching.

    'kh@818' -> 'khabib' (approximately). Non-mapped chars pass through.
    """
    return "".join(UNLEET_MAP.get(ch, ch) for ch in token.lower())


def strip_affixes(password: str) -> str:
    """Remove leading/trailing digits and punctuation, keep the word core.

    'khabibNurmagomedov777' -> 'khabibNurmagomedov'
    '!!!Real_Madrid.'       -> 'Real_Madrid'  (inner separators kept)
    """
    return password.strip("0123456789!@#$%^&*()-_=+.,;:'\"[]{}<>/\\|`~ ")


def alpha_runs(password: str, min_len: int = 3) -> list[str]:
    """Extract maximal alphabetic runs from a password.

    Used by the evaluator to find embedded personal words in a compound
    password like 'Madrid2018Khabib'.
    """
    runs: list[str] = []
    cur = ""
    for ch in password:
        if ch.isalpha():
            cur += ch
        else:
            if len(cur) >= min_len:
                runs.append(cur)
            cur = ""
    if len(cur) >= min_len:
        runs.append(cur)
    return runs


def append_affixes(token: str, numbers: list[str], symbols: list[str],
                   append_symbols: bool) -> list[str]:
    """token + number, token + symbol, token + number + symbol."""
    out: list[str] = [token]
    for n in numbers:
        out.append(token + n)
        if append_symbols:
            for s in symbols:
                out.append(token + n + s)
                out.append(token + s + n)
    if append_symbols:
        for s in symbols:
            out.append(token + s)
    return out


def prepend_affixes(token: str, numbers: list[str]) -> list[str]:
    """number + token."""
    return [n + token for n in numbers]


def combine(tokens: list[str], separators: tuple[str, ...] = ("", "_", ".", "-")) -> list[str]:
    """All ordered 2-token joins with a few common separators.

    Capped by the caller via slicing; here we just enumerate.
    """
    out: list[str] = []
    for a, b in itertools.permutations(tokens, 2):
        for sep in separators:
            out.append(a + sep + b)
    return out
