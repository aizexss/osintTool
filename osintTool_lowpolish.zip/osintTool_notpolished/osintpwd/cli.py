"""Command-line entry point for the offline password engine.

Usage:
    python -m osintpwd wordlist  profile.json  [-o words.txt]
    python -m osintpwd check     profile.json  "SomePassword1"
    python -m osintpwd demo

A profile is a JSON file whose keys match the Profile dataclass fields.
Network / OSINT collection lives in a separate layer; this CLI is offline.
"""

from __future__ import annotations

import argparse
import json
import sys

from .evaluator import evaluate_password
from .generator import generate_wordlist, write_wordlist
from .models import Config, Profile


def load_profile(path: str) -> Profile:
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    valid = Profile.__dataclass_fields__.keys()
    unknown = set(data) - set(valid)
    if unknown:
        print(f"warning: ignoring unknown profile keys: {sorted(unknown)}",
              file=sys.stderr)
    return Profile(**{k: v for k, v in data.items() if k in valid})


def _demo_profile() -> Profile:
    return Profile(
        first_name="Aslan",
        last_name="Serikov",
        nickname="asik",
        birth_year=1994,
        city="Almaty",
        employer="AcmeBank",
        pets=["Barsik"],
        interests=["Khabib Nurmagomedov", "UFC", "Real Madrid"],
    )


def cmd_wordlist(args: argparse.Namespace) -> int:
    profile = _demo_profile() if args.demo else load_profile(args.profile)
    config = Config()
    if args.out:
        n = write_wordlist(profile, args.out, config)
        print(f"wrote {n} candidates -> {args.out}")
    else:
        for w in generate_wordlist(profile, config):
            print(w)
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    profile = _demo_profile() if args.demo else load_profile(args.profile)
    verdict = evaluate_password(args.password, profile)
    status = "ALLOW" if verdict.allowed else "REJECT"
    print(f"[{status}]  score={verdict.score}  password={args.password!r}")
    for r in verdict.reasons:
        print(f"  - {r}")
    if verdict.matched_tokens:
        print(f"  matched: {', '.join(verdict.matched_tokens)}")
    return 0 if verdict.allowed else 1


def cmd_demo(args: argparse.Namespace) -> int:
    profile = _demo_profile()
    print("=== demo profile ===")
    print(json.dumps(profile.__dict__, ensure_ascii=False, indent=2))
    print("\n=== sample wordlist (first 25) ===")
    for w in generate_wordlist(profile)[:25]:
        print(" ", w)
    print("\n=== password checks ===")
    for pw in ["khabibNurmagomedov777", "Kh@bib_2018!", "Almaty2020",
               "Barsik123", "correct-horse-battery-staple", "Tr0ub4dour&3"]:
        v = evaluate_password(pw, profile)
        tag = "ALLOW " if v.allowed else "REJECT"
        why = v.reasons[0] if v.reasons else ""
        print(f"  [{tag}] {pw:32} score={v.score:<5} {why}")
    return 0


def cmd_discover(args: argparse.Namespace) -> int:
    # imported lazily: keeps the offline engine free of network deps
    from .discovery import discover, enrich
    from .discovery.pipeline import candidates_to_profile

    hints = {
        k: v for k, v in {
            "city": args.city, "country": args.country,
            "employer": args.employer, "job_title": args.job_title,
            "school": args.school,
        }.items() if v
    }
    print(f"discovering '{args.name}' with hints {hints or '{}'} ...")
    result = discover(args.name, hints)

    if result.errors:
        for e in result.errors:
            print(f"  ! {e}", file=sys.stderr)
    if not result.candidates:
        print("no candidates found (search may be rate-limited; try again "
              "or add hints).")
        return 1

    n_named = sum(1 for c in result.candidates if c.name_match)
    n_groups = max((c.group for c in result.candidates), default=0)
    grp = f", {n_groups} identity group(s)" if n_groups > 1 else ""
    print(f"\n{len(result.candidates)} candidate(s)  ({n_named} by name{grp}):")
    for i, c in enumerate(result.candidates):
        tag = " [по имени]" if c.name_match else ""
        gtag = f" #{c.group}" if c.group else ""
        print(f"  [{i}] {c.platform:9} score={c.score:.2f}  @{c.handle}{tag}{gtag}")
        print(f"      {c.url}")
        if c.title:
            print(f"      {c.title[:100]}")
        if c.matched_hints:
            print(f"      ✔ matched: {', '.join(c.matched_hints)}")

    profile = candidates_to_profile(args.name, result.candidates, hints)

    if args.enrich or args.photos_out:
        print("\nenriching (fetching public metadata) ...")
        enrich(result.candidates)
        for c in result.candidates:
            if c.keywords:
                print(f"  @{c.handle}: {', '.join(c.keywords[:15])}")

        # run the local ML layer over the harvested public text
        from .ml import enrich_profile
        blob = " . ".join(c.public_text for c in result.candidates if c.public_text)
        if blob:
            res = enrich_profile(profile, text=blob, use_spacy=True)
            if res.profile.interests:
                print(f"  interests: {', '.join(res.profile.interests[:15])}")
            if res.notes:
                print(f"  notes: {'; '.join(res.notes)}")

    if args.photos_out:
        from .discovery.enrich import download_images
        from .discovery.http import PoliteClient
        client = PoliteClient()
        try:
            saved = download_images(result.candidates, args.photos_out, client)
        finally:
            client.close()
        print(f"\ndownloaded {len(saved)} profile photo(s) -> {args.photos_out}")
        if saved:
            print("  feed these to the nomad face_recog pipeline, then confirm:")
            print(f"  python -m osintpwd confirm <face_recog_output_dir> "
                  f"--photos {args.photos_out}")

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(profile.__dict__, fh, ensure_ascii=False, indent=2)
        print(f"\nwrote draft profile -> {args.out}")
        print("  review it, move real interests/pets into the right fields, then:")
        print(f"  python -m osintpwd wordlist {args.out} -o words.txt")
    return 0


def cmd_confirm(args: argparse.Namespace) -> int:
    """Read a nomad face_recog output/ folder and confirm profile identity."""
    from .ml.faces_nomad import read_identity, stats

    rep = read_identity(args.output_dir)
    if not rep.available:
        print(f"no clusters found in {args.output_dir} "
              "(is this a face_recog output/ folder?)")
        return 1

    st = stats(args.output_dir)
    print(f"clusters: {len(rep.clusters)}  "
          f"faces: {st.get('total_faces', '?')}")

    if args.photos:
        import os
        files = [f for f in os.listdir(args.photos)
                 if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))]
    else:
        files = args.files or []

    if not files:
        print("pass --photos <dir> or a list of filenames to confirm identity")
        return 0

    same, mapping = rep.same_person(files)
    print(f"\nsame person across profiles: {'YES' if same else 'NO'}")
    for f, c in mapping.items():
        print(f"  {f:40} -> {c or 'no match / not clustered'}")
    return 0 if same else 2


def cmd_enrich(args: argparse.Namespace) -> int:
    """Offline: enrich a profile from a text file and/or a folder of images."""
    from .ml import enrich_profile

    profile = load_profile(args.profile) if args.profile else Profile()
    text = ""
    if args.text_file:
        with open(args.text_file, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()

    res = enrich_profile(
        profile, text=text, image_dir=args.images,
        use_spacy=not args.no_spacy, use_objects=args.objects,
    )
    print("=== enrichment ===")
    if res.profile.interests:
        print(f"interests: {', '.join(res.profile.interests)}")
    if res.profile.significant_years:
        print(f"years:     {res.profile.significant_years}")
    if res.geo:
        print(f"geotags:   {res.geo}")
    if res.image_hints:
        print(f"img hints: {', '.join(res.image_hints)}")
    if res.notes:
        print(f"notes:     {'; '.join(res.notes)}")

    out = args.out or args.profile
    if out:
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(res.profile.__dict__, fh, ensure_ascii=False, indent=2)
        print(f"\nwrote enriched profile -> {out}")
    return 0


def cmd_ig_login(args: argparse.Namespace) -> int:
    """Log into a burner IG account and save a reusable session.

    Username: CLI arg or IG_USERNAME (.env). Password: IG_PASSWORD (.env) if
    set, otherwise prompted locally via getpass.
    """
    import getpass
    import os
    from .discovery.instagram import login_and_save

    username = args.username or os.environ.get("IG_USERNAME", "").strip()
    if not username:
        print("no username: pass it or set IG_USERNAME in .env")
        return 1

    print("Instagram login — use a BURNER account, never a personal one.")
    password = os.environ.get("IG_PASSWORD", "")
    if password:
        print("using IG_PASSWORD from environment/.env")
    else:
        print("password is read locally and NOT stored; only the session is saved.")
        password = getpass.getpass(f"Password for @{username}: ")
    if not password:
        print("no password entered, aborting")
        return 1
    try:
        path = login_and_save(username, password)
    except Exception as e:  # noqa: BLE001
        print(f"login failed: {type(e).__name__}: {e}")
        print("if IG asks for a challenge, log in via the app once, then retry.")
        return 1
    print(f"\n✓ session saved -> {path}")
    print(f"set IG_USERNAME={username} in .env, then analysis reads IG.")
    return 0


def cmd_fb_login(args: argparse.Namespace) -> int:
    """Open a browser to log into a burner Facebook account and save cookies."""
    from .discovery.facebook import fb_login_interactive
    print("Facebook login — use a BURNER account, never a personal one.")
    print("A browser window will open. Log in there (2FA ok); cookies are saved.")
    try:
        path = fb_login_interactive()
    except Exception as e:  # noqa: BLE001
        print(f"login failed: {type(e).__name__}: {e}")
        print("ensure Playwright + chromium are installed "
              "(pip install playwright && python -m playwright install chromium)")
        return 1
    print(f"\n✓ FB session saved -> {path}")
    print("analysis will now read Facebook profiles you selected.")
    return 0


def cmd_fb_import(args: argparse.Namespace) -> int:
    """Reuse an existing browser FB login as a saved session."""
    from .discovery import facebook as fb

    if args.cookies:
        # legacy: decrypt cookies from the browser store (fails on modern Chrome)
        try:
            path, n = fb.import_cookies_from_browser(args.browser)
        except Exception as e:  # noqa: BLE001
            print(f"cookie import failed: {type(e).__name__}: {e}")
            print("modern Chrome/Edge encrypt cookies — use the default "
                  "(profile) mode instead: python -m osintpwd fb-import")
            return 1
        print(f"✓ imported {n} facebook cookies -> {path}")
        return 0

    # default: drive Chrome with your own profile (Chrome decrypts its cookies)
    print("Reusing your Chrome login — CLOSE ALL CHROME WINDOWS first "
          "(the profile is locked while open).")
    try:
        path, n, logged_in = fb.import_from_chrome_profile(
            profile_dir=args.profile_dir)
    except Exception as e:  # noqa: BLE001
        print(f"import failed: {type(e).__name__}: {e}")
        print("tips: fully close Chrome (check the tray); if you use a non-default"
              " profile pass --profile-dir \"Profile 1\"; or fall back to"
              " `python -m osintpwd fb-login`.")
        return 1
    if not logged_in:
        print(f"saved {n} cookies, but you don't look logged into Facebook in "
              f"that Chrome profile. Log into facebook.com in Chrome, or try "
              f"another --profile-dir. Session: {path}")
        return 1
    print(f"✓ FB session imported from your Chrome profile -> {path}")
    print("analysis will now read Facebook using your existing login.")
    return 0


def cmd_pwmodel_train(args: argparse.Namespace) -> int:
    """Build a behavioural password model from a user's own passwords."""
    from .ml.pwmodel import _DEFAULT_PATH
    from .ml.pwtrain import fine_tune

    # read passwords: .csv with a 'password' column, else one per line
    pwds: list[str] = []
    if args.passwords.lower().endswith(".csv"):
        import csv
        with open(args.passwords, encoding="utf-8", errors="replace") as fh:
            reader = csv.DictReader(fh)
            col = "password" if reader.fieldnames and "password" in reader.fieldnames else None
            fh.seek(0)
            if col:
                for row in csv.DictReader(fh):
                    if row.get("password"):
                        pwds.append(row["password"])
            else:
                for line in fh:
                    if line.strip():
                        pwds.append(line.strip())
    else:
        with open(args.passwords, encoding="utf-8", errors="replace") as fh:
            pwds = [ln.strip() for ln in fh if ln.strip()]

    base = args.base or _DEFAULT_PATH
    out = args.out
    print(f"fine-tuning behavioural model on {len(pwds)} passwords "
          f"({args.epochs} epochs)...")

    def prog(ep, loss):
        if ep == 1 or ep % 5 == 0:
            print(f"  epoch {ep:3d}  loss {loss:.4f}")

    try:
        h = fine_tune(pwds, base, out, epochs=args.epochs, progress=prog)
    except Exception as e:  # noqa: BLE001
        print(f"training failed: {type(e).__name__}: {e}")
        return 1
    print(f"\n✓ saved behavioural model -> {out}")
    print(f"  loss {h['loss'][0]} -> {h['loss'][-1]}  ({h['trainable']:,} params tuned)")
    print(f"  score passwords with it: OSINT_PWMODEL={out} in scoring, or use in the API")
    return 0


def cmd_web(args: argparse.Namespace) -> int:
    import os

    # Auto-attach a local SearXNG instance if one is reachable and the user
    # hasn't configured a backend, so discovery "just works" in the UI.
    if not os.environ.get("SEARXNG_URL"):
        url = args.searxng or "http://localhost:8080"
        try:
            import httpx
            r = httpx.get(f"{url}/healthz", timeout=1.5)
            if r.status_code < 500:
                os.environ["SEARXNG_URL"] = url
                print(f"search backend: SearXNG @ {url}")
        except Exception:  # noqa: BLE001
            print("search backend: none reachable (discovery will be limited)."
                  " Start SearXNG or set SERPER_API_KEY.")

    from .web.app import run
    print(f"dashboard -> http://{args.host}:{args.port}  (Ctrl+C to stop)")
    run(host=args.host, port=args.port)
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="osintpwd",
                                description="Offline personalized password engine")
    sub = p.add_subparsers(dest="cmd", required=True)

    pw = sub.add_parser("wordlist", help="generate a wordlist from a profile")
    pw.add_argument("profile", nargs="?", help="path to profile JSON")
    pw.add_argument("-o", "--out", help="write to file instead of stdout")
    pw.add_argument("--demo", action="store_true", help="use built-in demo profile")
    pw.set_defaults(func=cmd_wordlist)

    ck = sub.add_parser("check", help="evaluate one password against a profile")
    ck.add_argument("profile", nargs="?", help="path to profile JSON")
    ck.add_argument("password", help="password to evaluate")
    ck.add_argument("--demo", action="store_true", help="use built-in demo profile")
    ck.set_defaults(func=cmd_check)

    dm = sub.add_parser("demo", help="run a self-contained demonstration")
    dm.set_defaults(func=cmd_demo)

    ds = sub.add_parser("discover",
                        help="ONLINE: find candidate public profiles for a name")
    ds.add_argument("name", help='full name, e.g. "Aslan Serikov"')
    ds.add_argument("--city")
    ds.add_argument("--country")
    ds.add_argument("--employer")
    ds.add_argument("--job-title", dest="job_title")
    ds.add_argument("--school")
    ds.add_argument("--enrich", action="store_true",
                    help="also fetch public metadata for each candidate")
    ds.add_argument("--photos-out", dest="photos_out",
                    help="download candidate og:image photos into this folder "
                         "(for the nomad face_recog pipeline)")
    ds.add_argument("-o", "--out", help="write a draft profile JSON to this path")
    ds.set_defaults(func=cmd_discover)

    cf = sub.add_parser("confirm",
                        help="read nomad face_recog output/ and confirm identity")
    cf.add_argument("output_dir", help="path to face_recog output/ folder")
    cf.add_argument("--photos", help="folder of downloaded profile photos to check")
    cf.add_argument("--files", nargs="*", help="explicit filenames to check")
    cf.set_defaults(func=cmd_confirm)

    il = sub.add_parser("ig-login",
                        help="log into a burner IG account, save a session")
    il.add_argument("username", nargs="?",
                    help="burner IG username (or set IG_USERNAME in .env)")
    il.set_defaults(func=cmd_ig_login)

    fl = sub.add_parser("fb-login",
                        help="open a browser to log into a burner FB account")
    fl.set_defaults(func=cmd_fb_login)

    fi = sub.add_parser("fb-import",
                        help="reuse your existing Chrome FB login as a session")
    fi.add_argument("--profile-dir", default="Default",
                    help='Chrome profile folder (e.g. "Default", "Profile 1")')
    fi.add_argument("--cookies", action="store_true",
                    help="legacy: decrypt cookies from browser store (needs admin,"
                         " fails on modern Chrome)")
    fi.add_argument("--browser", default="chrome",
                    choices=["chrome", "edge", "firefox", "brave"],
                    help="browser for --cookies mode")
    fi.set_defaults(func=cmd_fb_import)

    pt = sub.add_parser("pwmodel-train",
                        help="build a behavioural password model from a user's passwords")
    pt.add_argument("passwords", help="file: .csv with 'password' column, or one per line")
    pt.add_argument("-o", "--out", default="models/personal.pth",
                    help="output model path")
    pt.add_argument("--base", help="base model to reuse the backbone from "
                    "(default: personal_adapted_poe_mtl.pth)")
    pt.add_argument("--epochs", type=int, default=40)
    pt.set_defaults(func=cmd_pwmodel_train)

    wb = sub.add_parser("web", help="launch the local web dashboard")
    wb.add_argument("--host", default="127.0.0.1")
    wb.add_argument("--port", type=int, default=7020)
    wb.add_argument("--searxng", help="SearXNG base URL (default http://localhost:8080)")
    wb.set_defaults(func=cmd_web)

    en = sub.add_parser("enrich",
                        help="LOCAL ML: enrich a profile from text and/or images")
    en.add_argument("profile", nargs="?", help="profile JSON to augment (optional)")
    en.add_argument("--text-file", dest="text_file",
                    help="file with harvested public text (posts, bio)")
    en.add_argument("--images", help="folder of local images (EXIF/objects)")
    en.add_argument("--objects", action="store_true",
                    help="run YOLO object detection (needs ultralytics)")
    en.add_argument("--no-spacy", action="store_true",
                    help="skip spaCy NER even if installed (rules only)")
    en.add_argument("-o", "--out", help="output path (default: overwrite input)")
    en.set_defaults(func=cmd_enrich)

    return p


def main(argv: list[str] | None = None) -> int:
    from .env import load_env
    load_env()  # pull SEARXNG_URL / IG_USERNAME / SERPER_API_KEY etc. from .env

    # Windows consoles default to cp1251/cp866 and crash on non-ASCII output
    # (og:titles, Cyrillic names). Force UTF-8 with replacement.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    args = build_parser().parse_args(argv)
    # allow `check --demo PASSWORD` without a profile path
    if getattr(args, "demo", False) and getattr(args, "profile", None) and \
            args.cmd == "check" and not getattr(args, "password", None):
        args.password = args.profile
        args.profile = None
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
