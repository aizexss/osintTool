"""Wordlist generation: Profile + Config -> candidate passwords.

This is the *reactive* side — the output is fed to hashcat/john to audit
existing password hashes dumped from the domain. It intentionally trades
precision for coverage (a big list), bounded by Config.max_words.
"""

from __future__ import annotations

from collections.abc import Iterator

from . import transforms as T
from .models import Config, Profile


def _numeric_pool(profile: Profile, config: Config) -> list[str]:
    """Numbers used as affixes: config defaults + profile dates + years."""
    pool = list(config.common_numbers)
    pool.extend(profile.date_tokens())
    if config.append_years:
        lo, hi = config.year_range
        pool.extend(str(y) for y in range(lo, hi + 1))
        pool.extend(str(y)[2:] for y in range(lo, hi + 1))
    # de-dup preserve order
    seen: set[str] = set()
    return [n for n in pool if not (n in seen or seen.add(n))]


def _iter_candidates(profile: Profile, config: Config) -> Iterator[str]:
    """Yield raw candidates (pre-filter). May yield duplicates.

    Order: EVERY token's plain case-variants first, THEN the affixed ones. This
    surfaces each personal token (pet, hobby, custom) near the top instead of
    burying later tokens under thousands of affixes of the first one — so a
    distinctive token is visible in the preview and reached first in an audit.
    """
    base = profile.base_tokens()
    numbers = _numeric_pool(profile, config)

    # optionally fold in 2-token combinations as extra "base" words
    tokens = list(base)
    if config.combine_tokens and len(base) >= 2:
        # cap combinations to avoid explosion: only combine the first N tokens
        head = base[:12]
        tokens.extend(T.combine(head))

    # precompute the case/leet variants once per token
    variant_lists: list[list[str]] = []
    for token in tokens:
        variants = T.case_variants(
            token, config.use_lower, config.use_upper, config.use_capitalized
        )
        if config.use_leet:
            variants.append(T.leet_variant(token))
        variant_lists.append(variants)

    # pass 1 — plain tokens (all of them surface early)
    for variants in variant_lists:
        for v in variants:
            yield v

    # pass 2 — affixed variants (numbers/symbols/years)
    for variants in variant_lists:
        for v in variants:
            for w in T.append_affixes(v, numbers, config.common_symbols,
                                      config.append_symbols):
                yield w
            if config.prepend_numbers:
                for w in T.prepend_affixes(v, numbers):
                    yield w


def generate_wordlist(profile: Profile, config: Config | None = None) -> list[str]:
    """Return a de-duplicated, length-filtered wordlist for this profile.

    Order is roughly "most likely first": plain tokens before heavily
    affixed ones, because generation walks tokens then affixes.
    """
    config = config or Config()
    out: list[str] = []
    seen: set[str] = set()

    for cand in _iter_candidates(profile, config):
        if len(cand) < config.min_length:
            continue
        if cand in seen:
            continue
        seen.add(cand)
        out.append(cand)
        if len(out) >= config.max_words:
            break
    return out


def write_wordlist(profile: Profile, path: str, config: Config | None = None) -> int:
    """Generate and write the wordlist to `path`. Returns count written."""
    words = generate_wordlist(profile, config)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        for w in words:
            fh.write(w + "\n")
    return len(words)
