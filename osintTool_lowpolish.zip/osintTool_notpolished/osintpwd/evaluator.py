"""Password evaluation: is a proposed password guessable from the profile?

This is the *proactive* side — it plugs into the moment a user sets or
changes a password (AD password filter, self-service portal) and answers:
"does this password derive from this person's public/known information?"

It does NOT just check membership in the generated wordlist. It normalises
the candidate (de-leet, strip affixes, split compounds) and fuzzy-matches
the word core against the profile's tokens, so 'Kh@bib_2018!' is caught
even though that exact string may not be in any list.
"""

from __future__ import annotations

import difflib
from dataclasses import dataclass, field

from . import transforms as T
from .models import Profile


@dataclass
class Verdict:
    """Result of evaluating one password against one profile."""

    allowed: bool
    score: float                     # 0.0 (safe) .. 1.0 (trivially derived)
    reasons: list[str] = field(default_factory=list)
    matched_tokens: list[str] = field(default_factory=list)

    def __bool__(self) -> bool:      # truthy == allowed
        return self.allowed


# similarity at/above this counts as "the same personal word"
_FUZZY_THRESHOLD = 0.82


def _similar(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, a, b).ratio()


def _best_match(word: str, tokens: list[str]) -> tuple[str, float]:
    """Best (token, similarity) for `word` against the profile tokens."""
    best_tok, best = "", 0.0
    for tok in tokens:
        # substring containment is a strong signal both ways
        if tok in word or word in tok:
            ratio = max(_similar(word, tok), 0.9)
        else:
            ratio = _similar(word, tok)
        if ratio > best:
            best_tok, best = tok, ratio
    return best_tok, best


def evaluate_password(
    password: str,
    profile: Profile,
    fuzzy_threshold: float = _FUZZY_THRESHOLD,
) -> Verdict:
    """Judge whether `password` is derivable from `profile`.

    Strategy:
      1. Normalise: lowercase, de-leet, strip surrounding digits/symbols.
      2. Pull out alphabetic runs (handles compounds like 'Madrid2018Khabib').
      3. Fuzzy-match each run against the profile's base tokens.
      4. Also flag when the password is essentially <personal word>+<year/number>.
    """
    tokens = profile.base_tokens()
    if not tokens:
        return Verdict(allowed=True, score=0.0,
                       reasons=["no profile data to compare against"])

    reasons: list[str] = []
    score = 0.0

    # Build the set of word-cores to test from the candidate.
    lowered = password.lower()
    deleeted = T.unleet(lowered)
    cores: set[str] = set()
    for variant in (lowered, deleeted):
        cores.add(T.strip_affixes(variant))
        cores.update(T.alpha_runs(variant, min_len=3))
    cores.discard("")

    # Keep only the single best (highest-ratio, then most alphabetic) core
    # per matched profile token, so reasons read cleanly.
    best_per_token: dict[str, tuple[float, str]] = {}
    for core in cores:
        tok, ratio = _best_match(core, tokens)
        if ratio >= fuzzy_threshold:
            prev = best_per_token.get(tok)
            if prev is None or ratio > prev[0]:
                best_per_token[tok] = (ratio, core)

    matched: list[str] = []
    for tok, (ratio, core) in best_per_token.items():
        matched.append(tok)
        score = max(score, ratio)
        reasons.append(
            f"contains personal token '{tok}' "
            f"(as '{core}', {int(ratio * 100)}% match)"
        )

    # Penalty pattern: personal word immediately followed by a number/year,
    # which is the classic 'khabibNurmagomedov777' shape.
    stripped = T.strip_affixes(lowered)
    trailing = lowered[len(stripped):] if lowered.startswith(stripped) else ""
    if matched and trailing and any(ch.isdigit() for ch in trailing):
        score = min(1.0, score + 0.05)
        reasons.append(
            f"personal word followed by digits ('{trailing}') — "
            "a very common, weak pattern"
        )

    matched = sorted(set(matched))
    allowed = not matched
    if allowed:
        reasons = ["no personal information detected in this password"]

    return Verdict(
        allowed=allowed,
        score=round(score, 3),
        reasons=reasons,
        matched_tokens=matched,
    )
