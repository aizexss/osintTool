"""Data models for a target profile and generation config.

Kept to the stdlib (dataclasses) on purpose: the evaluator runs inside an
Active Directory password filter where heavy dependencies are a liability.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Profile:
    """Everything we know about a person, sourced from OSINT / onboarding.

    Every field is optional. The generator and evaluator only use what is
    present. Free-text lists (interests, custom) are where the juicy,
    person-specific tokens live — e.g. ["khabib", "nurmagomedov", "ufc"].
    """

    first_name: str = ""
    last_name: str = ""
    nickname: str = ""

    birth_year: int | None = None          # e.g. 1994
    significant_years: list[int] = field(default_factory=list)  # grad, wedding...

    city: str = ""
    country: str = ""
    street: str = ""

    employer: str = ""
    job_title: str = ""

    spouse: str = ""
    children: list[str] = field(default_factory=list)
    pets: list[str] = field(default_factory=list)

    phone_digits: str = ""                 # bare digits, e.g. "7777123456"

    interests: list[str] = field(default_factory=list)   # teams, idols, hobbies
    custom: list[str] = field(default_factory=list)       # anything else notable

    def base_tokens(self) -> list[str]:
        """All raw word-tokens tied to this person (before transformation).

        Multi-word entries (e.g. "khabib nurmagomedov") are emitted both as
        the joined phrase and as individual words, since people build
        passwords from either.
        """
        raw: list[str] = []

        singles = [
            self.first_name, self.last_name, self.nickname,
            self.city, self.country, self.street,
            self.employer, self.job_title, self.spouse,
        ]
        raw.extend(singles)
        raw.extend(self.children)
        raw.extend(self.pets)
        raw.extend(self.interests)
        raw.extend(self.custom)

        tokens: list[str] = []
        for entry in raw:
            entry = (entry or "").strip()
            if not entry:
                continue
            words = entry.split()
            if len(words) > 1:
                tokens.append("".join(words))   # khabibnurmagomedov
                tokens.extend(words)            # khabib, nurmagomedov
            else:
                tokens.append(entry)

        # de-dup, drop 1-char noise, lowercase for a canonical set
        seen: set[str] = set()
        out: list[str] = []
        for t in tokens:
            t = t.lower()
            if len(t) < 2 or t in seen:
                continue
            seen.add(t)
            out.append(t)
        return out

    def date_tokens(self) -> list[str]:
        """Numeric tokens derived from years and phone."""
        out: list[str] = []
        years = list(self.significant_years)
        if self.birth_year:
            years.append(self.birth_year)
        for y in years:
            out.append(str(y))          # 1994
            out.append(str(y)[2:])      # 94
        if self.phone_digits:
            d = "".join(ch for ch in self.phone_digits if ch.isdigit())
            if len(d) >= 4:
                out.append(d[-4:])      # last 4 of phone
        # de-dup preserve order
        seen: set[str] = set()
        return [x for x in out if not (x in seen or seen.add(x))]


@dataclass
class Config:
    """Knobs controlling how aggressively the wordlist is expanded.

    Bigger = more coverage but larger list. Defaults aim at a practical
    balance for a real audit.
    """

    # case variants to try per token
    use_lower: bool = True
    use_upper: bool = True
    use_capitalized: bool = True

    # leetspeak substitution (a->@, o->0, ...) as an extra variant
    use_leet: bool = True

    # numeric suffixes/prefixes appended/prepended to tokens
    common_numbers: list[str] = field(
        default_factory=lambda: [
            "1", "12", "123", "1234", "12345", "123456",
            "007", "777", "69", "420", "666", "111", "000",
            "2", "3", "21", "22", "23", "24", "25",
        ]
    )
    common_symbols: list[str] = field(
        default_factory=lambda: ["!", "@", "#", "$", ".", "_", "*"]
    )

    # also append a range of plausible years even without profile dates
    year_range: tuple[int, int] = (1970, 2027)
    append_years: bool = True

    # combine two base tokens (khabib + real, first + last, etc.)
    combine_tokens: bool = True

    prepend_numbers: bool = True
    append_symbols: bool = True

    # minimum length to keep in the wordlist (skip trivially short)
    min_length: int = 4
    # hard cap so generation never blows up
    max_words: int = 500_000
