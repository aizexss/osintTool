"""Load configuration from a .env file so users don't set env vars by hand.

Looks for `.env` in the current directory and in the project root, loading the
first ones found without overriding variables already set in the real
environment (real env wins). Safe to call more than once.
"""

from __future__ import annotations

import os

_LOADED = False


def load_env() -> None:
    global _LOADED
    if _LOADED:
        return
    _LOADED = True
    try:
        from dotenv import load_dotenv
    except ImportError:
        return

    seen: set[str] = set()
    candidates = [
        os.path.join(os.getcwd(), ".env"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                     ".env"),
    ]
    for path in candidates:
        ap = os.path.abspath(path)
        if ap in seen:
            continue
        seen.add(ap)
        if os.path.exists(ap):
            load_dotenv(ap, override=False)
