"""osintpwd — personalized password auditing engine.

Defensive-security tooling: builds a per-person password wordlist from
OSINT-derived keywords (reactive audit via hashcat) and evaluates whether
a proposed password is guessable from that same profile (proactive
prevention at password-change time, e.g. an Active Directory password filter).
"""

from .models import Profile, Config
from .generator import generate_wordlist
from .evaluator import evaluate_password, Verdict

__all__ = [
    "Profile",
    "Config",
    "generate_wordlist",
    "evaluate_password",
    "Verdict",
]

__version__ = "0.1.0"
