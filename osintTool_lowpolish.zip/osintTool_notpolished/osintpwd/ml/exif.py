"""EXIF / GPS extraction from local image files (Pillow only, offline).

Photos an employee posts publicly are a goldmine for password material:
the capture date, the camera/phone model, and — when geotags survive — the
exact location. We surface all of it as tokens for the generator/evaluator.
"""

from __future__ import annotations

from dataclasses import dataclass, field

try:
    from PIL import Image
    from PIL.ExifTags import GPSTAGS, TAGS
    _PIL_OK = True
except ImportError:  # pragma: no cover
    _PIL_OK = False


@dataclass
class ExifData:
    path: str
    datetime: str = ""            # "2021:07:14 18:33:02"
    camera_make: str = ""
    camera_model: str = ""
    gps_lat: float | None = None
    gps_lon: float | None = None
    tokens: list[str] = field(default_factory=list)


def _to_degrees(value) -> float:
    """Convert EXIF GPS rational (d, m, s) to decimal degrees."""
    d, m, s = (float(x) for x in value)
    return d + m / 60.0 + s / 3600.0


def _gps_from_ifd(gps_ifd: dict) -> tuple[float | None, float | None]:
    named = {GPSTAGS.get(k, k): v for k, v in gps_ifd.items()}
    lat = lon = None
    if "GPSLatitude" in named and "GPSLongitude" in named:
        lat = _to_degrees(named["GPSLatitude"])
        lon = _to_degrees(named["GPSLongitude"])
        if named.get("GPSLatitudeRef") == "S":
            lat = -lat
        if named.get("GPSLongitudeRef") == "W":
            lon = -lon
    return lat, lon


def extract_exif(path: str) -> ExifData:
    """Read EXIF from one image. Never raises — returns empty data on failure."""
    data = ExifData(path=path)
    if not _PIL_OK:
        return data
    try:
        img = Image.open(path)
        exif = img.getexif()
    except (OSError, ValueError, SyntaxError):
        return data
    if not exif:
        return data

    named = {TAGS.get(k, k): v for k, v in exif.items()}
    data.datetime = str(named.get("DateTime", "") or
                        named.get("DateTimeOriginal", "")).strip()
    data.camera_make = str(named.get("Make", "")).strip()
    data.camera_model = str(named.get("Model", "")).strip()

    # GPS lives in a sub-IFD
    try:
        gps_ifd = exif.get_ifd(0x8825)  # GPSInfo
        if gps_ifd:
            data.gps_lat, data.gps_lon = _gps_from_ifd(gps_ifd)
    except (KeyError, AttributeError, ValueError, TypeError):
        pass

    data.tokens = _tokens_from_exif(data)
    return data


def _tokens_from_exif(data: ExifData) -> list[str]:
    tokens: list[str] = []
    if data.datetime:
        # "2021:07:14 18:33:02" -> year 2021, 07, 14, 2107, 1407 ...
        date_part = data.datetime.split()[0]
        parts = date_part.replace("-", ":").split(":")
        if len(parts) == 3:
            y, m, d = parts
            tokens += [y, y[2:], m + d, d + m, y + m + d]
    if data.camera_make:
        tokens.append(data.camera_make.split()[0])
    if data.camera_model:
        tokens.append(data.camera_model.replace(" ", ""))
    # coordinates themselves rarely become passwords, but keep a coarse tag
    return [t for t in tokens if t]
