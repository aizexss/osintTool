"""Entity extraction from text: rule-based now, optional spaCy/HF later.

The rule layer needs no dependencies and already yields years, emails,
@handles, proper-noun runs (Latin + Cyrillic) and gazetteer interests.
A local spaCy or HF-transformers model, when installed, is layered on top
for proper PERSON / GPE / ORG tagging (multilingual, GPU-friendly).
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field

from .gazetteer import match_interests

# Latin + common Cyrillic letters; a "proper noun" is a capitalized run.
_CAP_WORD = r"[A-ZА-ЯЁ][a-zа-яё'’\-]{1,}"
_PROPER_RUN = re.compile(rf"{_CAP_WORD}(?:\s{_CAP_WORD}){{0,2}}")
_YEAR = re.compile(r"\b(?:19|20)\d{2}\b")
_EMAIL = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
_HANDLE = re.compile(r"@([A-Za-z0-9_.]{2,30})")
_DATE = re.compile(r"\b(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2,4})\b")

# proper-noun runs that are just platform chrome, not people/places
_PROPER_STOP = {
    "instagram", "facebook", "linkedin", "profile", "photos", "videos",
    "followers", "following", "log in", "sign up", "see photos",
}


@dataclass
class Entities:
    persons: list[str] = field(default_factory=list)
    locations: list[str] = field(default_factory=list)
    orgs: list[str] = field(default_factory=list)
    proper_nouns: list[str] = field(default_factory=list)  # unclassified runs
    years: list[str] = field(default_factory=list)
    emails: list[str] = field(default_factory=list)
    handles: list[str] = field(default_factory=list)
    interests: list[str] = field(default_factory=list)

    def all_tokens(self) -> list[str]:
        """Flat, de-duplicated token list for the password engine."""
        bag: list[str] = []
        for group in (self.persons, self.locations, self.orgs,
                      self.proper_nouns, self.years, self.handles,
                      self.interests):
            bag.extend(group)
        # split emails into local-part + domain-name
        for e in self.emails:
            local, _, domain = e.partition("@")
            bag.append(local)
            if domain:
                bag.append(domain.split(".")[0])
        seen: set[str] = set()
        out: list[str] = []
        for t in bag:
            t = t.strip()
            if len(t) < 2:
                continue
            key = t.lower()
            if key in seen:
                continue
            seen.add(key)
            out.append(t)
        return out


def _rule_based(text: str) -> Entities:
    ent = Entities()
    ent.years = list(dict.fromkeys(_YEAR.findall(text)))
    ent.emails = list(dict.fromkeys(_EMAIL.findall(text)))
    ent.handles = list(dict.fromkeys(_HANDLE.findall(text)))

    for m in _DATE.finditer(text):
        y = m.group(3)
        if len(y) == 4 and y not in ent.years:
            ent.years.append(y)

    runs: list[str] = []
    for m in _PROPER_RUN.finditer(text):
        run = m.group(0).strip()
        if run.lower() in _PROPER_STOP:
            continue
        runs.append(run)
    ent.proper_nouns = list(dict.fromkeys(runs))

    ent.interests = [term for term, _cat in match_interests(text)]
    return ent


# --------------------------------------------------------------------------- #
# Optional spaCy backend (lazy, graceful)
# --------------------------------------------------------------------------- #
_SPACY_NLP = None
_SPACY_TRIED = False


def _load_spacy():
    global _SPACY_NLP, _SPACY_TRIED
    if _SPACY_TRIED:
        return _SPACY_NLP
    _SPACY_TRIED = True
    model = os.environ.get("OSINT_SPACY_MODEL", "xx_ent_wiki_sm")
    try:
        import spacy
        _SPACY_NLP = spacy.load(model)
    except Exception:  # noqa: BLE001 — missing model/package is fine
        _SPACY_NLP = None
    return _SPACY_NLP


def _augment_with_spacy(text: str, ent: Entities) -> None:
    nlp = _load_spacy()
    if nlp is None:
        return
    doc = nlp(text[:100_000])
    for e in doc.ents:
        val = e.text.strip()
        if len(val) < 2:
            continue
        label = e.label_.upper()
        if label in ("PER", "PERSON"):
            ent.persons.append(val)
        elif label in ("LOC", "GPE"):
            ent.locations.append(val)
        elif label in ("ORG",):
            ent.orgs.append(val)
    ent.persons = list(dict.fromkeys(ent.persons))
    ent.locations = list(dict.fromkeys(ent.locations))
    ent.orgs = list(dict.fromkeys(ent.orgs))


def extract_entities(text: str, use_spacy: bool = True) -> Entities:
    """Extract entities from `text`. spaCy is used only if available."""
    ent = _rule_based(text or "")
    if use_spacy:
        _augment_with_spacy(text or "", ent)
    return ent
