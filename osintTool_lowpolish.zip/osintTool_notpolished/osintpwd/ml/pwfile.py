"""Extract a password list from an uploaded file (CSV / TXT / XLSX / DOCX).

Used by the web upload so a user can feed old/leaked passwords as a file
instead of pasting them. Tolerant: a 'password' column is used when present,
otherwise every non-empty cell/line is treated as a candidate password.
"""

from __future__ import annotations

import csv
import io

MAX_PASSWORDS = 20000


def _clean(pwds: list[str]) -> list[str]:
    out, seen = [], set()
    for p in pwds:
        p = (p or "").strip()
        if len(p) < 2 or p in seen:
            continue
        seen.add(p)
        out.append(p)
        if len(out) >= MAX_PASSWORDS:
            break
    return out


def _from_csv(data: bytes) -> list[str]:
    text = data.decode("utf-8", errors="replace")
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        return []
    header = [h.strip().lower() for h in rows[0]]
    if "password" in header:
        col = header.index("password")
        return _clean([r[col] for r in rows[1:] if len(r) > col])
    # no header column: take every cell (handles single-column and messy files)
    cells: list[str] = []
    for r in rows:
        cells.extend(r)
    return _clean(cells)


def _from_txt(data: bytes) -> list[str]:
    return _clean(data.decode("utf-8", errors="replace").splitlines())


def _from_xlsx(data: bytes) -> list[str]:
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    out: list[str] = []
    for ws in wb.worksheets:
        rows = ws.iter_rows(values_only=True)
        first = next(rows, None)
        if first is None:
            continue
        header = [str(c).strip().lower() if c is not None else "" for c in first]
        if "password" in header:
            col = header.index("password")
            out.extend(str(r[col]) for r in rows if len(r) > col and r[col] is not None)
        else:
            for c in first:
                if c is not None:
                    out.append(str(c))
            for r in rows:
                for c in r:
                    if c is not None:
                        out.append(str(c))
    return _clean(out)


def _from_docx(data: bytes) -> list[str]:
    import docx
    doc = docx.Document(io.BytesIO(data))
    lines = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                lines.append(cell.text)
    return _clean(lines)


def parse_passwords(filename: str, data: bytes) -> list[str]:
    """Dispatch by extension; fall back to plain-text line parsing."""
    name = (filename or "").lower()
    try:
        if name.endswith(".csv"):
            return _from_csv(data)
        if name.endswith((".xlsx", ".xlsm")):
            return _from_xlsx(data)
        if name.endswith(".docx"):
            return _from_docx(data)
        if name.endswith((".txt", ".lst", ".dic", "")):
            return _from_txt(data)
    except Exception:  # noqa: BLE001 — fall back to text
        pass
    return _from_txt(data)
