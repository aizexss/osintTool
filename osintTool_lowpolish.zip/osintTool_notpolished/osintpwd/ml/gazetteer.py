"""A seed gazetteer of common 'interest' terms people bake into passwords.

Tuned toward the CIS/Kazakhstan context (football, MMA, cars, pop culture).
It is deliberately small and editable — extend it for your own population.
Matching is case-insensitive and also matches the space-stripped form so
'Real Madrid' is caught in 'realmadrid'.
"""

from __future__ import annotations

# category -> set of canonical multi/one-word terms
GAZETTEER: dict[str, set[str]] = {
    "football_clubs": {
        "real madrid", "barcelona", "manchester united", "manchester city",
        "liverpool", "chelsea", "arsenal", "juventus", "bayern", "psg",
        "milan", "inter", "kairat", "astana", "zenit", "spartak", "cska",
    },
    "fighters": {
        "khabib", "nurmagomedov", "khamzat", "chimaev", "conor", "mcgregor",
        "islam", "makhachev", "jon jones", "shavkat", "usman", "ngannou",
    },
    "football_players": {
        "messi", "ronaldo", "cristiano", "neymar", "mbappe", "haaland",
        "zidane", "benzema", "modric",
    },
    "car_brands": {
        "toyota", "camry", "corolla", "landcruiser", "lexus", "bmw", "mercedes",
        "audi", "hyundai", "kia", "nissan", "honda", "mazda", "lada",
    },
    "tech_brands": {
        "apple", "iphone", "samsung", "galaxy", "xiaomi", "playstation", "xbox",
    },
    "pop": {
        "marvel", "batman", "spiderman", "pokemon", "naruto", "starwars",
        "gameofthrones", "harrypotter", "minecraft", "fortnite", "dota", "cska",
    },
}

# flattened lookup: normalized term -> category
_LOOKUP: dict[str, str] = {}
for _cat, _terms in GAZETTEER.items():
    for _t in _terms:
        _LOOKUP[_t.replace(" ", "").lower()] = _cat


def match_interests(text: str) -> list[tuple[str, str]]:
    """Return (term, category) pairs from the gazetteer found in `text`.

    Matches both spaced and concatenated forms.
    """
    haystack = text.lower()
    haystack_nospace = haystack.replace(" ", "")
    found: list[tuple[str, str]] = []
    seen: set[str] = set()
    for norm, cat in _LOOKUP.items():
        if norm in seen:
            continue
        # word-ish containment: present as a run in either normalized form
        if norm in haystack_nospace or norm in haystack.replace("-", ""):
            seen.add(norm)
            found.append((norm, cat))
    return found
