"""Adapter for the existing nomad_mvp face_recog output (loose coupling).

The face_recog module (InsightFace + ArcFace + HDBSCAN, run via its own
Docker/env) clusters face crops into `person_XXXX/` folders. We do NOT import
its heavy stack; we just READ its `output/` folder to answer one question the
password tool cares about:

    "Do these downloaded profile photos belong to the SAME person?"

Workflow:
    1. discovery downloads candidate og:images named `<platform>_<handle>.jpg`
    2. analyst drops them into face_recog/photos and runs that pipeline
    3. we read output/ and check whether the crops from those files landed
       in one identity cluster -> the profiles are confirmed as one person.

Crop filenames are `<source_stem>_face<N>.jpg`; checkpoint.json lists the
processed source photo paths.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field

_FACE_SUFFIX = re.compile(r"_face\d+$", re.IGNORECASE)


def _crop_to_source_stem(crop_filename: str) -> str:
    """`abc123_face0.jpg` -> `abc123` (the source photo's stem)."""
    stem = os.path.splitext(crop_filename)[0]
    return _FACE_SUFFIX.sub("", stem)


@dataclass
class IdentityReport:
    clusters: dict[str, list[str]] = field(default_factory=dict)   # cluster -> source stems
    stem_to_cluster: dict[str, str] = field(default_factory=dict)  # source stem -> cluster
    available: bool = False

    def cluster_of(self, filename: str) -> str | None:
        """Cluster for a downloaded file like 'instagram_asik.jpg'."""
        stem = _crop_to_source_stem(os.path.basename(filename))
        # match by stem prefix (source stem may include our platform_handle)
        if stem in self.stem_to_cluster:
            return self.stem_to_cluster[stem]
        for s, c in self.stem_to_cluster.items():
            if s.startswith(stem) or stem.startswith(s):
                return c
        return None

    def same_person(self, filenames: list[str]) -> tuple[bool, dict[str, str | None]]:
        """True if every given file maps to the same (non-None) cluster."""
        mapping = {f: self.cluster_of(f) for f in filenames}
        clusters = {c for c in mapping.values() if c}
        return (len(clusters) == 1 and None not in mapping.values()), mapping


def read_identity(output_dir: str) -> IdentityReport:
    """Read a face_recog output/ folder into an IdentityReport. Never raises."""
    report = IdentityReport()
    clusters_dir = os.path.join(output_dir, "clusters")
    if not os.path.isdir(clusters_dir):
        return report

    for entry in os.listdir(clusters_dir):
        cdir = os.path.join(clusters_dir, entry)
        if not os.path.isdir(cdir) or entry.startswith("noise"):
            continue
        stems: list[str] = []
        for crop in os.listdir(cdir):
            if crop.lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
                stem = _crop_to_source_stem(crop)
                stems.append(stem)
                report.stem_to_cluster.setdefault(stem, entry)
        if stems:
            report.clusters[entry] = sorted(set(stems))

    report.available = bool(report.clusters)
    return report


def stats(output_dir: str) -> dict:
    """Return cluster_stats.json if present (n_clusters, sizes...)."""
    path = os.path.join(output_dir, "cluster_stats.json")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError):
        return {}
