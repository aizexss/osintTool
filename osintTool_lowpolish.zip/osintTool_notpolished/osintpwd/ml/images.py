"""Image understanding: object tags and faces (optional, GPU-friendly).

EXIF/GPS (see exif.py) is the cheap, always-on signal. Object detection and
face analysis need heavy models, so they are optional and lazily loaded:

    object tagging  -> ultralytics YOLO  (pip install ultralytics)
    face detection  -> insightface / face_recognition (optional)

Without those packages these functions return empty results — the pipeline
degrades gracefully and still uses EXIF + text NER.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# COCO object classes -> coarse interest hint feeding the password profile.
_COCO_TO_HINT = {
    "dog": "dog", "cat": "cat", "horse": "horse", "bird": "bird",
    "car": "car", "motorcycle": "moto", "bicycle": "bike",
    "sports ball": "football", "skateboard": "skate", "surfboard": "surf",
    "snowboard": "snowboard", "skis": "ski", "guitar": "guitar",
    "tennis racket": "tennis", "baseball glove": "baseball",
}


@dataclass
class ImageTags:
    path: str
    objects: list[str] = field(default_factory=list)   # raw detected labels
    hints: list[str] = field(default_factory=list)      # mapped interest hints
    n_faces: int = 0


_YOLO_MODEL = None
_YOLO_TRIED = False


def _load_yolo():
    global _YOLO_MODEL, _YOLO_TRIED
    if _YOLO_TRIED:
        return _YOLO_MODEL
    _YOLO_TRIED = True
    try:
        from ultralytics import YOLO
        _YOLO_MODEL = YOLO("yolov8n.pt")  # nano; auto-downloads once
    except Exception:  # noqa: BLE001
        _YOLO_MODEL = None
    return _YOLO_MODEL


def detect_objects(path: str, conf: float = 0.35) -> ImageTags:
    """Detect objects in an image; empty result if YOLO is unavailable."""
    tags = ImageTags(path=path)
    model = _load_yolo()
    if model is None:
        return tags
    try:
        results = model(path, conf=conf, verbose=False)
    except Exception:  # noqa: BLE001
        return tags
    labels: list[str] = []
    for r in results:
        names = r.names
        for c in r.boxes.cls.tolist() if r.boxes is not None else []:
            labels.append(names[int(c)])
    tags.objects = list(dict.fromkeys(labels))
    tags.n_faces = tags.objects.count("person")  # coarse; real faces below
    tags.hints = list(dict.fromkeys(
        _COCO_TO_HINT[o] for o in tags.objects if o in _COCO_TO_HINT
    ))
    return tags


def is_object_detection_available() -> bool:
    return _load_yolo() is not None
