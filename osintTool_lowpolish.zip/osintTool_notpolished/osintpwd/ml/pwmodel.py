"""Neural password-guessability scorer (PoE + MTL char-LSTM).

Ports the exact preprocessing + architecture from the training notebook
(`password_poe_mtl`) so the trained weights load and score passwords. The
model is a Product-of-Experts, multi-task, character-level LSTM with LoRA
adapters fine-tuned on personal passwords. It answers a DIFFERENT question
from the rule-based evaluator:

    evaluator.py  -> "does this password contain the target's personal info?"
    pwmodel.py    -> "how structurally guessable / low-entropy is it?"

Scoring returns average negative log-probability (lower = easier to guess),
converted to bits of entropy and an estimated guess count.

Requires torch. Loads lazily; if torch or the weights are missing, the
scorer reports unavailable and callers fall back to the rule engine.
"""

from __future__ import annotations

import io
import math
import os
import string
import zipfile
from dataclasses import dataclass

# --------------------------------------------------------------------------- #
# Preprocessing — must match the training notebook EXACTLY (vocab order etc.)
# --------------------------------------------------------------------------- #
MAX_LEN = 48

LEET_MAP = {
    '0': 'o', '1': 'i', '!': 'i', '3': 'e', '4': 'a', '@': 'a', '$': 's',
    '5': 's', '7': 't', '8': 'b', '€': 'e', '£': 'l', '¥': 'y', '§': 's',
}
for _k, _v in list(LEET_MAP.items()):
    LEET_MAP[_k.upper()] = _v.lower()

CLASS_TO_ID = {'L': 0, 'U': 1, 'D': 2, 'S': 3}


def char_class(c: str) -> int:
    if c.islower():
        return 0
    if c.isupper():
        return 1
    if c.isdigit():
        return 2
    return 3


def canonical_letter(c: str):
    base = LEET_MAP.get(c, c).lower()
    return base if base in string.ascii_lowercase else None


GROUP_TO_ID = {'<none>': 0}
for _i, _ch in enumerate(string.ascii_lowercase, start=1):
    GROUP_TO_ID[_ch] = _i


def group_id_of_char(c: str) -> int:
    can = canonical_letter(c)
    return GROUP_TO_ID[can] if can else 0


BASE_CHARS = set(
    'abcdefghijklmnopqrstuvwxyz'
    'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    '0123456789!@#$%^&*()-_=+[]{}|;:,.<>?/\\'
)
char_to_idx = {ch: i + 1 for i, ch in enumerate(sorted(BASE_CHARS))}
PAD = '<PAD>'
UNK = '<UNK>'
char_to_idx[PAD] = 0
char_to_idx[UNK] = max(char_to_idx.values()) + 1
idx_to_char = {v: k for k, v in char_to_idx.items()}
VOCAB_SIZE = max(char_to_idx.values()) + 1  # 92


# --------------------------------------------------------------------------- #
# Model (ported from the notebook)
# --------------------------------------------------------------------------- #
def _build_model(use_adapters: bool = True):
    import torch.nn as nn

    class Adapter(nn.Module):
        def __init__(self, hidden_dim, bottleneck=64):
            super().__init__()
            self.down = nn.Linear(hidden_dim, bottleneck)
            self.act = nn.ReLU()
            self.up = nn.Linear(bottleneck, hidden_dim)

        def forward(self, x):
            return x + self.up(self.act(self.down(x)))

    class PoEPasswordMTL(nn.Module):
        def __init__(self, vocab_size, embedding_dim=128, hidden_dim=256,
                     num_layers=2, num_groups=27, num_classes=4, max_len=48,
                     poe_alpha=1.0, use_adapters=False, dropout=0.2):
            super().__init__()
            self.max_len = max_len
            self.poe_alpha = poe_alpha
            self.char_emb = nn.Embedding(vocab_size, embedding_dim,
                                         padding_idx=char_to_idx[PAD])
            self.group_emb = nn.Embedding(num_groups, 16)
            self.class_emb = nn.Embedding(num_classes, 8)
            self.pos_emb = nn.Embedding(max_len, 16)
            fused = embedding_dim + 16 + 8 + 16
            self.raw_lstm = nn.LSTM(fused, hidden_dim, num_layers=num_layers,
                                    batch_first=True, dropout=dropout)
            self.canon_lstm = nn.LSTM(fused, hidden_dim, num_layers=num_layers,
                                      batch_first=True, dropout=dropout)
            if use_adapters:
                self.adapt_raw = Adapter(hidden_dim, 64)
                self.adapt_canon = Adapter(hidden_dim, 64)
            else:
                self.adapt_raw = nn.Identity()
                self.adapt_canon = nn.Identity()
            self.head_char_raw = nn.Linear(hidden_dim, vocab_size)
            self.head_char_canon = nn.Linear(hidden_dim, vocab_size)
            self.head_next_canon = nn.Linear(hidden_dim, 27)
            self.head_next_class = nn.Linear(hidden_dim, 4)

        def _fuse(self, chars, groups, classes, pos):
            import torch
            return torch.cat([self.char_emb(chars), self.group_emb(groups),
                              self.class_emb(classes), self.pos_emb(pos)], dim=-1)

        def forward(self, batch):
            x_raw = self._fuse(batch['raw'], batch['group'], batch['class'], batch['pos'])
            x_canon = self._fuse(batch['canon'], batch['group'], batch['class'], batch['pos'])
            raw_out, _ = self.raw_lstm(x_raw)
            canon_out, _ = self.canon_lstm(x_canon)
            raw_out = self.adapt_raw(raw_out)
            canon_out = self.adapt_canon(canon_out)
            logits_raw = self.head_char_raw(raw_out)
            logits_canon = self.head_char_canon(canon_out)
            return {'logits_char_poe': logits_raw + self.poe_alpha * logits_canon}

    return PoEPasswordMTL(VOCAB_SIZE, use_adapters=use_adapters)


def _load_state_dict(path: str):
    """torch.load a .pth whether it's a real zip file or an extracted dir."""
    import torch
    if os.path.isdir(path):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_STORED) as z:
            for dp, _, fs in os.walk(path):
                for f in fs:
                    full = os.path.join(dp, f)
                    z.write(full, os.path.relpath(full, path))
        buf.seek(0)
        return torch.load(buf, map_location='cpu', weights_only=True)
    return torch.load(path, map_location='cpu', weights_only=True)


@dataclass
class Score:
    avg_neg_logp: float
    bits: float
    guesses: float


class PasswordScorer:
    """Loads the trained model and scores password guessability."""

    def __init__(self, model_path: str):
        self.model_path = model_path
        self._model = None
        self._ok = None

    def available(self) -> bool:
        if self._ok is not None:
            return self._ok
        try:
            import torch  # noqa: F401
            self._model = _build_model(use_adapters=True)
            state = _load_state_dict(self.model_path)
            self._model.load_state_dict(state, strict=True)
            self._model.eval()
            self._ok = True
        except Exception:  # noqa: BLE001
            self._ok = False
        return self._ok

    def score_batch(self, pwds: list[str], batch_size: int = 512) -> list[float | None]:
        """Average neg-log-prob for many passwords (batched, fast). None for
        entries too short. Order matches the input."""
        if not self.available():
            return [None] * len(pwds)
        import torch

        out: list[float | None] = [None] * len(pwds)

        def pad(x, fill):
            return x + [fill] * (MAX_LEN - len(x)) if len(x) < MAX_LEN else x[:MAX_LEN]

        for start in range(0, len(pwds), batch_size):
            chunk = pwds[start:start + batch_size]
            idxs, R, C, CL, G, lens = [], [], [], [], [], []
            for j, pwd in enumerate(chunk):
                if len(pwd) < 2:
                    continue
                raw = [char_to_idx.get(c, char_to_idx[UNK]) for c in pwd]
                cls = [char_class(c) for c in pwd]
                grp = [group_id_of_char(c) for c in pwd]
                canon_chars = [canonical_letter(c) or c for c in pwd]
                canon = [char_to_idx.get(c, char_to_idx[UNK]) for c in canon_chars]
                idxs.append(start + j)
                R.append(pad(raw, char_to_idx[PAD]))
                C.append(pad(canon, char_to_idx[PAD]))
                CL.append(pad(cls, CLASS_TO_ID['S']))
                G.append(pad(grp, 0))
                lens.append(min(len(raw), MAX_LEN))
            if not idxs:
                continue
            B = len(idxs)
            batch = {
                'raw': torch.tensor(R), 'canon': torch.tensor(C),
                'class': torch.tensor(CL), 'group': torch.tensor(G),
                'pos': torch.tensor([list(range(MAX_LEN))] * B),
            }
            with torch.no_grad():
                logits = self._model(batch)['logits_char_poe']
                logp = torch.log_softmax(logits, dim=-1)
            for row, (gi, L) in enumerate(zip(idxs, lens)):
                if L < 2:
                    continue
                tgt = torch.tensor(R[row][1:L])
                lp = logp[row, torch.arange(L - 1), tgt]
                out[gi] = float(-(lp.mean().item()))
        return out

    def score(self, pwd: str) -> Score | None:
        """Average negative log-prob of the password (lower = easier). None if
        too short or the model is unavailable."""
        if not self.available() or len(pwd) < 2:
            return None
        import torch

        raw = [char_to_idx.get(c, char_to_idx[UNK]) for c in pwd]
        cls = [char_class(c) for c in pwd]
        grp = [group_id_of_char(c) for c in pwd]
        canon_chars = [canonical_letter(c) or c for c in pwd]
        canon = [char_to_idx.get(c, char_to_idx[UNK]) for c in canon_chars]

        def pad(x, fill):
            return x + [fill] * (MAX_LEN - len(x)) if len(x) < MAX_LEN else x[:MAX_LEN]

        batch = {
            'raw': torch.tensor([pad(raw, char_to_idx[PAD])]),
            'canon': torch.tensor([pad(canon, char_to_idx[PAD])]),
            'class': torch.tensor([pad(cls, CLASS_TO_ID['S'])]),
            'group': torch.tensor([pad(grp, 0)]),
            'pos': torch.tensor([list(range(MAX_LEN))]),
        }
        with torch.no_grad():
            out = self._model(batch)
        logits = out['logits_char_poe'][0][:len(raw) - 1]
        probs = torch.softmax(logits, dim=-1)
        t = torch.tensor(raw[1:], dtype=torch.long)
        chosen = probs[torch.arange(len(t)), t]
        avg_nll = float(-(torch.log(chosen + 1e-12).mean().item()))
        bits = avg_nll / math.log(2)
        return Score(avg_neg_logp=round(avg_nll, 4),
                     bits=round(bits, 2),
                     guesses=round(2 ** bits, 1))


# module-level singleton, path resolved lazily
_DEFAULT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "personal_adapted_poe_mtl.pth",
)
_SCORER: PasswordScorer | None = None


def get_scorer(path: str | None = None) -> PasswordScorer:
    global _SCORER
    if _SCORER is None or path is not None:
        _SCORER = PasswordScorer(path or _DEFAULT_PATH)
    return _SCORER
