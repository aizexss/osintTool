"""Local ML / enrichment layer — runs entirely on this machine.

Nothing here calls a cloud API: employee photos and posts never leave the
host. Given text (from the discovery layer) and local image files, it
extracts the person-specific signals that weak passwords are built from —
names, dates, places, interests, pets, geotags — and folds them into a
Profile the offline password engine consumes.

Heavy models (spaCy, HF transformers, YOLO, face recognition) are optional
and lazily loaded; without them the rule-based paths still produce useful
signals. EXIF/GPS extraction needs only Pillow.
"""

from .enricher import enrich_profile, EnrichmentResult
from .exif import extract_exif
from .ner import extract_entities

__all__ = [
    "enrich_profile",
    "EnrichmentResult",
    "extract_exif",
    "extract_entities",
]
