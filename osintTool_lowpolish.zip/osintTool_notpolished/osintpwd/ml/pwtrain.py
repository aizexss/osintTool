"""Fine-tune the password model on a user's own passwords → behavioural model.

Reuses the pretrained backbone baked into `personal_adapted_poe_mtl.pth`,
resets the LoRA adapters, freezes the backbone, and trains the adapters +
output heads on the uploaded passwords — exactly the personalisation stage
from the training notebook, minus the base pretrain (backbone is reused).

Result: a model tuned to THAT person's password style. Low avg_neg_logp
then means "matches how this person builds passwords".

Ported preprocessing/loss from `password_poe_mtl` so encodings match the
weights. Needs torch (CPU is fine for a few hundred passwords).
"""

from __future__ import annotations

from .pwmodel import (
    CLASS_TO_ID, MAX_LEN, PAD, canonical_letter, char_class, char_to_idx,
    group_id_of_char, idx_to_char, _build_model, _load_state_dict,
)

_BACKBONE_PREFIXES = ("char_emb", "group_emb", "class_emb", "pos_emb",
                      "raw_lstm", "canon_lstm")


def _canon_id(c: str) -> int:
    can = canonical_letter(c)
    return 1 + (ord(can) - ord('a')) if can else 0


def _encode(pwd: str):
    raw = [char_to_idx.get(c, char_to_idx['<UNK>']) for c in pwd]
    cls = [char_class(c) for c in pwd]
    grp = [group_id_of_char(c) for c in pwd]
    canon_chars = [canonical_letter(c) or c for c in pwd]
    canon = [char_to_idx.get(c, char_to_idx['<UNK>']) for c in canon_chars]
    return raw, canon, cls, grp


def _pad(xs, fill):
    return xs[:MAX_LEN] + [fill] * (MAX_LEN - len(xs)) if len(xs) < MAX_LEN else xs[:MAX_LEN]


def _make_batch(pwds, torch):
    R, C, CL, G, P, TC, MK = [], [], [], [], [], [], []
    for pwd in pwds:
        raw, canon, cls, grp = _encode(pwd)
        tgt_char = raw[1:] + [char_to_idx[PAD]]
        R.append(_pad(raw, char_to_idx[PAD]))
        C.append(_pad(canon, char_to_idx[PAD]))
        CL.append(_pad(cls, CLASS_TO_ID['S']))
        G.append(_pad(grp, 0))
        P.append(list(range(MAX_LEN)))
        TC.append(_pad(tgt_char, char_to_idx[PAD]))
        MK.append([1] * min(len(raw), MAX_LEN) + [0] * max(0, MAX_LEN - len(raw)))
    t = lambda x: torch.tensor(x)  # noqa: E731
    return {'raw': t(R), 'canon': t(C), 'class': t(CL), 'group': t(G),
            'pos': t(P), 'tgt_char': t(TC),
            'mask': torch.tensor(MK, dtype=torch.float32)}


def _reset_adapters(model):
    """Fresh adapters so we don't inherit the previous person's style."""
    import torch.nn as nn
    for adp in (model.adapt_raw, model.adapt_canon):
        if isinstance(adp, nn.Identity):
            continue
        nn.init.kaiming_uniform_(adp.down.weight, a=5 ** 0.5)
        nn.init.zeros_(adp.down.bias)
        nn.init.zeros_(adp.up.weight)   # start as identity (residual)
        nn.init.zeros_(adp.up.bias)


def fine_tune(passwords: list[str], base_model_path: str, out_path: str,
              epochs: int = 40, lr: float = 3e-3, batch_size: int = 64,
              progress=None) -> dict:
    """Train a personal model on `passwords`. Returns a small history dict.

    `progress(epoch, loss)` is called each epoch if provided.
    """
    import torch

    pwds = [str(p).strip() for p in passwords if str(p).strip() and len(str(p).strip()) >= 2]
    if len(pwds) < 3:
        raise ValueError("need at least 3 passwords to fit a behavioural model")

    model = _build_model(use_adapters=True)
    state = _load_state_dict(base_model_path)
    model.load_state_dict(state, strict=False)   # reuse backbone + heads
    _reset_adapters(model)

    # freeze backbone; train adapters + heads
    for name, p in model.named_parameters():
        p.requires_grad = not any(name.startswith(pref) for pref in _BACKBONE_PREFIXES)
    trainable = [p for p in model.parameters() if p.requires_grad]

    opt = torch.optim.AdamW(trainable, lr=lr, weight_decay=1e-4)
    ce = torch.nn.CrossEntropyLoss(reduction='none')
    model.train()

    history = {"loss": [], "n": len(pwds), "trainable": sum(p.numel() for p in trainable)}
    import random
    for epoch in range(1, epochs + 1):
        random.shuffle(pwds)
        total, nb = 0.0, 0
        for i in range(0, len(pwds), batch_size):
            batch = _make_batch(pwds[i:i + batch_size], torch)
            opt.zero_grad(set_to_none=True)
            out = model(batch)
            logits = out['logits_char_poe']
            B, T, V = logits.shape
            loss_all = ce(logits.reshape(B * T, V), batch['tgt_char'].reshape(B * T))
            m = batch['mask'].reshape(B * T)
            loss = (loss_all * m).sum() / (m.sum() + 1e-8)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 1.0)
            opt.step()
            total += float(loss.item()); nb += 1
        avg = total / max(nb, 1)
        history["loss"].append(round(avg, 4))
        if progress:
            progress(epoch, avg)

    model.eval()
    torch.save(model.state_dict(), out_path)
    history["out_path"] = out_path
    return history
