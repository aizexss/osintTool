"""Merge ML signals (text NER + image EXIF/objects) into a Profile.

Input: raw public text (from discovery) plus optional local image paths.
Output: a Profile whose structured fields and `custom`/`interests` are
populated with the person-specific tokens weak passwords are built from.
"""

from __future__ import annotations

import glob
import os
from dataclasses import dataclass, field

from ..models import Profile
from .exif import extract_exif
from .images import detect_objects
from .ner import extract_entities


@dataclass
class EnrichmentResult:
    profile: Profile
    interests: list[str] = field(default_factory=list)
    proper_nouns: list[str] = field(default_factory=list)
    years: list[str] = field(default_factory=list)
    geo: list[tuple[float, float]] = field(default_factory=list)
    image_hints: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


def _iter_images(image_dir: str | None, image_paths: list[str] | None):
    seen: set[str] = set()
    if image_paths:
        for p in image_paths:
            if p not in seen:
                seen.add(p)
                yield p
    if image_dir and os.path.isdir(image_dir):
        for ext in ("jpg", "jpeg", "png", "tif", "tiff", "heic", "webp"):
            for p in glob.glob(os.path.join(image_dir, f"**/*.{ext}"),
                               recursive=True):
                if p not in seen:
                    seen.add(p)
                    yield p


def _merge(dst: list[str], src: list[str], seen: set[str]) -> None:
    for x in src:
        k = x.strip().lower()
        if k and k not in seen:
            seen.add(k)
            dst.append(x.strip())


def enrich_profile(
    base: Profile | None = None,
    text: str = "",
    image_dir: str | None = None,
    image_paths: list[str] | None = None,
    use_spacy: bool = True,
    use_objects: bool = False,
) -> EnrichmentResult:
    """Build/augment a Profile from text and images. Never raises."""
    profile = base or Profile()
    result = EnrichmentResult(profile=profile)

    # --- text ---
    if text:
        ent = extract_entities(text, use_spacy=use_spacy)
        result.interests = ent.interests
        result.proper_nouns = (ent.persons + ent.locations + ent.orgs
                               + ent.proper_nouns)
        result.years = ent.years
        if ent.persons or ent.locations:
            result.notes.append("spaCy entities used")

    # --- images ---
    geo_tokens: list[str] = []
    for path in _iter_images(image_dir, image_paths):
        ex = extract_exif(path)
        geo_tokens.extend(ex.tokens)
        if ex.gps_lat is not None and ex.gps_lon is not None:
            result.geo.append((ex.gps_lat, ex.gps_lon))
        if use_objects:
            tags = detect_objects(path)
            _merge(result.image_hints, tags.hints, set(result.image_hints))

    # --- fold everything into the profile ---
    seen = {t.lower() for t in profile.base_tokens()}

    new_interests: list[str] = []
    _merge(new_interests, result.interests, set(i.lower() for i in profile.interests))
    _merge(new_interests, result.image_hints, set(i.lower() for i in new_interests))
    profile.interests = list(profile.interests) + new_interests

    new_custom: list[str] = list(profile.custom)
    seen_custom = {c.lower() for c in new_custom}
    _merge(new_custom, result.proper_nouns, seen_custom)
    _merge(new_custom, geo_tokens, seen_custom)
    profile.custom = new_custom

    for y in result.years:
        try:
            yi = int(y)
            if yi not in profile.significant_years:
                profile.significant_years.append(yi)
        except ValueError:
            pass

    if result.geo:
        result.notes.append(f"{len(result.geo)} geotagged photo(s)")
    return result
