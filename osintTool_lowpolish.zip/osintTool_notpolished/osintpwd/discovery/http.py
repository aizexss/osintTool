"""A polite, resilient HTTP client shared across the discovery layer.

Browser-like headers, a global minimum interval between requests (be a good
citizen and avoid trivial rate-limit bans), and bounded retries with backoff
on 429 / 5xx. Everything degrades gracefully — callers get None on failure
rather than an exception tearing down a whole run.
"""

from __future__ import annotations

import threading
import time
import ipaddress
import socket
from urllib.parse import urljoin, urlsplit

import httpx

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,ru;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "DNT": "1",
    "Upgrade-Insecure-Requests": "1",
}


def _public_url_error(url: str) -> str:
    """Reject local/private destinations before opening a public document.

    Every DNS answer must be globally routable. This preflight is repeated for
    redirects; it is not DNS pinning and does not claim rebinding protection.
    Search backend calls intentionally do not use this restriction (a configured
    SearXNG service can legitimately be local).
    """
    try:
        if not isinstance(url, str) or any(ord(ch) < 32 or ord(ch) == 127 for ch in url):
            return "public_url_invalid"
        parsed = urlsplit(url)
        host = (parsed.hostname or "").rstrip(".").lower()
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        if parsed.scheme not in ("http", "https") or not host:
            return "public_url_invalid"
        if parsed.username is not None or parsed.password is not None:
            return "public_url_credentials_not_allowed"
        if host == "localhost" or host.endswith((".localhost", ".local")) or "%" in host:
            return "public_target_not_global"
        try:
            addresses = [ipaddress.ip_address(host)]
        except ValueError:
            answers = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            addresses = [ipaddress.ip_address(answer[4][0]) for answer in answers]
        if not addresses:
            return "public_dns_unavailable"
        for address in addresses:
            address = getattr(address, "ipv4_mapped", None) or address
            if (not address.is_global or address.is_multicast or address.is_reserved
                    or getattr(address, "is_site_local", False)):
                return "public_target_not_global"
        return ""
    except (OSError, ValueError, UnicodeError):
        return "public_dns_or_url_invalid"


def _public_error(reason: str, status: int = 400) -> httpx.Response:
    # No source URL, exception text, headers or credentials are reflected.
    return httpx.Response(status, extensions={"read_error": reason})


class PoliteClient:
    """Thin wrapper over httpx.Client with rate limiting and retries."""

    def __init__(
        self,
        min_interval: float = 1.5,
        timeout: float = 20.0,
        max_retries: int = 3,
        headers: dict | None = None,
    ) -> None:
        self.min_interval = min_interval
        self.max_retries = max_retries
        self._last_request = 0.0
        # httpx.Client is thread-safe for requests; the throttle spacing is not,
        # so guard it — the pipeline fans several searches out across threads.
        self._throttle_lock = threading.Lock()
        self._client = httpx.Client(
            headers=headers or DEFAULT_HEADERS,
            timeout=timeout,
            follow_redirects=True,
            http2=True,
        )

    def _throttle(self) -> None:
        # Serialize the spacing so concurrent callers still keep min_interval
        # apart (each thread sleeps until its own slot), never bursting.
        with self._throttle_lock:
            elapsed = time.monotonic() - self._last_request
            wait = self.min_interval - elapsed
            now = time.monotonic() + (wait if wait > 0 else 0.0)
            self._last_request = now
        if wait > 0:
            time.sleep(wait)

    def get(self, url: str, **kwargs) -> httpx.Response | None:
        return self._request("GET", url, **kwargs)

    def get_public(self, url: str, max_bytes: int = 2 * 1024 * 1024,
                   **kwargs) -> httpx.Response:
        """Stream a public document with a byte cap and at most five redirects.

        Public page reads make one request per hop; backend requests keep the
        existing retry policy. A failure response has a sanitized ``read_error``
        extension. The decoded body is checked while streaming, before it is
        collected into one bytes object, including when Content-Length is absent
        or inaccurate. ``get`` remains available for configured backend URLs.
        """
        if not isinstance(max_bytes, int) or max_bytes <= 0:
            return _public_error("public_byte_limit_invalid")
        current = url
        request_options = dict(kwargs)
        request_options.pop("follow_redirects", None)
        for hop in range(6):
            reason = _public_url_error(current)
            if reason:
                return _public_error(reason)
            self._throttle()
            try:
                with self._client.stream("GET", current, follow_redirects=False,
                                         **request_options) as response:
                    if response.status_code in (301, 302, 303, 307, 308):
                        location = response.headers.get("location")
                        if not location:
                            return _public_error("public_redirect_missing_location", 502)
                        if hop == 5:
                            return _public_error("public_redirect_limit", 508)
                        current = urljoin(str(response.url), location)
                        # Query parameters supplied by a caller belong only to
                        # the initial URL, not every redirect destination.
                        request_options.pop("params", None)
                        continue
                    if response.status_code >= 400:
                        return httpx.Response(response.status_code,
                                              extensions={"read_error": f"HTTP {response.status_code}"})
                    length = response.headers.get("content-length", "")
                    if length.isdigit() and int(length) > max_bytes:
                        return _public_error("public_document_too_large", 413)
                    chunks: list[bytes] = []
                    size = 0
                    for chunk in response.iter_bytes(chunk_size=min(64 * 1024, max_bytes + 1)):
                        size += len(chunk)
                        if size > max_bytes:
                            return _public_error("public_document_too_large", 413)
                        chunks.append(chunk)
                    headers = dict(response.headers)
                    # iter_bytes has already decompressed the body. Removing
                    # transfer encodings prevents a second decode by Response.
                    headers.pop("content-encoding", None)
                    headers.pop("transfer-encoding", None)
                    headers["content-length"] = str(size)
                    return httpx.Response(response.status_code, headers=headers,
                                          content=b"".join(chunks), request=response.request,
                                          extensions=dict(response.extensions))
            except (httpx.HTTPError, httpx.InvalidURL, OSError, ValueError, UnicodeError):
                return _public_error("public_request_failed", 502)
        return _public_error("public_redirect_limit", 508)

    def post(self, url: str, **kwargs) -> httpx.Response | None:
        return self._request("POST", url, **kwargs)

    def _request(self, method: str, url: str, *, request_attempts: int | None = None,
                 **kwargs) -> httpx.Response | None:
        # A fragile optional provider can opt out of retries without changing
        # the shared client's policy for other search engines.
        attempts = self.max_retries if request_attempts is None else request_attempts
        backoff = 2.0
        for attempt in range(1, attempts + 1):
            self._throttle()
            try:
                resp = self._client.request(method, url, **kwargs)
            except httpx.HTTPError:
                if attempt == attempts:
                    return None
                time.sleep(backoff)
                backoff *= 2
                continue

            if resp.status_code in (429, 500, 502, 503, 504):
                if attempt == attempts:
                    return resp
                time.sleep(backoff)
                backoff *= 2
                continue
            return resp
        return None

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "PoliteClient":
        return self

    def __exit__(self, *exc) -> None:
        self.close()
