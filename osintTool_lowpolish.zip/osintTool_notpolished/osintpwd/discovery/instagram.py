"""Instagram enrichment via Instaloader with an authenticated session.

Anonymous Instagram access is blocked, so reading a public profile's bio and
recent post captions requires a logged-in session. Use a THROWAWAY / burner
account — Instagram may flag or ban accounts used for automated reading; never
use a personal account.

Auth flow (password never touches this tool's callers or logs):
    python -m osintpwd ig-login <burner_username>
        -> prompts for the password locally (getpass), logs in once,
           saves a reusable session file under the session dir.
Later, enrichment loads that saved session by username (env IG_USERNAME) —
no password needed again until the session expires.

`max_connection_attempts=1` makes calls fail FAST instead of hanging on IG's
anti-bot rate limiting.
"""

from __future__ import annotations

import os

# session files live here; override with IG_SESSION_DIR
DEFAULT_SESSION_DIR = os.path.join(
    os.environ.get("APPDATA") or os.path.expanduser("~"),
    "osintpwd", "ig_sessions",
)


def _session_path(username: str, session_dir: str | None = None) -> str:
    d = session_dir or os.environ.get("IG_SESSION_DIR") or DEFAULT_SESSION_DIR
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, f"session-{username}")


def _new_loader():
    import instaloader
    return instaloader.Instaloader(
        quiet=True,
        download_pictures=False, download_videos=False,
        download_video_thumbnails=False, download_geotags=False,
        download_comments=False, save_metadata=False, compress_json=False,
        max_connection_attempts=1,           # fail fast, never hang
    )


def login_and_save(username: str, password: str,
                   session_dir: str | None = None) -> str:
    """Log in once and persist the session. Returns the session file path.

    Raises instaloader exceptions on bad credentials / checkpoint challenges.
    """
    loader = _new_loader()
    loader.login(username, password)
    path = _session_path(username, session_dir)
    loader.save_session_to_file(path)
    return path


def load_loader(username: str | None = None, session_dir: str | None = None):
    """Return an Instaloader with a saved session, or None if unavailable."""
    username = username or os.environ.get("IG_USERNAME", "")
    if not username:
        return None
    path = _session_path(username, session_dir)
    if not os.path.exists(path):
        return None
    try:
        loader = _new_loader()
        loader.load_session_from_file(username, path)
        return loader
    except Exception:  # noqa: BLE001 — expired/invalid session -> unavailable
        return None


def session_available(username: str | None = None) -> bool:
    username = username or os.environ.get("IG_USERNAME", "")
    return bool(username) and os.path.exists(_session_path(username))


def fetch_profile_text(handle: str, loader=None, max_posts: int = 6) -> dict:
    """Fetch a public IG profile's text via an authed session.

    Returns {ok, text, full_name, followers, n_captions, error}. Never raises;
    a missing session or a private/blocked profile comes back as ok=False.
    """
    import itertools

    result = {"ok": False, "text": "", "full_name": "", "followers": 0,
              "n_captions": 0, "error": ""}
    loader = loader or load_loader()
    if loader is None:
        result["error"] = "no IG session (run: python -m osintpwd ig-login <user>)"
        return result

    try:
        import instaloader
        profile = instaloader.Profile.from_username(loader.context, handle)
    except Exception as e:  # noqa: BLE001
        msg = str(e)
        if "429" in msg or "Too Many Requests" in msg:
            result["error"] = ("IG rate-limited this burner (429) — the account "
                               "is fresh/flagged; warm it up (use it normally in "
                               "the app a few days) or use another")
        elif "401" in msg or "login" in msg.lower():
            result["error"] = "IG session expired — re-run: python -m osintpwd ig-login"
        else:
            result["error"] = f"profile fetch failed: {type(e).__name__}"
        return result

    parts: list[str] = []
    result["full_name"] = profile.full_name or ""
    result["followers"] = profile.followers
    if profile.full_name:
        parts.append(profile.full_name)
    if profile.biography:
        parts.append(profile.biography)

    if profile.is_private:
        result["error"] = "private profile (burner must follow it to read posts)"
    else:
        try:
            for post in itertools.islice(profile.get_posts(), max_posts):
                if post.caption:
                    parts.append(post.caption)
                    result["n_captions"] += 1
        except Exception as e:  # noqa: BLE001
            result["error"] = f"posts unavailable: {type(e).__name__}"

    result["text"] = "\n".join(parts)
    result["ok"] = bool(result["text"])
    return result
