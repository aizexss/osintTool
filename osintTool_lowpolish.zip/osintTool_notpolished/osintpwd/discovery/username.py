"""Expand a CONFIRMED account into the person's wider footprint.

Once the analyst confirms one real handle, the same username very often exists
on other networks. This checks a curated, high-signal site list directly (no
search engine), concurrently and with short timeouts, and returns the profiles
that exist. Reliability is chosen over breadth: a site is included only when a
missing user is distinguishable (a 404, or a definite "no such user" marker),
so it does not invent profiles.

This runs only on a handle the analyst chose — it is expansion of a confirmed
identity, not blind enumeration.
"""

from __future__ import annotations

import concurrent.futures as cf
import re
import urllib.parse

import httpx

from .http import DEFAULT_HEADERS, PoliteClient

_AUTH_PATHS = ("/login", "/signin", "/signup", "/sign_in", "/auth",
               "/account/login", "/join", "/register")
_HANDLE_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.\-]{1,39}")

# short "what's here" note per platform, for the UI
SITE_DESC = {
    "github": "код и репозитории", "gitlab": "код и репозитории",
    "reddit": "посты и комментарии", "medium": "статьи",
    "keybase": "крипто-профиль, контакты", "soundcloud": "музыка",
    "vimeo": "видео", "youtube": "видео-канал", "habr": "статьи и публикации",
    "gravatar": "аватар и привязки почты", "behance": "портфолио",
    "dribbble": "портфолио", "about.me": "визитка", "vk": "профиль ВК",
    "ok.ru": "профиль ОК", "steam": "игровой профиль",
    "hackernews": "комментарии", "producthunt": "продукты и стартапы",
}

# (name, url template with {u}, ok_status, missing markers on 200)
_SITES = (
    ("github", "https://github.com/{u}", (200,), ()),
    ("gitlab", "https://gitlab.com/{u}", (200,), ()),
    ("reddit", "https://old.reddit.com/user/{u}", (200,), ()),
    ("medium", "https://medium.com/@{u}", (200,), ()),
    ("keybase", "https://keybase.io/{u}", (200,), ()),
    ("soundcloud", "https://soundcloud.com/{u}", (200,), ()),
    ("vimeo", "https://vimeo.com/{u}", (200,), ()),
    ("youtube", "https://www.youtube.com/@{u}", (200,), ()),
    ("dribbble", "https://dribbble.com/{u}", (200,), ()),
    ("behance", "https://www.behance.net/{u}", (200,), ()),
    ("about.me", "https://about.me/{u}", (200,), ()),
    ("gravatar", "https://en.gravatar.com/{u}", (200,), ()),
    ("habr", "https://habr.com/ru/users/{u}/", (200,), ()),
    ("producthunt", "https://www.producthunt.com/@{u}", (200,), ()),
    ("vk", "https://vk.com/{u}", (200,),
     ("страница удалена", "page not found", "404 not found", "не найдена",
      "this page has been removed", "страница не найдена")),
    ("steam", "https://steamcommunity.com/id/{u}", (200,),
     ("the specified profile could not be found", "no profile could be found")),
    ("hackernews", "https://news.ycombinator.com/user?id={u}", (200,),
     ("no such user.",)),
)


def valid_handle(handle: str) -> str | None:
    h = (handle or "").strip().lstrip("@")
    if not h or " " in h or not _HANDLE_RE.fullmatch(h) or not any(c.isalpha() for c in h):
        return None
    return h


def check_username(handle: str, *, timeout: float = 5.0, max_workers: int = 16) -> list[dict]:
    """Probe `handle` across the curated sites concurrently; return the hits
    as {"site", "url", "note"}. Network-bound; never raises."""
    h = valid_handle(handle)
    if not h:
        return []
    hits: list[dict] = []
    with httpx.Client(headers=dict(DEFAULT_HEADERS), timeout=timeout,
                      follow_redirects=True,
                      limits=httpx.Limits(max_connections=max_workers)) as client:
        def probe(site):
            name, tmpl, ok, missing = site
            try:
                r = client.get(tmpl.format(u=h))
            except httpx.HTTPError:
                return None
            if r.status_code not in ok:
                return None
            path = urllib.parse.urlparse(str(r.url)).path.lower()
            if path in ("", "/") or any(a in path for a in _AUTH_PATHS):
                return None
            if r.history and h.lower() not in str(r.url).lower():
                return None
            if missing and any(m in r.text[:30000].lower() for m in missing):
                return None
            return {"site": name, "url": str(r.url), "note": SITE_DESC.get(name, "профиль")}

        with cf.ThreadPoolExecutor(max_workers=max_workers) as ex:
            for res in ex.map(probe, _SITES):
                if res:
                    hits.append(res)
    return hits
