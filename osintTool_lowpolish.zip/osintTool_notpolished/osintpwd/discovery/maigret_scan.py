"""Bounded anonymous username expansion; a matching handle never proves ownership."""
from __future__ import annotations

import asyncio
from copy import deepcopy
from datetime import datetime, timezone
from functools import lru_cache
import logging
from pathlib import Path
import re
import threading
import time
from urllib.parse import urlparse

from bs4 import BeautifulSoup

from .candidates import _HOSTS, _handle_from_url, canonical_profile_url
from .username import check_username, valid_handle

SITES = {'GitHub': 'github', 'GitLab': 'gitlab', 'Reddit': 'reddit',
         'Medium': 'medium', 'SoundCloud': 'soundcloud', 'VK': 'vk',
         'Steam': 'steam', 'TikTok': 'tiktok', 'Threads': 'threads',
         'Bluesky': 'bluesky', 'Telegram': 'telegram', 'YouTube': 'youtube',
         'Instagram': 'instagram', 'Facebook': 'facebook', 'Twitter': 'x',
         'LinkedIn': 'linkedin', 'Twitch': 'twitch'}
_LOCK = threading.Lock()
_SLOTS = threading.BoundedSemaphore(1)
_COOLDOWNS: dict[str, float] = {}
_CACHE: dict[str, tuple[float, dict]] = {}
_LOGGER = logging.getLogger('osintpwd.maigret')
_LOGGER.addHandler(logging.NullHandler())
_LOGGER.propagate = False  # upstream messages may contain raw response details


@lru_cache(maxsize=1)
def _database():
    import maigret
    from maigret.sites import MaigretDatabase
    return MaigretDatabase().load_from_path(str(Path(maigret.__file__).parent / 'resources' / 'data.json'))


def _public_profile(platform: str, url: str) -> bool:
    host = (urlparse(url).hostname or '').lower()
    if platform == 'youtube' and url.rstrip('/').endswith('/about'):
        url = url.rstrip('/')[:-6]
    return (url.startswith('https://') and
            any(host == domain or host.endswith('.' + domain) for domain in _HOSTS[platform]) and
            bool(_handle_from_url(platform, url)))


def _select_sites():
    selected, skipped = {}, []
    now = time.monotonic()
    for site in _database().sites:
        platform = SITES.get(site.name)
        if not platform or site.disabled:
            continue
        # Some catalog entries refer to analytics/mirror sites, not the account.
        if not _public_profile(platform, site.url.replace('{username}', 'exampleuser')):
            continue
        with _LOCK:
            cooling = _COOLDOWNS.get(site.name, 0) > now
        if cooling:
            skipped.append({'site': platform, 'status': 'cooldown'})
            continue
        entry = deepcopy(site)
        entry.activation = {}  # no guest tokens, login or activation requests
        entry.request_head_only = False  # inspect content, not just HTTP 200
        selected[site.name] = entry
    return selected, skipped


def _normalize(handle: str, results: dict, selected: dict, skipped: list[dict]) -> dict:
    accounts, checks = [], list(skipped)
    retrieved = datetime.now(timezone.utc).isoformat(timespec='seconds')
    for name in selected:
        platform = SITES[name]
        raw = results.get(name, {})
        status = raw.get('status')
        state = getattr(getattr(status, 'status', None), 'name', 'UNKNOWN')
        html = str(raw.get('response_text') or '')[:500000]
        soup = BeautifulSoup(html, 'html.parser')
        title = soup.title.get_text(' ', strip=True) if soup.title else ''
        ids = getattr(status, 'ids_data', None) or raw.get('ids_data') or {}
        if not isinstance(ids, dict):
            ids = {}
        # Maigret 0.6.6 does not retain response_text despite documenting it.
        # Its local extractors provide positive account fields instead, including
        # public API responses with an account ID and no HTML title at all.
        parsed_account = any(ids.get(key) for key in ('uid', 'id', 'username', 'user_id', 'nickname'))
        title = title or str(ids.get('fullname') or ids.get('name') or (handle if parsed_account else ''))
        visible = soup.get_text(' ', strip=True)[:24000]
        challenge = any(mark in (title + ' ' + visible[:1500]).casefold() for mark in
                        ('just a moment', 'verify you are human', 'access denied',
                         'security verification', 'checking your browser', 'captcha challenge'))
        url = str(raw.get('url_user') or '')
        if platform == 'youtube' and url.rstrip('/').endswith('/about'):
            url = url.rstrip('/')[:-6]
        code = raw.get('http_status')
        error = getattr(status, 'error', None)
        if challenge or error or state == 'UNKNOWN' or code in (202, 401, 403, 429):
            label = 'challenge' if challenge else 'unavailable'
            with _LOCK:
                _COOLDOWNS[name] = time.monotonic() + (300 if challenge else 120)
        elif state == 'AVAILABLE':
            label = 'not_found'
        elif state == 'ILLEGAL':
            label = 'unsupported_handle'
        elif (state == 'CLAIMED' and code == 200 and not raw.get('is_similar')
              and _public_profile(platform, url)):
            # A challenge/login shell with a 200 must not become an account.
            metadata = ' '.join(str(tag.get('content') or tag.get('href') or '')
                                for tag in soup.select('meta[property^="og:"], link[rel="canonical"]'))
            present = re.search(r'(?<![\w.-])' + re.escape(handle) + r'(?![\w-])',
                                title + ' ' + visible + ' ' + metadata, re.I)
            if (present or parsed_account) and title and not re.search(r'^(log ?in|sign ?in|sign ?up)(\b|\s)', title, re.I):
                label = 'found'
                accounts.append({'site': platform, 'url': canonical_profile_url(platform, url),
                                 'title': title[:300], 'provider': 'maigret', 'retrieved_at': retrieved,
                                 'note': 'Совпадает ник; владелец не подтверждён',
                                 'evidence': [{'kind': 'username', 'provider': 'maigret',
                                               'source_url': url, 'excerpt': title[:300],
                                               'retrieved_at': retrieved}]})
            else:
                label = 'unverified_response'
        else:
            label = 'unverified_response'
        checks.append({'site': platform, 'status': label})
    partial = any(item['status'] not in ('found', 'not_found', 'unsupported_handle') for item in checks)
    return {'accounts': accounts, 'checks': checks, 'partial': partial,
            'provider': 'maigret', 'cached': False}


async def _scan_async(handle: str) -> dict:
    from maigret import search
    selected, skipped = _select_sites()
    results = {}
    if selected:
        try:
            await asyncio.wait_for(search(
                username=handle, site_dict=selected, logger=_LOGGER, timeout=5,
                is_parsing_enabled=True, is_enrich_enabled=False,
                max_connections=4, no_progressbar=True, retries=0,
                check_domains=False, cloudflare_bypass=None, dns_resolver='threaded',
                output_container=results), timeout=25)
        except asyncio.TimeoutError:
            pass  # completed sites are preserved; missing sites become unavailable
    return _normalize(handle, results, selected, skipped)


def scan_username(handle: str) -> dict:
    h = valid_handle(handle)
    if not h:
        return {'accounts': [], 'checks': [], 'partial': False, 'provider': 'maigret', 'cached': False}
    with _SLOTS:
        now = time.monotonic()
        with _LOCK:
            cached = _CACHE.get(h.casefold())
            if cached and now - cached[0] < (60 if cached[1]['partial'] else 600):
                result = deepcopy(cached[1])
                result['cached'] = True
                return result
        try:
            result = asyncio.run(_scan_async(h))
        except (ImportError, FileNotFoundError):
            result = {'accounts': check_username(h), 'checks': [{'site': 'maigret', 'status': 'not_installed'}],
                      'partial': True, 'provider': 'curated', 'cached': False}
        except Exception:
            _LOGGER.warning('Username provider unavailable')
            result = {'accounts': [], 'checks': [{'site': 'maigret', 'status': 'unavailable'}],
                      'partial': True, 'provider': 'maigret', 'cached': False}
        with _LOCK:
            _CACHE[h.casefold()] = (time.monotonic(), deepcopy(result))
            while len(_CACHE) > 64:
                _CACHE.pop(next(iter(_CACHE)))
        return result
