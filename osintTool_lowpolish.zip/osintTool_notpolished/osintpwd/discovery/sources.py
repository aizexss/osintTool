"""Publication queries and URL handling; retrieval never proves relevance."""
from __future__ import annotations

import re
from urllib.parse import parse_qsl, unquote, urlencode, urlparse, urlunparse


_VK_DOCUMENT = re.compile(r'^(?:wall|topic|photo|video|article)-?\d+_\d+$')

JUNK_HOSTS = ('socialcatfish', 'spokeo', 'whitepages', 'beenverified', 'thatsthem',
              'radaris', 'mylife', 'peoplefinder', 'truepeoplesearch', 'intelius',
              'fastpeoplesearch', 'idcrawl', 'clustrmaps', 'usersearch', 'peekyou',
              'zabasearch', 'instantcheckmate', 'peoplelooker', 'spydialer')
JUNK_DOMAINS = ('rocketreach.co', 'zoominfo.com', 'datanyze.com', 'signalhire.com')


def canonical_source_url(url: str) -> str:
    """Keep comment IDs, normalize VK document wrappers and discard trackers."""
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or '').lower()
        port = parsed.port
        if parsed.scheme not in {'http', 'https'} or not host:
            return ''
    except (TypeError, ValueError):
        return ''
    pairs = [(key, value) for key, value in parse_qsl(parsed.query, keep_blank_values=True)
             if not key.lower().startswith('utm_') and key.lower() not in {'fbclid', 'gclid'}]
    path = parsed.path
    if host in {'vk.com', 'vk.ru', 'www.vk.com', 'www.vk.ru', 'm.vk.com', 'm.vk.ru'}:
        # A VK root/profile URL can open a concrete wall post in an overlay.
        # Never turn an arbitrary redirect parameter into a fetch destination.
        wrapper = next((value.split('/', 1)[0] for key, value in pairs
                        if key in {'w', 'z'} and _VK_DOCUMENT.fullmatch(value.split('/', 1)[0])), '')
        if wrapper:
            path = '/' + wrapper
            pairs = [(key, value) for key, value in pairs if key not in {'w', 'z'}]
        if _VK_DOCUMENT.fullmatch(path.strip('/')):
            host = 'vk.com'
    # Fragments can identify a particular comment; don't merge them away.
    return urlunparse((parsed.scheme, host + (f':{port}' if port else ''),
                       path or '/', '', urlencode(sorted(pairs)), parsed.fragment))


def quoted_terms(name: str) -> str:
    return ' '.join(f'"{part}"' for part in name.replace('"', '').split())


def build_info_queries(name: str, variants: list[str], hints: dict,
                       platforms: tuple[str, ...]) -> list[str]:
    """At most six publication queries, independent of account success."""
    terms = quoted_terms(name)
    alternate = next((v for v in variants if v.casefold() != name.casefold()), '')
    queries = [terms]
    if alternate:
        queries.append(quoted_terms(alternate))
    if 'vk' in platforms:
        # Large OR groups are silently broadened by some free engines. Use
        # separate scopes and both scripts; broader VK queries follow if needed.
        queries.append(f'site:vk.com/wall {terms}')
        queries.append(f'site:vk.ru/wall {quoted_terms(alternate or name)}')
    queries.append(f'{terms} filetype:pdf')
    context = ' '.join(f'"{str(hints[key]).replace(chr(34), "")}"'
                       for key in ('city', 'school', 'employer', 'country') if hints.get(key))
    queries.append(f'{terms} {context}' if context else
                   f'{terms} -site:linkedin.com')
    return list(dict.fromkeys(q for q in queries if q != f'"{name}"'))[:6]


def build_info_recovery_queries(name: str, variants: list[str], platforms: tuple[str, ...],
                                *, need_web: bool, need_vk: bool) -> list[str]:
    """Try simple alternate formulations after account retries, within a reserve."""
    alternate = next((v for v in variants if v.casefold() != name.casefold()), name)
    queries = []
    if need_web:
        queries.extend([f'"{" ".join(reversed(name.split()))}" -site:linkedin.com',
                        f'{name.replace(chr(34), "")} -site:linkedin.com'])
    if need_vk and 'vk' in platforms:
        queries.extend([f'site:vk.com {quoted_terms(alternate)}',
                        f'site:vk.ru {quoted_terms(name)}',
                        f'site:vk.com {alternate.replace(chr(34), "")}'])
    if need_web and alternate != name:
        queries.append(f'"{" ".join(reversed(alternate.split()))}"')
    return list(dict.fromkeys(queries))[:6]


def is_publication_url(url: str) -> bool:
    """Documents can become read leads. Social roots/categories/profiles cannot."""
    from .candidates import PLATFORMS, SOCIAL_HOSTS, _handle_from_url
    url = canonical_source_url(url)
    if not url:
        return False
    parsed = urlparse(url)
    host = parsed.hostname or ''
    if any(host == d or host.endswith('.' + d) for d in
           (*JUNK_DOMAINS, *(label + '.com' for label in JUNK_HOSTS))):
        return False
    path = unquote(parsed.path).strip('/').lower()
    social = any(host == d or host.endswith('.' + d) for d in SOCIAL_HOSTS)
    if social and path.split('/')[0] in {'', 'index.php', 'login', 'login.php', 'logout',
            'logout.php', 'signin', 'sign-in', 'signup', 'sign-up', 'register', 'accounts',
            'auth', 'oauth', 'checkpoint', 'search', 'results', 'feed', 'home', 'im',
            'messages', 'settings', 'privacy', 'terms', 'help', 'topic', 'topics'}:
        return False
    return not any(_handle_from_url(platform, url) for platform in PLATFORMS)


def publication_name_match(name: str, hit) -> bool:
    from .related import target_contexts
    return is_publication_url(hit.url) and bool(target_contexts(name, hit.title + '\n' + hit.snippet))


def source_type(url: str) -> str:
    parsed = urlparse(url)
    path = unquote(parsed.path).lower()
    if path.endswith('.pdf'):
        return 'document'
    if any(key in dict(parse_qsl(parsed.query)) for key in ('reply', 'comment', 'comment_id')) or parsed.fragment.startswith(('reply', 'comment')):
        return 'comment'
    if re.search(r'/(?:wall-?\d|topic-?\d|posts?/|status/|p/|reels?/|comments/)', path):
        return 'publication'
    return 'web'


def profile_link_evidence(links: list[dict], candidates: list) -> dict | None:
    """A local, non-navigation link to a named account is a reviewable connection."""
    from .candidates import canonical_profile_url
    known = {canonical_profile_url(c.platform, c.url): c for c in candidates
             if c.name_match and c.relation != 'username'}
    for link in links:
        if link.get('boilerplate'):
            continue
        url = canonical_profile_url(link.get('site', ''), link.get('url', ''))
        if url in known:
            context = (link.get('context') or link.get('anchor') or '').strip()
            if context:
                return {'kind': 'profile_link', 'profile_url': url, 'excerpt': context[:600]}
    return None
