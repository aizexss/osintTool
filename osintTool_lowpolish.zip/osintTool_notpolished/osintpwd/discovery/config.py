"""Environment-driven configuration for discovery backends.

Nothing secret is hardcoded. Set only what you use:

    SERPER_API_KEY      -> enables Serper.dev (google.serper.dev)
    GOOGLE_CSE_KEY      -> Google Custom Search JSON API key
    GOOGLE_CSE_CX       -> Google Custom Search engine id (cx)
    SEARXNG_URL         -> base URL of your SearXNG instance
                           (default http://localhost:8080)
    OSINT_BACKEND_ORDER -> comma list to force priority, e.g.
                           "serper,searxng,playwright,duckduckgo"
"""

from __future__ import annotations

import os
from dataclasses import dataclass


def discovery_query_budget() -> int:
    """Deployment setting; the UI keeps one automatic analysis action."""
    try:
        value = int(os.environ.get('OSINT_QUERY_BUDGET', '48'))
    except ValueError:
        value = 48
    return max(12, min(value, 200))


@dataclass
class DiscoveryConfig:
    serper_key: str = ""
    google_cse_key: str = ""
    google_cse_cx: str = ""
    searxng_url: str = ""          # empty => SearXNG disabled
    backend_order: tuple[str, ...] = ()
    search_mode: str = 'auto'  # keyless excludes credential-based providers

    @classmethod
    def from_env(cls) -> "DiscoveryConfig":
        order = os.environ.get("OSINT_BACKEND_ORDER", "")
        return cls(
            serper_key=os.environ.get("SERPER_API_KEY", "").strip(),
            google_cse_key=os.environ.get("GOOGLE_CSE_KEY", "").strip(),
            google_cse_cx=os.environ.get("GOOGLE_CSE_CX", "").strip(),
            # SearXNG only joins the chain when explicitly configured, so an
            # absent instance never stalls the fallback on connect retries.
            searxng_url=os.environ.get("SEARXNG_URL", "").strip(),
            backend_order=tuple(
                x.strip() for x in order.split(",") if x.strip()
            ),
            search_mode=os.environ.get('OSINT_SEARCH_MODE', 'auto').strip().lower(),
        )
