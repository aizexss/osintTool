"""Facebook enrichment via a saved Playwright browser session.

Facebook has no reliable scraping library and walls almost everything behind
login, so we drive a real Chromium: you log in ONCE in a visible window
(`fb-login`, handles 2FA/checkpoints), the cookies are saved as a Playwright
storage-state file, and analysis reuses them headlessly.

Use a THROWAWAY/burner account — Facebook aggressively bans automation.
This path is inherently fragile: FB may still block, and the DOM changes
often, so text extraction is best-effort.

`FB_SESSION_FILE` overrides the saved-session location.
"""

from __future__ import annotations

import os

DEFAULT_SESSION_FILE = os.path.join(
    os.environ.get("APPDATA") or os.path.expanduser("~"),
    "osintpwd", "fb_session.json",
)


def session_file_path(path: str | None = None) -> str:
    p = path or os.environ.get("FB_SESSION_FILE") or DEFAULT_SESSION_FILE
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def session_available(path: str | None = None) -> bool:
    return os.path.exists(session_file_path(path))


def fb_login_interactive(path: str | None = None, timeout: int = 300) -> str:
    """Open a visible Chrome, let the user log in, auto-detect + save the session.

    No key presses needed: it polls for the 'c_user' login cookie and saves
    the moment you're logged in. A display is required (run on the desktop).
    """
    import time

    from playwright.sync_api import sync_playwright

    target = session_file_path(path)
    prefill_user = os.environ.get("FB_USERNAME", "")
    prefill_pass = os.environ.get("FB_PASSWORD", "")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, channel="chrome")
        ctx = browser.new_context()
        page = ctx.new_page()
        page.goto("https://www.facebook.com/login", wait_until="domcontentloaded")

        try:  # best-effort pre-fill; user still submits + handles 2FA
            if prefill_user:
                page.fill("#email", prefill_user, timeout=4000)
            if prefill_pass:
                page.fill("#pass", prefill_pass, timeout=4000)
        except Exception:  # noqa: BLE001
            pass

        print("\n>>> A Chrome window opened. Log in there (2FA is fine).")
        print(">>> It saves automatically once you're in — no key press needed.\n")

        deadline = time.monotonic() + timeout
        logged_in = False
        while time.monotonic() < deadline:
            try:
                cks = ctx.cookies("https://www.facebook.com")
            except Exception:  # noqa: BLE001 — window closed
                break
            if any(c["name"] == "c_user" for c in cks):
                logged_in = True
                break
            page.wait_for_timeout(1500)

        if logged_in:
            ctx.storage_state(path=target)
        browser.close()

    if not logged_in:
        raise RuntimeError("login not detected within timeout")
    return target


def import_cookies_from_browser(browser: str = "chrome",
                                path: str | None = None) -> tuple[str, int]:
    """Reuse an EXISTING browser login: pull facebook.com cookies and save them
    as a Playwright storage-state. No separate login needed.

    Note: if you're logged in with a personal account, the tool then reads FB
    as that account (ban risk to your real account).
    """
    import json

    import browser_cookie3

    loaders = {
        "chrome": browser_cookie3.chrome,
        "edge": browser_cookie3.edge,
        "firefox": browser_cookie3.firefox,
        "brave": browser_cookie3.brave,
    }
    load = loaders.get(browser.lower(), browser_cookie3.chrome)
    jar = load(domain_name="facebook.com")

    cookies = []
    for ck in jar:
        rest = getattr(ck, "_rest", {}) or {}
        cookies.append({
            "name": ck.name,
            "value": ck.value,
            "domain": ck.domain,
            "path": ck.path or "/",
            "expires": float(ck.expires) if ck.expires else -1,
            "httpOnly": bool(rest.get("HttpOnly", False)),
            "secure": bool(ck.secure),
            "sameSite": "Lax",
        })
    if not cookies:
        raise RuntimeError(f"no facebook.com cookies found in {browser} "
                           "(are you logged in there?)")

    target = session_file_path(path)
    with open(target, "w", encoding="utf-8") as fh:
        json.dump({"cookies": cookies, "origins": []}, fh)
    return target, len(cookies)


def _default_chrome_user_data() -> str:
    local = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(local, "Google", "Chrome", "User Data")


def _find_chrome_exe() -> str | None:
    candidates = [
        os.path.join(os.environ.get("PROGRAMFILES", r"C:\Program Files"),
                     "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
                     "Google", "Chrome", "Application", "chrome.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""),
                     "Google", "Chrome", "Application", "chrome.exe"),
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None


def import_from_chrome_profile(path: str | None = None,
                               user_data_dir: str | None = None,
                               profile_dir: str = "Default") -> tuple[str, int, bool]:
    """Reuse an existing Chrome login by driving Chrome with its own profile.

    Chrome decrypts its own cookies, so no admin / no cookie-file decryption.
    CHROME MUST BE CLOSED (the profile is locked while it runs). Saves the
    facebook.com cookies as a Playwright storage-state and reports whether the
    session looks logged in (FB sets a 'c_user' cookie when authenticated).
    """
    import json
    import subprocess
    import time

    import httpx
    from playwright.sync_api import sync_playwright

    udd = user_data_dir or _default_chrome_user_data()
    if not os.path.isdir(udd):
        raise RuntimeError(f"Chrome user-data dir not found: {udd}")
    chrome = _find_chrome_exe()
    if not chrome:
        raise RuntimeError("chrome.exe not found — is Chrome installed?")

    # ABE-encrypted cookies only decrypt inside the real Chrome install on the
    # real profile. Launching that profile in-place via Playwright detaches on
    # Windows, so instead we start Chrome ourselves with remote debugging and
    # read the (already-decrypted) cookies over CDP.
    port = 9222
    proc = subprocess.Popen(
        [chrome, f"--user-data-dir={udd}", f"--profile-directory={profile_dir}",
         f"--remote-debugging-port={port}", "--headless=new",
         "--no-first-run", "--no-default-browser-check", "--disable-gpu",
         "about:blank"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    try:
        # wait for the debugging endpoint
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            try:
                if httpx.get(f"http://127.0.0.1:{port}/json/version",
                             timeout=1).status_code == 200:
                    break
            except httpx.HTTPError:
                time.sleep(0.4)
        else:
            raise RuntimeError("Chrome debugging port never came up")

        with sync_playwright() as p:
            browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{port}")
            ctx = browser.contexts[0]
            raw = ctx.cookies("https://www.facebook.com")
            browser.close()
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:  # noqa: BLE001
            proc.kill()

    def _ss(v):
        return v if v in ("Strict", "Lax", "None") else "Lax"

    fb_cookies = [
        {"name": c["name"], "value": c["value"],
         "domain": c.get("domain", ".facebook.com"), "path": c.get("path", "/"),
         "expires": c.get("expires", -1),
         "httpOnly": c.get("httpOnly", False), "secure": c.get("secure", False),
         "sameSite": _ss(c.get("sameSite"))}
        for c in raw if "facebook.com" in c.get("domain", "")
    ]
    logged_in = any(c["name"] == "c_user" for c in fb_cookies)

    target = session_file_path(path)
    with open(target, "w", encoding="utf-8") as fh:
        json.dump({"cookies": fb_cookies, "origins": []}, fh)
    return target, len(fb_cookies), logged_in


def fetch_profile_text(url: str, path: str | None = None,
                       max_chars: int = 5000) -> dict:
    """Fetch a FB profile's visible text using the saved session (headless).

    Returns {ok, text, error}. Never raises.
    """
    result = {"ok": False, "text": "", "error": ""}
    if not session_available(path):
        result["error"] = "no FB session (run: python -m osintpwd fb-login)"
        return result

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        result["error"] = "playwright not installed"
        return result

    target = session_file_path(path)
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            ctx = browser.new_context(storage_state=target)
            page = ctx.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=25000)
            page.wait_for_timeout(2500)
            main_text = page.evaluate(
                "() => (document.querySelector('[role=main]')"
                " || document.body).innerText")
            og = page.evaluate(
                "() => { const m=document.querySelector("
                "'meta[property=\"og:description\"]'); return m?m.content:''; }")
            browser.close()
    except Exception as e:  # noqa: BLE001
        result["error"] = f"fetch failed: {type(e).__name__}"
        return result

    combined = "\n".join(t for t in (og, main_text) if t)[:max_chars]
    result["text"] = combined
    result["ok"] = bool(combined.strip())
    if not result["ok"]:
        result["error"] = "no readable text (walled or empty)"
    return result
