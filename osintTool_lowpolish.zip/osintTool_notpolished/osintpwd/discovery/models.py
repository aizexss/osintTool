"""Dataclasses for the discovery layer."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SearchResult:
    """One raw hit from a search-engine backend."""

    url: str
    title: str = ""
    snippet: str = ""
    provider: str = ""
    query: str = ""
    retrieved_at: str = ""
    cached: bool = False
    cache_age_seconds: int = 0
    stale: bool = False
    partial: bool = False  # some sources failed when this response was retrieved
    page: int = 1


@dataclass
class Candidate:
    """A possible profile of the target, pending human confirmation."""

    platform: str            # "linkedin" | "instagram" | "facebook"
    url: str
    handle: str = ""         # slug / username extracted from the URL
    title: str = ""          # SERP or og:title
    snippet: str = ""        # SERP snippet / og:description
    score: float = 0.0       # how well hint terms matched (higher = better)
    confirmed: bool = False
    # True when the target's NAME actually appears on this hit (full name in the
    # title/snippet, or a handle that IS the name). A direct by-name match is
    # always surfaced as a real find — never demoted to "related" or dropped.
    name_match: bool = False
    # Namesake disambiguation (grouping, never filtering — recall is preserved):
    #   group        — identity cluster id; accounts sharing a handle across
    #                   networks get the same id (1 = best-fitting identity).
    #   matched_hints — which supplied hints (city/employer/…) appear on THIS hit,
    #                   the evidence that tells same-named people apart.
    group: int = 0
    matched_hints: list[str] = field(default_factory=list)
    # Requirement 2: when an account is reached via a co-mentioned person
    # instead of the target directly, name that person here (empty = direct).
    related_person: str = ""
    # Account-centric expansion: when this account was found by pivoting a
    # confirmed/known handle across networks, the source handle goes here.
    expanded_from: str = ""
    note: str = ""           # short "what's here" note for the UI

    # filled in by enrich()
    public_text: str = ""
    keywords: list[str] = field(default_factory=list)
    image_url: str = ""      # og:image (public profile photo), if any
    # cross-account links declared ON this profile (rel=me / bio links to other
    # networks). Key for finding accounts whose handle differs from this one.
    public_links: list[dict] = field(default_factory=list)
    fetch_status: str = "not_read"  # not_read | ok | empty | error
    fetch_error: str = ""
    # Retrieval evidence is not proof that two profiles have the same owner.
    evidence: list[dict] = field(default_factory=list)
    match_reasons: list[str] = field(default_factory=list)
    relation: str = "direct"  # direct | related_person | via_related | username


@dataclass
class DiscoveryResult:
    """Everything discovery found for one query, before confirmation."""

    query_name: str
    hints: dict = field(default_factory=dict)
    candidates: list[Candidate] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    # Requirement 2: people mentioned near the target, used as the fallback
    # route to their social networks when the target's own accounts weren't found.
    related_people: list[str] = field(default_factory=list)
    # Accounts reached VIA those nearby people — kept SEPARATE from the target's
    # own accounts so associates never masquerade as the target.
    related_accounts: list["Candidate"] = field(default_factory=list)
    # Open-source info about the person (non-profile pages: news, articles,
    # university/company pages). Secondary to accounts — used as corroboration
    # to help confirm which accounts belong to this specific person.
    web_info: list[dict] = field(default_factory=list)
    related_searched: bool = False
    related_evidence: list[dict] = field(default_factory=list)
    stats: dict = field(default_factory=dict)
    # Explicit owner-name contradictions cannot return through weaker routes.
    excluded_profile_urls: list[str] = field(default_factory=list)
