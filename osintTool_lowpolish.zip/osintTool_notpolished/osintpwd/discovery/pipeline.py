"""Orchestrate discovery: name + hints -> candidates -> (confirm) -> enrich."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import time
from urllib.parse import unquote, urlparse

from ..models import Profile
from .candidates import (
    PLATFORMS, SITE_FRAG, build_extra_query, build_extra_queries, build_queries, classify,
    EXTRA_SITE_QUERIES, SOCIAL_HOSTS,
    canonical_candidate_key, canonical_profile_url, merge_candidate, is_name_match,
    _handle_from_url, has_owner_name_conflict, flag_owner_conflict,
)
from .enrich import enrich_candidate
from .http import PoliteClient
from .models import Candidate, DiscoveryResult, SearchResult
from .retrieval import SearchRun
from .pivots import build_pivot_queries, evidenced_pivot_queries
from .metrics import query_yield_report
from .search import SearchBackend, default_backend
from .translit import name_variants
from .sources import (build_info_queries, canonical_source_url, profile_link_evidence,
                      quoted_terms, source_type, build_info_recovery_queries, is_publication_url,
                      JUNK_HOSTS as _JUNK_HOSTS, JUNK_DOMAINS as _JUNK_DOMAINS)

# How many search queries run concurrently. Rare names walk the full backend
# fallback chain (Serper -> CSE -> SearXNG -> DDG) per query, ~10-15s each;
# fanning them out turns a sum into a max and cuts a 2-minute run to seconds.
# The whole batch (all variants at once) shares this pool, so a Cyrillic second
# variant adds queries but little wall-clock. Serper/SearXNG tolerate this fan-out.
_SEARCH_WORKERS = 2
_EXTRA_SITE_QUERIES = EXTRA_SITE_QUERIES


def _is_junk_info(url: str) -> bool:
    host = (urlparse(url).hostname or '').lower()
    return (_is_service_info(url) or any(host == d or host.endswith('.' + d) for d in _JUNK_DOMAINS) or any(
        host == bad + '.com' or host.endswith('.' + bad + '.com') for bad in _JUNK_HOSTS))
def _is_service_info(url: str) -> bool:
    """Social navigation/login pages are never person-specific sources.

    Publications remain eligible: a post or repository with an actual name
    mention is useful, unlike a site's home/feed/login/search page.
    """
    parsed = urlparse(url)
    host = (parsed.hostname or '').lower()
    if not any(host == domain or host.endswith('.' + domain) for domain in SOCIAL_HOSTS):
        return False
    parts = unquote(parsed.path).strip('/').lower().split('/')
    return parts[0] in {'', 'index.php', 'login', 'login.php', 'logout', 'logout.php',
        'signin', 'sign-in', 'signup', 'sign-up', 'register', 'accounts', 'auth',
        'oauth', 'checkpoint', 'search', 'results', 'feed', 'home', 'im',
        'messages', 'settings', 'privacy', 'terms', 'help', 'topic', 'topics'}


def _info_contexts(name: str, source: dict, variants: list[str]) -> list[str]:
    # A search query/URL is retrieval context, not a mention on the source.
    # Whole tokens keep Muhammedali from matching Muhammed and accept either
    # name order. Do not apply profile-owner title rules to article headlines.
    from .related import target_contexts
    return target_contexts(name, '\n'.join(source.get(field, '') or ''
        for field in ('title', 'snippet', 'excerpt')), variants=variants)


def _linked_candidates(name: str, variants: list[str], hints: dict,
                       page: Candidate, *, owner: Candidate | None = None,
                       rejected_urls: set[str] | None = None) -> list[Candidate]:
    """Keep explicit account links with their local context, without claiming ownership."""
    from .related import _link_names_target
    out = []
    for link in page.public_links:
        platform = link.get('site', '')
        if platform not in PLATFORMS or link.get('boilerplate'):
            continue
        anchor = link.get('anchor') or link.get('text', '')
        context = link.get('context', '')
        # A generic footer link on a news site is not evidence about the target.
        attached = _link_names_target(link, variants)
        declared = bool(link.get('rel_me'))
        owner_named = owner is not None and owner.name_match
        page_named = any(is_name_match(v, SearchResult(page.url, page.title, ''), '')
                         for v in variants)
        linked = attached or declared and (owner_named or page_named)
        if not linked and not classify(name, hints, platform, [SearchResult(link['url'], anchor)]):
            # A feed block may contain the target plus many unrelated authors.
            # Partial links need their own matching anchor/handle, not a distant
            # name copied from the parent block. Named attachment is handled above.
            continue
        # Context stays in the snippet; names mentioned there are not the owner title.
        hit = SearchResult(link['url'], anchor, context)
        for c in classify(name, hints, platform, [hit], rejected_urls=rejected_urls,
                          linked_context=linked):
            if (attached or declared and owner_named) and 'owner_name_conflict' not in c.match_reasons:
                c.name_match = True
                c.score = max(c.score, 0.65 if declared and owner_named else 0.55)
            c.note = 'Явная ссылка со страницы' + (' · rel=me' if declared else '')
            c.evidence = [{'kind': 'profile_link' if owner else 'page_link',
                           'source_url': page.url, 'excerpt': (context or anchor or page.title)[:500],
                           'target_url': c.url, 'rel_me': declared}]
            c.match_reasons.append('Явная ссылка рядом с именем' if attached else
                                   'Ссылка rel=me' if declared else 'Совпадение в ссылке или её контексте')
            out.append(c)
    return out


def discover(
    name: str,
    hints: dict | None = None,
    platforms: tuple[str, ...] = PLATFORMS,
    backend: SearchBackend | None = None,
    max_per_platform: int = 10,
    username_scan: bool = True,
    max_scan_handles: int = 2,
    fetch_pages: int = 4,
    enrich_profiles: int = 2,
    related_search: str = "auto",
    query_budget: int | None = None,
    search_mode: str | None = None,
    username_provider: str = 'curated',
    journal=None,
    progress=None,
) -> DiscoveryResult:
    """Find candidate profiles for `name`. Network-bound; never raises.

    Results are ranked but UNCONFIRMED — a human should pick the real target
    before the data is used to build a password profile.
    """
    if related_search not in ('auto', 'always', 'off'):
        raise ValueError('related_search must be auto, always or off')
    if username_provider not in ('curated', 'maigret'):
        raise ValueError('username_provider must be curated or maigret')
    started = time.monotonic()
    hints = hints or {}
    client = PoliteClient(min_interval=0.3, timeout=8, max_retries=1)
    search_client: PoliteClient | None = None
    if backend is None:
        from .config import DiscoveryConfig
        from dataclasses import replace
        # Search engines tolerate a brisker cadence than page scraping. Concurrency
        # + a tighter interval is the speed win; keep timeout/retries generous
        # enough that a transient failure doesn't silently drop a query's results
        # (recall matters more than shaving the last few seconds). DuckDuckGo caps
        # its own wait (it's usually gated) so it can't dominate the run.
        search_client = PoliteClient(min_interval=0.3, timeout=15, max_retries=2)
        config = DiscoveryConfig.from_env()
        if search_mode is not None:
            config = replace(config, search_mode=search_mode)
        backend = default_backend(search_client, config)
    backend = SearchRun(backend, max_queries=query_budget, journal=journal)
    related_reserve = min(12, query_budget // 4) if query_budget is not None and related_search != 'off' else 0
    publication_reserve = min(6, query_budget // 8) if query_budget is not None else 0
    backend.reserve_queries(related_reserve + publication_reserve)
    result = DiscoveryResult(query_name=name, hints=hints)
    result.stats = {'source_pages_read': 0, 'profile_pages_read': 0,
                    'source_pages_ok': 0, 'profile_pages_ok': 0, 'page_errors': 0,
                    'search_mode': search_mode or (config.search_mode if search_client else 'custom'),
                    'requested_platforms': list(platforms), 'related_query_reserve': related_reserve,
                    'publication_query_reserve': publication_reserve}

    if hasattr(backend, "is_available") and not backend.is_available():
        result.errors.append(
            "no search backend available — set SERPER_API_KEY / GOOGLE_CSE_KEY"
            " / SEARXNG_URL, install Playwright, or rely on the free scraper"
        )

    # A Cyrillic name is usually written in Latin on the web too — search both.
    variants = name_variants(name)[:3]
    rejected_urls: set[str] = set()

    try:
        seen: dict[str, Candidate] = {}
        info_seen: dict[str, dict] = {}
        source_hits: list[dict] = []
        phase = 'search'
        last_checkpoint = 0.0

        def checkpoint(stage=None):
            nonlocal phase, last_checkpoint
            if stage:
                phase = stage
            if progress and (stage or time.monotonic() - last_checkpoint >= 1):
                result.stats.update(backend.stats())
                progress(result, phase)
                last_checkpoint = time.monotonic()

        def _keep(cands: list[Candidate]) -> None:
            # Explicit caller exclusions stay separate from owner conflicts.
            for key, candidate in list(seen.items()):
                if canonical_profile_url(candidate.platform, candidate.url) in rejected_urls:
                    del seen[key]
            result.candidates[:] = [c for c in result.candidates
                                    if canonical_profile_url(c.platform, c.url) not in rejected_urls]
            for c in cands:
                c.url = canonical_profile_url(c.platform, c.url)
                if c.url in rejected_urls:
                    continue
                if has_owner_name_conflict(name, c.title, c.handle):
                    flag_owner_conflict(c)
                key = canonical_candidate_key(c)
                if key in seen:
                    merge_candidate(seen[key], c)
                    continue
                seen[key] = c
                result.candidates.append(c)
            checkpoint()

        def _run_searches(tasks: list[dict], max_results: int) -> list[dict]:
            """Fan a batch of search tasks out across threads.

            Each task is a dict with a "query" (run in a worker) plus whatever
            aggregation context the caller needs ("tag", "platform", "variant").
            Only the network call runs off the main thread; results are returned
            so classify/aggregate stays single-threaded and race-free. Order is
            preserved for deterministic aggregation.
            """
            if not tasks:
                return []
            out = []
            if query_budget is not None:
                # Ask for LinkedIn before a multi-network batch can consume the
                # provider's available request capacity. Then keep concurrency low.
                tasks = sorted(tasks, key=lambda t: t.get('platform') != 'linkedin')
                if tasks[0].get('platform') == 'linkedin':
                    first, tasks = tasks[0], tasks[1:]
                    try:
                        hits = backend.search_profiles(first['query'], max_results=max_results,
                                                       platform='linkedin', name=name)
                        out.append({**first, 'hits': hits, 'err': None})
                        if any(is_name_match(name, hit, _handle_from_url('linkedin', hit.url) or '')
                               for hit in hits if _handle_from_url('linkedin', hit.url)):
                            tasks = [t for t in tasks if t.get('platform') != 'linkedin']
                    except Exception as exc:
                        out.append({**first, 'hits': [], 'err': repr(exc)})
            if not tasks:
                return out
            workers = 2 if query_budget is not None else _SEARCH_WORKERS
            with ThreadPoolExecutor(max_workers=min(workers, len(tasks))) as ex:
                futs = []
                for task in tasks:
                    if task['tag'] in ('info', 'info_recovery'):
                        future = ex.submit(backend.search_publications, task['query'],
                                           max_results=max_results, name=name)
                    elif task['tag'] == 'site' and task['platform']:
                        future = ex.submit(backend.search_profiles, task['query'], max_results=max_results,
                                           platform=task['platform'], name=name)
                    else:
                        future = ex.submit(backend.search, task['query'], max_results=max_results)
                    futs.append((task, future))
                for t, fut in futs:
                    try:
                        out.append({**t, "hits": fut.result(), "err": None})
                    except Exception as e:  # noqa: BLE001 — one query mustn't kill the run
                        out.append({**t, "hits": [], "err": repr(e)})
                return out

        def _absorb_web_info(hits, *, skip_urls: set[str] | None = None) -> None:
            skip_urls = skip_urls or set()
            for h in hits:
                url = canonical_source_url(h.url)
                if not url:
                    continue
                host = (urlparse(url).hostname or '').lower()
                if h.url in skip_urls or _is_junk_info(url):
                    continue
                # Raw www/tracking aliases of profiles must not consume source
                # slots intended for publications, websites and public posts.
                if any(_handle_from_url(p, url) for p in PLATFORMS):
                    continue
                key = url
                if key in info_seen:
                    source = info_seen[key]
                    source['search_evidence'].append({'query': h.query, 'provider': h.provider,
                        'source_url': h.url, 'excerpt': '\n'.join((h.title, h.snippet)),
                        'retrieved_at': h.retrieved_at, 'cached': h.cached, 'stale': h.stale, 'page': h.page})
                    for field in ('title', 'snippet'):
                        text = getattr(h, field)
                        if text and text not in source[field]:
                            source[field] = (source[field] + '\n' + text).strip()[:4000]
                    continue
                if len(source_hits) >= 100:
                    if not _info_contexts(name, {'title': h.title, 'snippet': h.snippet}, variants):
                        continue
                    # A flood of off-topic hits must not fill the internal
                    # bound before a later query returns a useful publication.
                    unproven = next((w for w in source_hits if not _info_contexts(name, w, variants)), None)
                    if unproven is None:
                        continue
                    source_hits.remove(unproven)
                    old_key = unproven['url']
                    info_seen.pop(old_key, None)
                info_seen[key] = {"url": url, "title": h.title,
                                  "snippet": h.snippet, 'query': h.query, 'provider': h.provider,
                                  'retrieved_at': h.retrieved_at, 'cached': h.cached,
                                  'cache_age_seconds': h.cache_age_seconds, 'stale': h.stale,
                                  'source_type': source_type(url),
                                  'search_evidence': [{'query': h.query, 'provider': h.provider,
                                      'source_url': h.url, 'excerpt': '\n'.join((h.title, h.snippet)),
                                      'retrieved_at': h.retrieved_at, 'cached': h.cached, 'stale': h.stale, 'page': h.page}]}
                source_hits.append(info_seen[key])

        # Build ONE query batch across every name variant and run it in a single
        # concurrent wave — so a second variant (e.g. the Cyrillic form of a
        # Latin-typed name) costs almost no extra wall-clock, not a doubling.
        #   1) site-scoped dorks (precise per-platform profile hits)
        #   2) a plain "name" query (nickname handles + corroborating pages)
        #   3) one combined dork sweeping X / GitHub / Telegram / TikTok / YT
        tasks: list[dict] = []
        info_queries = build_info_queries(name, variants, hints, platforms)
        for variant in variants:
            for platform, query in build_queries(variant, hints):
                if platform in platforms:
                    if query_budget is not None and variant != name and platform != 'linkedin':
                        continue
                    tasks.append({"tag": "site", "platform": platform,
                                  "query": query, "variant": variant})
            if query_budget is not None and variant != name:
                continue
            tasks.append({"tag": "web", "platform": None,
                          "query": f'"{variant}"', "variant": variant})
            if variant == name:
                # Publication discovery gets capacity before long-tail account
                # retries, and continues even when LinkedIn has already matched.
                tasks.extend({'tag': 'info', 'platform': None, 'query': query,
                              'variant': name} for query in info_queries)
            for extra_query in build_extra_queries(variant, platforms):
                tasks.append({"tag": "extra", "platform": None,
                              "query": extra_query, "variant": variant})

        for r in _run_searches(tasks, max_per_platform * 2):
            variant, hits = r["variant"], r["hits"]
            if r["err"]:
                result.errors.append(f"{r['platform'] or r['tag']}: {r['err']}")
                continue
            if r["tag"] == "site":
                _keep(classify(name, hints, r["platform"], hits, rejected_urls=rejected_urls))
                _absorb_web_info(hits)
            elif r["tag"] == "web":
                social_urls: set[str] = set()
                for p in platforms:
                    candidates = classify(name, hints, p, hits, rejected_urls=rejected_urls)
                    social_urls.update(c.url for c in candidates)
                    _keep(candidates)
                _absorb_web_info(hits, skip_urls=social_urls)
            elif r["tag"] in {"extra", "info"}:
                for p in platforms:
                    _keep(classify(name, hints, p, hits, rejected_urls=rejected_urls))
                _absorb_web_info(hits)

        # Spend at most two slots on observed leads before generic retries.
        # Keep LinkedIn's fallback capacity when that primary source is missing.
        pivot_limit = 2
        if query_budget is not None:
            reserve = 2 if 'linkedin' in platforms and not any(
                c.platform == 'linkedin' and c.name_match for c in result.candidates) else 0
            pivot_limit = min(2, max(0, backend.remaining_queries - reserve))
        pivots = build_pivot_queries(name, result.candidates, limit=pivot_limit)
        pivot_tasks = [{'tag': 'pivot', 'platform': None, 'variant': name, **p} for p in pivots]
        for r in _run_searches(pivot_tasks, max_per_platform * 2):
            if r['err']:
                result.errors.append(f"pivot: {r['err']}")
                continue
            for platform in platforms:
                _keep(classify(name, hints, platform, r['hits'], rejected_urls=rejected_urls))
            _absorb_web_info(r['hits'])
        result.stats['search_pivots'] = pivots

        # ESCALATION — only when few direct accounts were found, so the common
        # case stays lean. Two things happen here:
        #  a) PLAIN (unquoted) queries. A quoted `site:` dork often returns 0 for
        #     gated networks (LinkedIn especially — search engines index it
        #     sparsely), yet the SAME name without quotes / with a plain keyword
        #     returns the profile. So we also "just look with an ordinary query".
        #  b) Community/hub pages (KZ tech + hackathons + GitHub-by-name) that tie
        #     a real NAME to a person's accounts, read later for cross-links.
        esc: list[dict] = []
        if not any(c.name_match for c in result.candidates):
            for variant in (variants[:1] if query_budget is not None else variants):
                # the plain "ordinary query" — no quotes, no site: filter
                esc.append({"tag": "plain", "platform": None,
                            "query": variant, "variant": variant})
                # unquoted sweep of the remaining networks by name
                if query_budget is None:
                    esc.append({"tag": "extra", "platform": None,
                                "query": build_extra_query(variant).replace('"', ""),
                                "variant": variant})
            for hq in (() if query_budget is not None else (f'site:astanahub.com "{name}"',
                       f'(site:devpost.com OR site:dorahacks.io) "{name}"',
                       f'site:github.com "{name}"')):
                esc.append({"tag": "hub", "platform": None, "query": hq, "variant": name})

        # Coverage is platform-specific: a GitHub/Instagram match must not stop
        # LinkedIn (or another primary network) from trying an unquoted query.
        covered = {c.platform for c in result.candidates if c.name_match}
        recovery_counts = {platform: 0 for platform in platforms}
        for platform, fragment in SITE_FRAG.items():
            if platform in platforms and platform not in covered:
                recovery_variants = variants[:3] if query_budget is None or platform == 'linkedin' else variants[:1]
                for variant in recovery_variants:
                    # Separate quoted components allow reordered names and
                    # middle names while retaining both terms in the query.
                    terms = ' '.join(f'"{part}"' for part in variant.replace('"', '').split()) if platform == 'linkedin' else variant
                    esc.append({'tag': 'site', 'platform': platform,
                                'query': f'{fragment} {terms}', 'variant': variant})
                    recovery_counts[platform] += 1

        # A combined OR query may contain hits from only one network. Explicitly
        # query uncovered platforms once; unrelated accounts must not stop discovery.
        covered = {c.platform for c in result.candidates if c.name_match}
        # Reserve two query slots for LinkedIn's existing final recovery. The
        # grouped first wave has already searched all requested extra sites.
        if query_budget is not None:
            recovery_limit = max(0, backend.remaining_queries - len(esc)
                                 - (2 if 'linkedin' in platforms and 'linkedin' not in covered else 0))
        else:
            recovery_limit = len(_EXTRA_SITE_QUERIES)
        for platform, fragment in _EXTRA_SITE_QUERIES.items():
            if platform in platforms and platform not in covered:
                if recovery_limit <= 0:
                    break
                esc.append({'tag': 'site', 'platform': platform,
                            'query': f'{fragment} "{name}"', 'variant': name})
                recovery_limit -= 1

        for r in _run_searches(esc, max_per_platform * 2):
            if r["err"]:
                result.errors.append(f"{r['tag']}: {r['err']}")
                continue
            hh, variant = r["hits"], r["variant"]
            if r["tag"] == "site":
                _keep(classify(name, hints, r["platform"], hh, rejected_urls=rejected_urls))
            else:                       # plain / extra / hub -> try every platform
                for platform in platforms:
                    _keep(classify(name, hints, platform, hh, rejected_urls=rejected_urls))
            _absorb_web_info(hh)

        # LinkedIn exact-phrase /in/ searches can miss reordered names and legacy
        # /pub/ or regional results. Relax in bounded waves, stopping as soon as
        # a named profile is retrieved. No URLs are guessed from a person's name.
        if 'linkedin' in platforms:
            for template in ('site:linkedin.com {name}', '{name} LinkedIn'):
                if any(c.platform == 'linkedin' and c.name_match for c in result.candidates):
                    break
                li_tasks = [{'tag': 'site', 'platform': 'linkedin', 'variant': variant,
                             'query': template.format(name=variant)}
                            for variant in (variants[:1] if query_budget is not None else variants[:3])]
                recovery_counts['linkedin'] += len(li_tasks)
                for r in _run_searches(li_tasks, max_per_platform * 2):
                    if r['err']:
                        result.errors.append(f"linkedin recovery: {r['err']}")
                        continue
                    _keep(classify(name, hints, 'linkedin', r['hits'], rejected_urls=rejected_urls))
                    _absorb_web_info(r['hits'])
        result.stats['platform_recovery_queries'] = recovery_counts

        # Spend a small part of the remaining direct-search capacity on deeper
        # pages of queries with actual target evidence. Never paginate noise.
        checkpoint('deeper_search')
        productive = {e['query'] for c in result.candidates if c.name_match
                      for e in c.evidence if e.get('kind') == 'search_result' and e.get('query')}
        productive.update(w['query'] for w in source_hits if _info_contexts(name, w, variants))
        page_queries = sorted((r for r in backend.records if r['query'] in productive
                               and r.get('page', 1) == 1 and r.get('results')),
                              key=lambda r: (-r['results'], r['sequence']))[:3]
        result.stats['additional_search_pages'] = 0
        if backend.supports_paging:
            for record in page_queries:
                for page_number in (2, 3):
                    if backend.remaining_queries == 0 or result.stats['additional_search_pages'] >= 6:
                        break
                    before = (len(seen), sum(bool(_info_contexts(name, w, variants)) for w in source_hits))
                    try:
                        hits = backend.search_page(record['query'], max_results=max_per_platform * 2,
                                                   page=page_number, platform=record.get('platform', ''),
                                                   name=record.get('target_name', ''))
                    except Exception as exc:
                        result.errors.append('pagination: ' + type(exc).__name__)
                        break
                    result.stats['additional_search_pages'] += 1
                    for platform in platforms:
                        _keep(classify(name, hints, platform, hits, rejected_urls=rejected_urls))
                    _absorb_web_info(hits)
                    after = (len(seen), sum(bool(_info_contexts(name, w, variants)) for w in source_hits))
                    if not hits or after == before:
                        break

        # Extra capacity follows observed accounts, after broad source coverage.
        # Stop only this optional continuation on a plateau, never skip the
        # mandatory related-person fallback because target queries were empty.
        extra_pivots = []
        plateau = 0
        if query_budget is not None and query_budget > 24:
            used_queries = {r['query'] for r in backend.records}
            for pivot in build_pivot_queries(name, result.candidates, limit=8):
                if pivot['query'] in used_queries:
                    continue
                if backend.remaining_queries == 0 or plateau >= 2:
                    break
                before = (len(seen), sum(bool(_info_contexts(name, w, variants)) for w in source_hits))
                for r in _run_searches([{'tag': 'pivot', 'platform': None, 'variant': name, **pivot}], max_per_platform * 2):
                    if r['err']:
                        result.errors.append(f"pivot: {r['err']}")
                        continue
                    for platform in platforms:
                        _keep(classify(name, hints, platform, r['hits'], rejected_urls=rejected_urls))
                    _absorb_web_info(r['hits'])
                extra_pivots.append(pivot)
                after = (len(seen), sum(bool(_info_contexts(name, w, variants)) for w in source_hits))
                plateau = plateau + 1 if after == before else 0
        pivots.extend(extra_pivots)
        result.stats['optional_pivots_stopped_on_plateau'] = plateau >= 2

        # Account retries cannot consume the small publication recovery reserve.
        # These queries simplify failed dorks and vary name order/script; they
        # never relax the final source-to-person evidence requirement.
        checkpoint('publications')
        backend.reserve_queries(related_reserve)
        named_sources = [w for w in source_hits if _info_contexts(name, w, variants)]
        named_vk = any((urlparse(w['url']).hostname or '').removeprefix('www.') in
                       ('vk.com', 'vk.ru', 'm.vk.com', 'm.vk.ru') for w in named_sources)
        recovery_info = build_info_recovery_queries(name, variants, platforms,
            need_web=len(named_sources) < 3, need_vk=not named_vk)
        recovery_info = [q for q in recovery_info if q not in info_queries][:publication_reserve or 6]
        tasks = [{'tag': 'info_recovery', 'platform': None, 'variant': name, 'query': q}
                 for q in recovery_info[:backend.remaining_queries] if q]
        for r in _run_searches(tasks, max_per_platform * 2):
            if r['err']:
                result.errors.append('publication recovery: ' + r['err'])
                continue
            _absorb_web_info(r['hits'])
            for platform in platforms:
                _keep(classify(name, hints, platform, r['hits'], rejected_urls=rejected_urls))
        info_queries.extend(recovery_info)
        result.stats['publication_recovery_queries'] = len(tasks)
        checkpoint('public_pages')

        # Source pages are useful even when the search engine found NO account.
        # Prefer sources whose snippets name the target; keep the page budget explicit.
        social_domains = tuple(SOCIAL_HOSTS)

        def _source_rank(web):
            host = (urlparse(web['url']).hostname or '').lower()
            social = any(host == d or host.endswith('.' + d) for d in social_domains)
            named = bool(_info_contexts(name, web, variants))
            return named, not social

        ranked = sorted(source_hits, key=_source_rank, reverse=True)
        # Reserve the front of the page budget for different hosts; indexed
        # reels from one gated network must not crowd out the open-web articles.
        hosts: dict[str, int] = {}
        diverse, deferred = [], []
        for web in ranked:
            host = urlparse(web['url']).hostname
            hosts[host] = hosts.get(host, 0) + 1
            (diverse if hosts[host] <= 2 else deferred).append(web)
        # Apply the relevance gate before the display limit. Unrelated hosts
        # must not crowd out a named publication from an already-seen host.
        relevant_sources = [w for w in diverse + deferred if _info_contexts(name, w, variants)]
        ranked_sources = relevant_sources[:25]
        sources = [(w['url'], f"{w['title']}\n{w['snippet']}") for w in ranked_sources]
        def _read_pages(pages: list[Candidate], metric: str):
            if not pages:
                return []
            with ThreadPoolExecutor(max_workers=min(3, len(pages))) as pool:
                futures = [(page, pool.submit(enrich_candidate, page, client)) for page in pages]
                read = []
                for page, future in futures:
                    try:
                        future.result()
                        result.stats[metric] += 1
                        if getattr(page, 'fetch_status', '') == 'ok':
                            result.stats[metric.replace('_read', '_ok')] += 1
                        if getattr(page, 'fetch_status', '') == 'error':
                            result.stats['page_errors'] += 1
                            result.errors.append(f"[page] {page.url}: {page.fetch_error}")
                        read.append(page)
                    except Exception as exc:
                        result.stats['page_errors'] += 1
                        result.errors.append(f"[page] {page.url}: {type(exc).__name__}")
                return read

        read_limit = max(0, min(fetch_pages, 8))
        # A named repository owner or article slug is a lead for a bounded
        # read, never sufficient evidence for display. Search snippets often
        # omit an author's name that is present in the body/README.
        pivot_queries = {p['query'] for p in pivots}
        probe_queries = {*info_queries, *(f'"{v}"' for v in variants),
                         *(quoted_terms(v) for v in variants)}
        def _named_source_url(web):
            return any(is_name_match(name, SearchResult(web['url']), segment)
                       for segment in unquote(urlparse(web['url']).path).split('/') if segment)
        backlink_queries = {p['query'] for p in pivots if p['kind'] == 'backlink'}
        def _probe_rank(web):
            queries = evidenced_pivot_queries(web, pivots)
            import re
            visible = ' '.join((web['title'], web['snippet'], unquote(urlparse(web['url']).path)))
            tokens = {token.casefold() for v in variants for token in v.split()}
            overlap = sum(bool(re.search(r'(?<!\w)' + re.escape(t) + r'(?!\w)', visible, re.I)) for t in tokens)
            return _named_source_url(web), bool(queries & backlink_queries), bool(queries & pivot_queries), overlap
        probes, probe_hosts = [], {}
        probe_limit = min(read_limit, max(2, read_limit - len(ranked_sources)))
        for web in sorted(ranked, key=_probe_rank, reverse=True):
            if web in ranked_sources:
                continue
            parsed = urlparse(web['url'])
            named_url = _named_source_url(web)
            social = any(parsed.hostname == host or parsed.hostname.endswith('.' + host)
                         for host in social_domains)
            targeted_query = bool(evidenced_pivot_queries(web, pivots)) or any(
                ev['query'] in (set(info_queries) if social else probe_queries)
                for ev in web['search_evidence'])
            if (probe_hosts.get(parsed.hostname, 0) >= 2 or not parsed.path.strip('/')
                    or not is_publication_url(web['url'])
                    or not (named_url or targeted_query)):
                continue
            probes.append(web)
            probe_hosts[parsed.hostname] = probe_hosts.get(parsed.hostname, 0) + 1
            if len(probes) >= probe_limit:
                break
        # Reserve bounded body reads even if other sources already match.
        # Discovery by a dork is only a read lead, never a display pass.
        probes = probes[:probe_limit]
        to_read = ranked_sources[:max(0, read_limit - len(probes))] + probes
        ranked_sources.extend(probes)
        result.stats['source_probe_reads'] = len(probes)
        pages = [Candidate(platform='web', url=w['url'], title=w['title'], snippet=w['snippet'])
                 for w in to_read]
        by_url = {w['url']: w for w in ranked_sources}
        for page in _read_pages(pages, 'source_pages_read'):
            web = by_url[page.url]
            web['fetch_status'] = page.fetch_status
            web['fetch_error'] = page.fetch_error
            linked = profile_link_evidence(page.public_links, result.candidates)
            if linked:
                web['profile_connection'] = linked
            if page.public_text:
                sources.append((page.url, page.public_text))
                # The manual continuation must retain late co-mentions too.
                by_url[page.url]['excerpt'] = page.public_text[:24000]
            _keep(_linked_candidates(name, variants, hints, page, rejected_urls=rejected_urls))

        # Every displayed source supplies a name context or an explicit link
        # to a named profile. An unverified query/URL never passes on its own.
        result.web_info = []
        for web in ranked_sources:
            contexts = _info_contexts(name, web, variants)
            if contexts or web.get('profile_connection'):
                if contexts:
                    web['name_context'] = contexts[0]
                web['evidence_kind'] = 'name_mention' if contexts else 'profile_link'
                result.web_info.append(web)
        result.web_info = result.web_info[:25]
        result.stats['web_sources_without_name'] = sum(
            not _info_contexts(name, w, variants) for w in source_hits)
        publication_records = [r for r in backend.records if r['query'] in info_queries]
        vk_records = [r for r in publication_records if 'site:vk.' in r['query']]
        result.stats['publication_diagnostics'] = {
            'queries': len(publication_records), 'planned_queries': len(info_queries),
            'unavailable_queries': sum(r['status'] in ('error', 'unavailable') for r in publication_records),
            'raw_results': sum(r.get('results', 0) for r in publication_records),
            'considered_sources': len(source_hits), 'read_pages': result.stats['source_pages_read'],
            'read_errors': sum(w.get('fetch_status') in ('error', 'empty') for w in to_read),
            'retained_sources': len(result.web_info),
            'unread_sources': sum(w.get('fetch_status', 'not_read') == 'not_read' for w in source_hits),
            'vk_queries': len(vk_records),
            'vk_results': sum(sum((urlparse(u).hostname or '').removeprefix('www.') in
                                 ('vk.com', 'vk.ru', 'm.vk.com', 'm.vk.ru') for u in r.get('result_urls', []))
                              for r in vk_records),
            'rejected_read_sources': [{'url': w['url'], 'title': w['title'], 'reason':
                'unavailable' if w.get('fetch_status') in ('error', 'empty') else 'no_name_or_profile_link',
                'fetch_error': w.get('fetch_error', '')}
                for w in to_read if w not in result.web_info],
        }

        # by-name finds lead, then by score — a direct name hit is never buried.
        result.candidates.sort(key=lambda c: (c.name_match, c.score), reverse=True)

        checkpoint('profiles')
        named_profiles = [c for c in result.candidates if c.name_match or c.confirmed]
        for c in _read_pages(named_profiles[:max(0, min(enrich_profiles, 4))], 'profile_pages_read'):
            if has_owner_name_conflict(name, c.title, c.handle):
                flag_owner_conflict(c)
                c.evidence.append({'kind': 'owner_name_conflict', 'source_url': c.url,
                                   'excerpt': c.title, 'provider': 'public_page'})
                continue
            _keep(_linked_candidates(name, variants, hints, c, owner=c, rejected_urls=rejected_urls))

        # Account multiplier: pivot the best handles across other networks, so
        # one found account yields the person's other profiles. Bounded to the
        # top handles — good ranking puts the real person first, so this stays
        # on-target and cheap. This is the account-centric core of the OSINT.
        checkpoint('usernames')
        if username_scan and max_scan_handles > 0 and result.candidates:
            from .username import check_username, valid_handle
            scanned_urls = {c.url.rstrip("/").lower() for c in result.candidates}
            handles: list[str] = []
            hset: set[str] = set()
            for c in result.candidates:
                if not c.name_match:
                    continue
                h = valid_handle(c.handle)
                if h and h.lower() not in hset:
                    hset.add(h.lower())
                    handles.append(h)
                if len(handles) >= max_scan_handles:
                    break
            for h in handles:
                try:
                    if username_provider == 'maigret':
                        from .maigret_scan import scan_username
                        scan = scan_username(h)
                        result.stats.setdefault('username_scans', []).append({
                            'handle': h, **{k: v for k, v in scan.items() if k != 'accounts'}})
                        if scan['partial']:
                            result.errors.append(f'[username] @{h}: часть площадок недоступна или ответ не подтверждает профиль')
                        accounts = scan['accounts']
                    else:
                        accounts = check_username(h)
                    for a in accounts:
                        key = a["url"].rstrip("/").lower()
                        scanned_urls.add(key)
                        _keep([Candidate(
                            platform=a["site"], url=a["url"], handle=h,
                            score=0.25, expanded_from=h, note=a.get("note", ""),
                            title=a.get('title', ''),
                            relation='username', match_reasons=['Совпадает ник; владелец не подтверждён'],
                            evidence=a.get('evidence') or [{'kind': 'username', 'source_url': a['url'], 'excerpt': h}])])
                except Exception as e:  # noqa: BLE001 — never kill the run
                    result.errors.append(f"expand {h}: {e!r}")

        # Requirement 2: if the target's own accounts weren't found, reach them
        # via people mentioned nearby and propose accounts from their networks.
        backend.reserve_queries(0)
        if related_search == 'always' or (related_search == 'auto' and not any(
                c.name_match and c.relation != 'username' for c in result.candidates)):
            from .related import discover_via_related
            checkpoint('related')
            result.related_searched = True
            rel = discover_via_related(name, backend, client=client, sources=sources, variants=variants)
            result.related_people = rel["people"]
            result.related_evidence = rel.get('evidence', [])
            result.stats.update(rel.get('stats', {}))
            # A hit reached via a nearby person can STILL carry the target's own
            # name — that's a real by-name find, not an associate. Promote those
            # to primary candidates so they're never hidden in the "related"
            # bucket; only genuine associate accounts stay separate.
            for c in rel["candidates"]:
                if c.relation == 'via_related':
                    _keep([c])
                else:
                    result.related_accounts.append(c)
            result.candidates.sort(key=lambda c: (c.name_match, c.score),
                                   reverse=True)
            result.errors.extend(rel["errors"])

        _keep([])
        result.excluded_profile_urls = sorted(rejected_urls)

        # Namesake disambiguation: group same-identity accounts and record which
        # hints each hit matches, so the analyst can separate people who share
        # the name. Grouping never drops a candidate — recall is preserved.
        from .identity import annotate_identity
        n_groups = annotate_identity(name, hints, result.candidates)
        if n_groups > 1:
            result.errors.append(
                f"[info] Гипотез группировки аккаунтов: {n_groups}. "
                f"Общий ник не подтверждает одного владельца; уточните город/работодателя.")

        result.candidates.sort(key=lambda c: (c.name_match, c.score), reverse=True)
        result.stats.update(backend.stats())
        result.stats['publication_diagnostics']['partial'] = (
            result.stats['search_degraded'] or result.stats['publication_diagnostics']['read_errors'] > 0
            or len(publication_records) < len(info_queries))
        result.stats['query_yield'] = query_yield_report(
            backend.records, [*result.candidates, *result.related_accounts], result.web_info, pivots)
        result.stats['publication_queries'] = sum(
            record['query'] in info_queries for record in backend.records)
        result.stats['publication_results'] = len(result.web_info)
        result.stats['search_degraded'] = result.stats.get('search_degraded', False) or any(
            scan['partial'] for scan in result.stats.get('username_scans', []))
        result.stats.update(candidate_count=len(result.candidates),
                            excluded_owner_profiles=len(rejected_urls),
                            owner_conflict_suggestions=sum('owner_name_conflict' in c.match_reasons for c in result.candidates),
                            related_searched=result.related_searched,
                            with_evidence=sum(bool(c.evidence) for c in result.candidates),
                            seconds=round(time.monotonic() - started, 3))
        if 'linkedin' in platforms:
            li_candidates = [c for c in result.candidates if c.platform == 'linkedin']
            li_named = sum(c.name_match for c in li_candidates)
            result.stats.update(linkedin_candidates=len(li_candidates), linkedin_name_matches=li_named,
                                linkedin_recovery_queries=recovery_counts['linkedin'])
            if not li_named:
                result.errors.append('[info] LinkedIn: профиль с совпадением имени в доступной выдаче '
                                     'не найден. Это не означает, что аккаунта нет; '
                                     'остальные ссылки остаются неподтверждёнными предложениями.')
        for e in getattr(backend, "errors", []):
            result.errors.append(f"[backend] {e}")
    finally:
        client.close()
        if search_client is not None:
            search_client.close()
    return result


def enrich(
    candidates: list[Candidate],
    client: PoliteClient | None = None,
) -> list[Candidate]:
    """Fetch public text for each (confirmed) candidate. Network-bound."""
    own = client is None
    client = client or PoliteClient()
    try:
        return [enrich_candidate(c, client) for c in candidates]
    finally:
        if own:
            client.close()


def discover_related(name: str, hints: dict | None = None,
                     web_info: list[dict] | None = None, *, search_mode: str | None = None) -> DiscoveryResult:
    """Explicit continuation after the user rejected the direct suggestions."""
    from .related import discover_via_related
    started = time.monotonic()
    result = DiscoveryResult(query_name=name, hints=hints or {}, related_searched=True)
    result.web_info = (web_info or [])[:25]
    sources = [(w['url'], '\n'.join(str(w.get(k, ''))[:24000]
                                    for k in ('title', 'snippet', 'excerpt')))
               for w in result.web_info if w.get('url')]
    with PoliteClient(min_interval=0.3, timeout=15, max_retries=2) as search_client, \
            PoliteClient(min_interval=0.3, timeout=8, max_retries=1) as page_client:
        from .config import DiscoveryConfig
        from dataclasses import replace
        config = DiscoveryConfig.from_env()
        if search_mode is not None:
            config = replace(config, search_mode=search_mode)
        backend = SearchRun(default_backend(search_client, config), max_queries=12)
        related = discover_via_related(name, backend, client=page_client,
                                       sources=sources, variants=name_variants(name))
        result.related_people = related['people']
        result.related_evidence = related.get('evidence', [])
        result.errors = related['errors'] + [f'[backend] {e}' for e in backend.errors]
        for candidate in related['candidates']:
            destination = result.candidates if candidate.relation == 'via_related' else result.related_accounts
            destination.append(candidate)
        from .identity import annotate_identity
        annotate_identity(name, hints or {}, result.candidates)
        result.candidates.sort(key=lambda c: (c.name_match, c.score), reverse=True)
        result.stats = {**related.get('stats', {}), **backend.stats(), 'related_searched': True,
                        'search_mode': config.search_mode,
                        'seconds': round(time.monotonic() - started, 3)}
    return result


def candidates_to_profile(
    name: str,
    candidates: list[Candidate],
    hints: dict | None = None,
) -> Profile:
    """Fold enriched candidates into a Profile for the offline engine.

    Names/hints go to their structured fields; harvested keywords land in
    `custom` (later refined by the NER layer into interests/pets/etc.).
    """
    hints = hints or {}
    parts = name.split()
    profile = Profile(
        first_name=parts[0] if parts else "",
        last_name=parts[-1] if len(parts) > 1 else "",
        city=hints.get("city", ""),
        country=hints.get("country", ""),
        employer=hints.get("employer", ""),
        job_title=hints.get("job_title", ""),
    )
    kw: list[str] = []
    seen: set[str] = set()
    for c in candidates:
        if c.handle and c.handle.lower() not in seen:
            seen.add(c.handle.lower())
            kw.append(c.handle)
        for k in c.keywords:
            if k.lower() not in seen:
                seen.add(k.lower())
                kw.append(k)
    profile.custom = kw
    return profile
