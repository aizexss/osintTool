"""Pluggable search backends with automatic fallback.

Priority (first available & non-empty wins):
    1. Serper.dev          (SERPER_API_KEY)          — reliable, keyed
    2. Google CSE JSON API (GOOGLE_CSE_KEY + _CX)    — reliable, keyed
    3. SearXNG             (SEARXNG_URL, self-host)  — free, private, no key
    4. Playwright/Bing     (optional dep)            — free, renders JS
    5. DuckDuckGo HTML     (scrape)                  — free, often gated

Each backend advertises `is_available()`. Generic searches stop at the first
nonempty provider; profile searches continue until a profile matches the target
name and platform, retaining partial results. A production deploy sets a key
(1/2) or runs SearXNG (3); the free scrapers are last-ditch.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import threading
import time
import urllib.parse
from collections import OrderedDict
from concurrent.futures import Future
from dataclasses import replace
from datetime import datetime, timezone
from contextlib import nullcontext
from typing import Protocol, runtime_checkable

from bs4 import BeautifulSoup

from .config import DiscoveryConfig
from .http import PoliteClient
from .models import SearchResult
from .provider_state import ProviderError, provider_state, response_error
from . import cache as disk_cache
from .searxng_engines import engine_pool


# Short-lived process cache, backed by SQLite: repeating a search should not
# immediately resend identical successful queries to free engines. Never retain
# errors or empty responses, since they may be temporary provider failures.
_RESPONSE_CACHE_TTL = 600.0
_RESPONSE_CACHE_STALE_TTL = 3600.0
_RESPONSE_CACHE_MAX_ENTRIES = 256
_RESPONSE_CACHE: OrderedDict[tuple[str, str, int], tuple[float, list[SearchResult]]] = OrderedDict()
_RESPONSE_CACHE_LOCK = threading.Lock()
_PROVIDER_INTERVALS = {'searxng': 1.5, 'duckduckgo': 1.5}
_INFLIGHT: dict[tuple[str, str, int], Future] = {}
_INFLIGHT_LOCK = threading.Lock()


def _cache_scope(*configuration: str) -> str:
    # Scope credentials/endpoints without storing or exposing their raw values
    # in cache keys, metrics or diagnostics.
    return hashlib.sha256(json.dumps(configuration).encode('utf-8')).hexdigest()


def _cached_response(scope: str, query: str, max_results: int, *, stale: bool = False) -> list[SearchResult] | None:
    key = (scope, query, max_results)
    now = time.monotonic()
    with _RESPONSE_CACHE_LOCK:
        for expired in [item for item, (saved, _) in _RESPONSE_CACHE.items()
                        if saved + _RESPONSE_CACHE_STALE_TTL <= now]:
            del _RESPONSE_CACHE[expired]
        cached = _RESPONSE_CACHE.get(key)
        if cached is None:
            persisted = disk_cache.read(scope, query, max_results)
            if persisted is None:
                return None
            age, hits = persisted
            cached = _RESPONSE_CACHE[key] = (now - age, hits)
            while len(_RESPONSE_CACHE) > _RESPONSE_CACHE_MAX_ENTRIES:
                _RESPONSE_CACHE.popitem(last=False)
        age = max(0, int(now - cached[0]))
        expired = now - cached[0] >= _RESPONSE_CACHE_TTL
        if expired and not stale:
            return None
        _RESPONSE_CACHE.move_to_end(key)
        return [replace(hit, cached=True, cache_age_seconds=age, stale=expired) for hit in cached[1]]


def _remember_response(scope: str, query: str, max_results: int, hits: list[SearchResult]) -> None:
    key = (scope, query, max_results)
    disk_cache.write(scope, query, max_results, hits)
    if not hits:
        # A successful empty refresh invalidates an older answer. Do not
        # resurrect it during a later outage, and do not cache the empty reply.
        with _RESPONSE_CACHE_LOCK:
            _RESPONSE_CACHE.pop(key, None)
        return
    with _RESPONSE_CACHE_LOCK:
        _RESPONSE_CACHE[key] = (time.monotonic(),
                                [replace(hit) for hit in hits])
        _RESPONSE_CACHE.move_to_end(key)
        while len(_RESPONSE_CACHE) > _RESPONSE_CACHE_MAX_ENTRIES:
            _RESPONSE_CACHE.popitem(last=False)


@runtime_checkable
class SearchBackend(Protocol):
    name: str

    def is_available(self) -> bool: ...
    def search(self, query: str, max_results: int = 20) -> list[SearchResult]: ...


# --------------------------------------------------------------------------- #
# Keyed backends
# --------------------------------------------------------------------------- #
class SerperBackend:
    name = "serper"
    URL = "https://google.serper.dev/search"

    def __init__(self, api_key: str, client: PoliteClient) -> None:
        self._key = api_key
        self._client = client
        self._response_cache_scope = _cache_scope(self.name, self.URL, api_key)
        self._health = threading.Condition()
        self._probe_in_progress = False
        self._probed = False
        self._disabled_reason = ""

    def is_available(self) -> bool:
        with self._health:
            return bool(self._key) and not self._disabled_reason

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        # Check an exhausted/invalid account once per run, including concurrent
        # searches. Query-specific errors must not disable the whole provider.
        with self._health:
            while self._probe_in_progress:
                self._health.wait()
            if self._disabled_reason:
                raise RuntimeError(self._disabled_reason)
            probing = not self._probed
            if probing:
                self._probe_in_progress = True
        try:
            return self._search_once(query, max_results)
        finally:
            if probing:
                with self._health:
                    self._probed = True
                    self._probe_in_progress = False
                    self._health.notify_all()

    def _disable(self, reason: str) -> None:
        with self._health:
            self._disabled_reason = "Serper unavailable: " + reason
        raise ProviderError(reason, cooldown=300, message=self._disabled_reason)

    def _search_once(self, query: str, max_results: int) -> list[SearchResult]:
        # Serper's free plan rejects num > 10 ("Query pattern not allowed for
        # free accounts"), so clamp it — a single page is plenty for discovery.
        num = min(max_results, 10)
        resp = self._client.post(
            self.URL,
            headers={"X-API-KEY": self._key, "Content-Type": "application/json"},
            content=json.dumps({"q": query, "num": num}),
            request_attempts=1,
        )
        if resp is not None and resp.status_code in (401, 403):
            self._disable("authentication_failed")
        if resp is not None and resp.status_code == 400:
            try:
                message = str(resp.json().get("message", "")).casefold()
            except (ValueError, AttributeError):
                message = ""
            if "not enough credits" in message or "insufficient credits" in message:
                self._disable("insufficient_credits")
        if resp is None or resp.status_code != 200:
            raise response_error(self.name, resp)
        data = resp.json()
        out: list[SearchResult] = []
        for item in data.get("organic", [])[:max_results]:
            out.append(SearchResult(
                url=item.get("link", ""),
                title=item.get("title", ""),
                snippet=item.get("snippet", ""),
            ))
        return [r for r in out if r.url]


class GoogleCSEBackend:
    name = "google_cse"
    URL = "https://www.googleapis.com/customsearch/v1"

    def __init__(self, api_key: str, cx: str, client: PoliteClient) -> None:
        self._key = api_key
        self._cx = cx
        self._client = client
        self._response_cache_scope = _cache_scope(self.name, self.URL, api_key, cx)

    def is_available(self) -> bool:
        return bool(self._key and self._cx)

    def search(self, query: str, max_results: int = 10) -> list[SearchResult]:
        # CSE returns max 10 per call; we take the first page.
        resp = self._client.get(self.URL, request_attempts=1, params={
            "key": self._key, "cx": self._cx, "q": query,
            "num": min(max_results, 10),
        })
        if resp is None or resp.status_code != 200:
            raise response_error(self.name, resp)
        data = resp.json()
        out: list[SearchResult] = []
        for item in data.get("items", [])[:max_results]:
            out.append(SearchResult(
                url=item.get("link", ""),
                title=item.get("title", ""),
                snippet=item.get("snippet", ""),
            ))
        return [r for r in out if r.url]


# --------------------------------------------------------------------------- #
# Self-hosted / free backends
# --------------------------------------------------------------------------- #
class SearxngBackend:
    name = "searxng"

    def __init__(self, base_url: str, client: PoliteClient) -> None:
        self._base = base_url.rstrip("/")
        self._client = client
        import os
        # The instance knows which engines are enabled and healthy. A fixed
        # override can silently remove its working engines from every query.
        self._engines = os.environ.get("OSINT_SEARXNG_ENGINES", "").strip()
        self._response_cache_scope = _cache_scope(self.name, self._base, self._engines)
        self._engine_pool = engine_pool(self._response_cache_scope)
        self._warnings: set[str] = set()
        self._warning_lock = threading.Lock()

    @property
    def warnings(self) -> list[str]:
        with self._warning_lock:
            return sorted(self._warnings)

    def _record_engine_errors(self, entries) -> None:
        # Never reflect arbitrary upstream text: responses may include URLs,
        # query text or credentials. Keep only a bounded engine/status label.
        import re
        if not isinstance(entries, list):
            return
        for entry in entries[:30]:
            if not isinstance(entry, (list, tuple)) or len(entry) < 2:
                continue
            engine, raw_reason = str(entry[0]).lower(), str(entry[1]).casefold()
            if not re.fullmatch(r"[a-z0-9_. -]{1,40}", engine):
                engine = "unknown"
            reason = "engine_error"
            for token, label in (("captcha", "challenge"), ("too many", "rate_limited"),
                                 ("rate", "rate_limited"), ("timeout", "timeout"),
                                 ("timed out", "timeout"), ("parsing", "parse_error"),
                                 ("connection", "connection_error")):
                if token in raw_reason:
                    reason = label
                    break
            with self._warning_lock:
                self._warnings.add(f"engine {engine}: {reason}")

    def is_available(self) -> bool:
        return bool(self._base)

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        return self.search_page(query, max_results=max_results, page=1)

    def search_page(self, query: str, max_results: int = 20, *, page: int = 1) -> list[SearchResult]:
        if not 1 <= page <= 3:
            raise ValueError('Search page must be between 1 and 3')
        params = {"q": query, "format": "json", "safesearch": "0"}
        if page > 1:
            params['pageno'] = page
        if not self._engines:
            self._engine_pool.refresh_inventory(self._client, self._base)
        selected = [] if self._engines else self._engine_pool.choose(page)
        if selected is None:
            raise ProviderError('engines_paused' if page == 1 else 'paging_unavailable')
        if self._engines:
            params["engines"] = self._engines
        elif selected:
            params['engines'] = ','.join(selected)
        resp = self._client.get(f"{self._base}/search", params=params, request_attempts=1)
        if resp is None or resp.status_code != 200:
            raise response_error(self.name, resp)
        try:
            data = resp.json()
        except (json.JSONDecodeError, ValueError) as exc:
            raise ProviderError('invalid_response', cooldown=60) from exc
        if not isinstance(data, dict) or not isinstance(data.get('results'), list):
            raise ProviderError('invalid_response', cooldown=60)
        if not self._engines:
            self._engine_pool.observe(data, selected)
        self._record_engine_errors(data.get("unresponsive_engines", []))
        out: list[SearchResult] = []
        for item in data.get("results", [])[:max_results]:
            out.append(SearchResult(
                url=item.get("url", ""),
                title=item.get("title", ""),
                snippet=item.get("content", ""),
                provider="searxng" + (":" + str(item["engine"]) if item.get("engine") else ""),
                partial=bool(data.get('unresponsive_engines')),
                page=page,
            ))
        hits = [r for r in out if r.url]
        if not hits and data.get('unresponsive_engines'):
            # Some engines can still be healthy but empty for this query. Do
            # not suspend the entire instance on an individual engine failure.
            raise ProviderError('partial_engine_failure')
        return hits


def _decode_bing_redirect(url: str) -> str:
    """Bing wraps results as bing.com/ck/a?...&u=a1<base64url>. Unwrap it."""
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return url
    host = (parsed.hostname or '').lower()
    if not (host == 'bing.com' or host.endswith('.bing.com')) or parsed.path != '/ck/a':
        return url
    qs = urllib.parse.parse_qs(parsed.query)
    raw = qs.get("u", [""])[0]
    if raw.startswith(('https://', 'http://')):
        return raw
    if not raw.startswith('a1'):
        return url
    raw = raw[2:]
    raw += '=' * (-len(raw) % 4)
    try:
        target = base64.urlsafe_b64decode(raw).decode('utf-8')
        return target if target.startswith(('https://', 'http://')) else url
    except (binascii.Error, ValueError, UnicodeError):
        return url


class PlaywrightBackend:
    """Renders a real Bing results page with a headless browser.

    Optional: requires `pip install playwright` + `playwright install chromium`.
    Lazily imported so the rest of the tool works without it.
    """

    name = "playwright"

    def __init__(self) -> None:
        self._checked = False
        self._ok = False

    def is_available(self) -> bool:
        if self._checked:
            return self._ok
        self._checked = True
        try:
            import playwright  # noqa: F401
            self._ok = True
        except ImportError:
            self._ok = False
        return self._ok

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            return []

        url = "https://www.bing.com/search?q=" + urllib.parse.quote_plus(query)
        out: list[SearchResult] = []
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page(
                    user_agent=("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                "AppleWebKit/537.36 (KHTML, like Gecko) "
                                "Chrome/124.0 Safari/537.36")
                )
                page.goto(url, wait_until="domcontentloaded", timeout=25000)
                page.wait_for_timeout(1500)
                html = page.content()
                browser.close()
        except Exception:  # noqa: BLE001 — browser failures are non-fatal
            return []

        soup = BeautifulSoup(html, "html.parser")
        for li in soup.select("li.b_algo")[:max_results]:
            a = li.select_one("h2 a")
            if not a or not a.get("href"):
                continue
            snip = li.select_one(".b_caption p")
            out.append(SearchResult(
                url=_decode_bing_redirect(a["href"]),
                title=a.get_text(" ", strip=True),
                snippet=snip.get_text(" ", strip=True) if snip else "",
            ))
        return out


def _unwrap_ddg(href: str) -> str:
    try:
        parsed = urllib.parse.urlparse(urllib.parse.urljoin('https://duckduckgo.com', href))
    except ValueError:
        return href
    host = (parsed.hostname or '').lower()
    if (host == 'duckduckgo.com' or host.endswith('.duckduckgo.com')) and parsed.path == '/l/':
        qs = urllib.parse.parse_qs(parsed.query)
        if "uddg" in qs:
            target = qs['uddg'][0]  # parse_qs has already decoded this layer.
            if target.startswith(('https://', 'http://')):
                return target
    if href.startswith("//"):
        return "https:" + href
    return href


class DuckDuckGoBackend:
    name = "duckduckgo"
    URL = "https://html.duckduckgo.com/html/"

    def __init__(self, client: PoliteClient) -> None:
        self._client = client
        self._response_cache_scope = _cache_scope(self.name, self.URL)
        self._health = threading.Condition()
        self._probe_in_progress = False
        self._probed = False
        self._disabled_reason = ""

    def is_available(self) -> bool:
        with self._health:
            return not self._disabled_reason

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        # Only the first request probes availability. Waiting queries must not
        # repeat a blocked probe; once healthy, ordinary searches run concurrently.
        with self._health:
            while self._probe_in_progress:
                self._health.wait()
            if self._disabled_reason:
                raise RuntimeError(self._disabled_reason)
            probing = not self._probed
            if probing:
                self._probe_in_progress = True
        try:
            return self._search_once(query, max_results)
        finally:
            if probing:
                with self._health:
                    self._probed = True
                    self._probe_in_progress = False
                    self._health.notify_all()

    def _disable(self, reason: str) -> None:
        # Reasons are fixed labels/status codes, never response text or queries.
        with self._health:
            self._disabled_reason = "DuckDuckGo unavailable: " + reason
        code = ('challenge' if reason in ('HTTP 202', 'HTTP 403', 'challenge page') else
                'rate_limited' if reason == 'HTTP 429' else 'transport_error')
        raise ProviderError(code, cooldown=300 if code == 'challenge' else 60,
                            message=self._disabled_reason)

    def _search_once(self, query: str, max_results: int) -> list[SearchResult]:
        # A timeout must bound one attempt, not every retry of every query.
        try:
            resp = self._client.post(self.URL, data={"q": query}, timeout=6.0,
                                     request_attempts=1)
        except Exception:  # noqa: BLE001 — optional search transport is non-fatal
            self._disable("request failed")
        if resp is None:
            self._disable("request failed")
        if resp.status_code in (202, 403, 429) or resp.status_code >= 500:
            self._disable(f"HTTP {resp.status_code}")
        if resp.status_code != 200:
            return []
        soup = BeautifulSoup(resp.text, "html.parser")
        if soup.select_one('form#challenge-form, form#img-form, form[action*="anomaly.js"], '
                           '.anomaly-modal, input[type="password"]'):
            self._disable("challenge page")
        out: list[SearchResult] = []
        for res in soup.select("div.result"):
            a = res.select_one("a.result__a")
            if not a or not a.get("href"):
                continue
            url = _unwrap_ddg(a["href"])
            if not url.startswith("http"):
                continue
            snip = res.select_one(".result__snippet")
            out.append(SearchResult(
                url=url,
                title=a.get_text(" ", strip=True),
                snippet=snip.get_text(" ", strip=True) if snip else "",
            ))
            if len(out) >= max_results:
                break
        return out


# --------------------------------------------------------------------------- #
# Fallback orchestrator
# --------------------------------------------------------------------------- #
class FallbackBackend:
    """Tries available backends in priority order until one yields results."""

    name = "fallback"

    def __init__(self, backends: list[SearchBackend]) -> None:
        self.backends = backends
        self.last_used = ""
        self.errors: list[str] = []
        self.attempts: list[dict] = []
        self.provider_cache_hits = 0
        self.provider_response_cache_hits = 0
        self.stale_cache_hits = 0
        self._result_cache: dict[tuple[int, str, int, int], Future] = {}
        # The pipeline fans searches out across threads; guard shared state.
        self._lock = threading.Lock()

    def is_available(self) -> bool:
        return any(b.is_available() for b in self.backends)

    def _note(self, msg: str) -> None:
        with self._lock:
            if msg not in self.errors:            # errors accumulate across the
                self.errors.append(msg)           # concurrent run; keep it deduped

    @staticmethod
    def _scope(backend) -> str:
        # Injected/custom backends do not share process state.
        return (backend._response_cache_scope if type(backend) in
                (SerperBackend, GoogleCSEBackend, SearxngBackend, DuckDuckGoBackend) else '')

    def provider_statuses(self) -> list[dict]:
        rows = []
        for backend in self.backends:
            scope = self._scope(backend)
            row = {'provider': backend.name, 'status': 'ready' if backend.is_available() else 'disabled'}
            if scope:
                state = provider_state(scope).snapshot()
                if state['status'] == 'cooldown':
                    row.update(state)
            if isinstance(backend, SearxngBackend):
                row['engine_selection'] = ({'selection': 'explicit', 'selected': backend._engines.split(',')}
                    if backend._engines else backend._engine_pool.snapshot())
            rows.append(row)
        return rows

    def _request_provider(self, backend, query, max_results, scope, record, page=1):
        if not scope:
            return self._call_provider(backend, query, max_results, scope, record, page)
        key = (scope, query, max_results)
        with _INFLIGHT_LOCK:
            shared = _INFLIGHT.get(key)
            owner = shared is None
            if owner:
                shared = _INFLIGHT[key] = Future()
        if not owner:
            hits = shared.result()
            with self._lock:
                self.provider_response_cache_hits += 1
            return [replace(hit, cached=True) for hit in hits]
        try:
            hits = self._call_provider(backend, query, max_results, scope, record, page)
            shared.set_result(hits)
            return hits
        except Exception as exc:
            shared.set_exception(exc)
            raise
        finally:
            with _INFLIGHT_LOCK:
                _INFLIGHT.pop(key, None)

    def _call_provider(self, backend, query, max_results, scope, record, page=1):
        state = provider_state(self._scope(backend)) if scope else None
        with state.slots if state else nullcontext():
            # Another discovery run may have completed the same request while
            # we waited. Recheck before consuming a slot or touching the network.
            cached = _cached_response(scope, query, max_results) if scope else None
            if cached is not None:
                with self._lock:
                    self.provider_response_cache_hits += 1
                return cached
            if state:
                with state.lock:
                    health = state.snapshot()
                    if health['status'] == 'cooldown':
                        record['retry_after_seconds'] = health['retry_after_seconds']
                        raise ProviderError(health['reason'], message=f"{backend.name}: {health['reason']}")
                    state.wait(_PROVIDER_INTERVALS.get(backend.name, 0.3))
            record['requested'] = True
            try:
                hits = (backend.search(query, max_results=max_results) if page == 1 else
                        backend.search_page(query, max_results=max_results, page=page)) or []
            except ProviderError as exc:
                if state:
                    with state.lock:
                        state.failed(exc)
                        record['retry_after_seconds'] = state.snapshot()['retry_after_seconds']
                raise
            retrieved_at = datetime.now(timezone.utc).isoformat(timespec='seconds')
            hits = [replace(hit, provider=hit.provider or backend.name, query=query,
                            retrieved_at=hit.retrieved_at or retrieved_at) for hit in hits]
            if scope:
                _remember_response(scope, query, max_results, hits)
            return hits

    def _provider_search(self, backend: SearchBackend, query: str, max_results: int,
                         platform: str, page: int = 1) -> tuple[list[SearchResult], dict | None]:
        # Qualification is a local operation. Reuse the provider's actual results
        # across generic/profile lookups without reusing a prematurely stopped
        # fallback chain. Lifetime is this backend instance (one discovery run).
        key = (id(backend), query, max_results, page)
        with self._lock:
            prior = next((future for (identity, cached_query, count, cached_page), future
                          in self._result_cache.items()
                          if identity == id(backend) and cached_query == query
                          and count >= max_results and cached_page == page), None)
            owner = prior is None
            if owner:
                prior = self._result_cache[key] = Future()
            else:
                self.provider_cache_hits += 1
        if not owner:
            return [replace(hit) for hit in prior.result()[:max_results]], None

        scope = self._scope(backend)
        if scope and page > 1:
            scope = _cache_scope(scope, 'page', str(page))
        if scope:
            cached = _cached_response(scope, query, max_results)
            if cached is not None:
                with self._lock:
                    self.provider_response_cache_hits += 1
                prior.set_result(cached)
                return [replace(hit) for hit in cached], None

        started = time.monotonic()
        record = {'query': query, 'provider': backend.name, 'platform': platform,
                  'page': page, 'status': 'ok', 'requested': False}
        try:
            hits = self._request_provider(backend, query, max_results, scope, record, page)
            record.update(results=len(hits), status=('ok' if hits else 'empty') if record['requested'] else 'cached')
            prior.set_result(hits)
            return [replace(hit) for hit in hits], record
        except Exception as exc:
            record.update(status='error' if record['requested'] else 'cooldown',
                          error=type(exc).__name__, results=0)
            detail = (backend._disabled_reason
                      if isinstance(backend, (DuckDuckGoBackend, SerperBackend)) else '')
            if detail:
                record['detail'] = detail
            if isinstance(exc, ProviderError):
                record['reason'] = exc.code
                if exc.code in ('engines_paused', 'paging_unavailable'):
                    record.update(requested=False, status='cooldown')
            self._note(f"{backend.name}: {detail or record.get('reason') or type(exc).__name__}")
            cached = _cached_response(scope, query, max_results, stale=True) if scope else None
            if cached:
                with self._lock:
                    self.stale_cache_hits += 1
                record['stale_results'] = len(cached)
                prior.set_result(cached)
                return [replace(hit) for hit in cached], record
            prior.set_exception(exc)
            with self._lock:
                self._result_cache.pop(key, None)
            raise
        finally:
            for warning in getattr(backend, 'warnings', []):
                self._note(f"{backend.name}: {warning}")
            record['seconds'] = round(time.monotonic() - started, 3)
            with self._lock:
                self.attempts.append(record)

    def search(self, query: str, max_results: int = 20) -> list[SearchResult]:
        return self._search(query, max_results)

    def search_profiles(self, query: str, max_results: int = 20, *, platform: str,
                        name: str) -> list[SearchResult]:
        """Continue past directories and unrelated owners, retaining partial hits.

        A title/handle match is a retrieval stopping rule, not verified identity.
        Each configured provider is consulted at most once for this query.
        """
        return self._search(query, max_results, platform, name)

    def search_publications(self, query: str, max_results: int = 20, *, name: str):
        return self._search(query, max_results, 'web', name)

    @property
    def supports_paging(self) -> bool:
        return any(callable(getattr(b, 'search_page', None)) for b in self.backends)

    def search_page(self, query: str, max_results: int = 20, *, page: int = 2,
                    platform: str = '', name: str = '') -> list[SearchResult]:
        return self._search(query, max_results, platform, name, page)

    def _search(self, query: str, max_results: int, platform: str = '',
                name: str = '', page: int = 1) -> list[SearchResult]:
        from .candidates import _handle_from_url, is_name_match
        from .sources import is_publication_url, publication_name_match

        def qualifies(hit):
            if platform == 'web':
                return publication_name_match(name, hit)
            handle = _handle_from_url(platform, hit.url)
            return bool(handle and is_name_match(name, hit, handle))

        def relevance(hit):
            if platform == 'web':
                return qualifies(hit), is_publication_url(hit.url)
            return qualifies(hit), bool(_handle_from_url(platform, hit.url))

        kept: list[SearchResult] = []
        seen: set[tuple] = set()
        for_query = max(0, max_results)
        if not for_query:
            return []
        for b in self.backends:
            if page > 1 and not callable(getattr(b, 'search_page', None)):
                continue
            if not b.is_available():
                # A provider disabled mid-run must not hide earlier successful
                # answers for another query already held in the process cache.
                scope = self._scope(b)
                if scope and page > 1:
                    scope = _cache_scope(scope, 'page', str(page))
                cached = _cached_response(scope, query, max_results) if scope else None
                if cached:
                    if platform == 'web':
                        cached = [hit for hit in cached if is_publication_url(hit.url)]
                    with self._lock:
                        self.provider_response_cache_hits += 1
                    if not platform or any(qualifies(hit) for hit in cached):
                        return sorted(kept + cached, key=relevance, reverse=True)[:for_query] if platform else cached
                    kept.extend(cached)
                continue
            try:
                results, record = self._provider_search(b, query, max_results, platform, page)
            except Exception:  # noqa: BLE001 — another provider may still work
                continue
            if results:
                with self._lock:
                    self.last_used = b.name
                if not platform:
                    return results
                if platform == 'web':
                    results = [hit for hit in results if is_publication_url(hit.url)]
                matching_profiles = sum(qualifies(hit) for hit in results)
                if record is not None:
                    record['matching_publications' if platform == 'web' else 'matching_profiles'] = matching_profiles
                for hit in results:
                    key = (str(hit.url), hit.title, hit.snippet, hit.provider)
                    if key not in seen:
                        seen.add(key)
                        kept.append(hit)
                if matching_profiles:
                    # Noise from an earlier provider must not push the recovered
                    # profile outside the result budget.
                    return sorted(kept, key=relevance, reverse=True)[:for_query]
            else:
                self._note(f"{b.name}: 0 results")
        return sorted(kept, key=relevance, reverse=True)[:for_query]


# Playwright is not a default *search* backend: scraping Bing via a headless
# browser costs ~15-20s per query and, in practice, adds nothing once
# Serper/SearXNG/DuckDuckGo have run. Re-add via OSINT_BACKEND_ORDER if needed.
_ORDER = ("serper", "google_cse", "searxng", "duckduckgo")


def build_backends(config: DiscoveryConfig | None,
                   client: PoliteClient) -> list[SearchBackend]:
    config = config or DiscoveryConfig.from_env()
    if config.search_mode not in ('auto', 'keyless'):
        raise ValueError('search_mode must be auto or keyless')
    registry: dict[str, SearchBackend] = {
        "serper": SerperBackend(config.serper_key, client),
        "google_cse": GoogleCSEBackend(config.google_cse_key,
                                       config.google_cse_cx, client),
        "searxng": SearxngBackend(config.searxng_url, client),
        "playwright": PlaywrightBackend(),
        "duckduckgo": DuckDuckGoBackend(client),
    }
    order = config.backend_order or (('searxng', 'duckduckgo') if config.search_mode == 'keyless' else _ORDER)
    if config.search_mode == 'keyless':
        order = tuple(name for name in order if name not in ('serper', 'google_cse'))
    return [registry[n] for n in order if n in registry]


def default_backend(client: PoliteClient | None = None,
                    config: DiscoveryConfig | None = None) -> FallbackBackend:
    client = client or PoliteClient()
    return FallbackBackend(build_backends(config, client))
