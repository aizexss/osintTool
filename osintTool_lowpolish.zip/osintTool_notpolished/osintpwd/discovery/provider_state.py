"""Process-wide provider backoff and pacing, shared by repeated UI runs.

Only hashed configuration scopes and fixed error labels are retained here.
No proxy rotation, CAPTCHA solving or retries through a blocked endpoint.
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
from email.utils import parsedate_to_datetime
import math
import threading
import time
from . import cache


class ProviderError(RuntimeError):
    def __init__(self, code: str, *, cooldown: float = 0, message: str = ''):
        super().__init__(message or code)
        self.code = code
        self.cooldown = cooldown


def response_error(provider: str, response) -> ProviderError:
    status = response.status_code if response is not None else None
    code = ('transport_error' if status is None else
            'rate_limited' if status == 429 else
            'access_denied' if status in (401, 403) else
            'upstream_error' if status >= 500 else f'http_{status}')
    cooldown = 60 if status is None or status == 429 or status >= 500 else 300 if status in (401, 403) else 0
    if response is not None and status in (429, 503):
        retry = response.headers.get('Retry-After', '')
        try:
            seconds = float(retry)
        except ValueError:
            try:
                seconds = parsedate_to_datetime(retry).timestamp() - time.time()
            except (ValueError, TypeError, OverflowError):
                seconds = 0
        if math.isfinite(seconds):
            cooldown = max(cooldown, min(seconds, 86400))
    return ProviderError(code, cooldown=cooldown, message=f'{provider}: {code}')


@dataclass
class ProviderState:
    # Scheduling is shared across runs; slow responses must not serialize the
    # whole search. At most two requests to a provider can be in flight.
    lock: threading.Lock = field(default_factory=threading.Lock)
    slots: threading.BoundedSemaphore = field(default_factory=lambda: threading.BoundedSemaphore(2))
    next_request: float = 0
    retry_at: float = 0
    reason: str = ''
    scope: str = ''

    def __post_init__(self):
        saved = cache.read_state('provider:' + self.scope) if self.scope else {}
        remaining = max(0, min(86400, saved.get('retry_at', 0) - time.time()))
        self.retry_at = time.monotonic() + remaining if remaining else 0
        self.reason = saved.get('reason', '') if remaining else ''

    def wait(self, interval: float) -> None:
        delay = self.next_request - time.monotonic()
        if delay > 0:
            time.sleep(delay)
        self.next_request = time.monotonic() + interval

    def failed(self, error: ProviderError) -> None:
        if error.cooldown > 0:
            self.retry_at = time.monotonic() + error.cooldown
            self.reason = error.code
            if self.scope:
                cache.write_state('provider:' + self.scope,
                                  {'retry_at': time.time() + error.cooldown, 'reason': error.code})

    def snapshot(self) -> dict:
        remaining = max(0, math.ceil(self.retry_at - time.monotonic()))
        return {'status': 'cooldown' if remaining else 'ready',
                'reason': self.reason if remaining else '', 'retry_after_seconds': remaining}


_STATES: OrderedDict[str, ProviderState] = OrderedDict()
_LOCK = threading.Lock()


def provider_state(scope: str) -> ProviderState:
    with _LOCK:
        if scope not in _STATES:
            _STATES[scope] = ProviderState(scope=scope)
        state = _STATES[scope]
        _STATES.move_to_end(scope)
        # Configuration changes are rare; do not evict a currently active or
        # cooling provider just because another request changes its settings.
        if len(_STATES) > 64:
            for key, old in list(_STATES.items()):
                if key != scope and not old.lock.locked() and old.retry_at <= time.monotonic():
                    del _STATES[key]
                    if len(_STATES) <= 64:
                        break
        return state
