"""Small, evidence-led search continuations; never guess identities or handles."""
import re
from urllib.parse import unquote
from urllib.parse import urlparse

from .candidates import canonical_profile_url
from .username import valid_handle


def build_pivot_queries(name, candidates, limit=2):
    """Use observed named accounts to seek mentions and explicit backlinks.

    Queries are read leads, not relevance evidence. Their results still pass
    the usual owner/name/source-link gates, including page-body verification.
    """
    terms = list(dict.fromkeys(name.replace('"', '').split()))
    if not terms or limit <= 0:
        return []
    anchors = sorted((c for c in candidates if c.name_match and c.relation != 'username'),
                     key=lambda c: (bool(c.matched_hints), 'name_in_title' in c.match_reasons,
                                    c.score), reverse=True)
    queries, seen = [], set()
    for candidate in anchors:
        url = canonical_profile_url(candidate.platform, candidate.url)
        parsed = urlparse(url)
        if not parsed.hostname or not parsed.path.strip('/'):
            continue
        handle = valid_handle(candidate.handle)
        proposals = []
        # A single first name is too broad to be a useful username lead.
        if handle and len(handle) >= 4 and handle.casefold() not in {t.casefold() for t in terms}:
            names = ' OR '.join(f'"{term}"' for term in terms)
            proposals.append(('handle', f'"{handle}" ({names})'))
        address = url.split('://', 1)[-1]
        proposals.append(('backlink', f'"{address}" -site:{parsed.hostname}'))
        for kind, query in proposals:
            if query in seen:
                continue
            seen.add(query)
            queries.append({'query': query, 'kind': kind, 'source_url': url,
                            'handle': candidate.handle, 'source_title': candidate.title})
            if len(queries) >= limit:
                return queries
    return queries


def evidenced_pivot_queries(source, pivots):
    """Engines may ignore exact-query terms; don't read arbitrary pivot hits.

    A visible handle/address is enough to spend a bounded body read, but final
    acceptance still requires a name mention or an explicit account link.
    """
    by_query = {p['query']: p for p in pivots}
    accepted = set()
    for evidence in source.get('search_evidence', []):
        pivot = by_query.get(evidence.get('query'))
        if not pivot:
            continue
        visible = evidence.get('excerpt', '') + '\n' + unquote(evidence.get('source_url', ''))
        if pivot['handle'] and re.search(r'(?<![\w])' + re.escape(pivot['handle']) + r'(?![\w])',
                                         visible, re.IGNORECASE):
            accepted.add(pivot['query'])
    return accepted
