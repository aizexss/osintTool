"""Observed retrieval yield, never an estimate of identity precision or recall."""
from .candidates import PLATFORMS, _handle_from_url, canonical_profile_url
from .sources import canonical_source_url


def query_yield_report(records, candidates, sources, pivots=()):
    aliases = {}

    def key(url):
        if url not in aliases:
            normalized = canonical_source_url(url)
            for platform in PLATFORMS:
                if normalized and _handle_from_url(platform, normalized):
                    normalized = canonical_profile_url(platform, normalized)
                    break
            aliases[url] = normalized
        return aliases[url]

    account_queries, named_queries, source_queries = {}, {}, {}
    for candidate in candidates:
        for ev in candidate.evidence:
            if ev.get('kind') != 'search_result' or not ev.get('query'):
                continue
            account_queries.setdefault(ev['query'], set()).add(key(candidate.url))
            if candidate.name_match:
                named_queries.setdefault(ev['query'], set()).add(key(candidate.url))
    for source in sources:
        for ev in source.get('search_evidence', []):
            if ev.get('query'):
                source_queries.setdefault(ev['query'], set()).add(key(source['url']))
    pivot_by_query = {p['query']: p for p in pivots}
    seen_urls, seen_accounts, seen_sources, rows = set(), set(), set(), []
    for record in sorted(records, key=lambda r: r.get('sequence', 0)):
        query = record['query']
        urls = {key(url) for url in record.get('result_urls', [])} - {''}
        # Count only retained hits carrying this query's own evidence.
        accounts = account_queries.get(query, set()) & urls
        publications = source_queries.get(query, set()) & urls
        rows.append({
            'query': query, 'page': record.get('page', 1), 'status': record['status'], 'seconds': record.get('seconds', 0),
            'providers': record.get('providers', []), 'results': record.get('results', 0),
            'cached_results': record.get('cached_results', 0),
            'accounts': len(accounts), 'full_name_accounts': len(accounts & named_queries.get(query, set())),
            'publications': len(publications), 'new_accounts': len(accounts - seen_accounts),
            'new_publications': len(publications - seen_sources),
            'repeated_results': max(0, record.get('results', 0) - len(urls - seen_urls)),
            'not_displayed_urls': len(urls - accounts - publications),
            **({'pivot': pivot_by_query[query]} if query in pivot_by_query else {}),
        })
        seen_urls.update(urls)
        seen_accounts.update(accounts)
        seen_sources.update(publications)
    return {'raw_results': sum(r['results'] for r in rows), 'unique_urls': len(seen_urls),
            'repeated_results': sum(r['repeated_results'] for r in rows),
            'retained_accounts': len(seen_accounts), 'retained_publications': len(seen_sources),
            'productive_queries': sum(bool(r['accounts'] or r['publications']) for r in rows),
            'unavailable_queries': sum(r['status'] in ('error', 'unavailable') for r in rows),
            'rows': rows}
