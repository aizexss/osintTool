"""Tentative account groups for human review; never proof of common ownership.

An exact shared username with matching owner-name evidence can suggest a group.
Separators remain significant, and different stated owners remain separate.
No account is discarded and no group automatically confirms an identity.
"""

from __future__ import annotations

from .candidates import _handle_name_matches, _matched_hints, _title_name_matches
from .models import Candidate

def _norm_handle(handle: str) -> str:
    return (handle or "").strip().removeprefix("@").casefold()


def annotate_identity(name: str, hints: dict, candidates: list[Candidate]) -> int:
    """Fill `group` and `matched_hints` on each candidate in place.

    Returns the number of tentative groups, not a count of identified people.
    """
    hints = hints or {}
    # 1) per-candidate hint evidence
    for c in candidates:
        # Repeated search hits may contain different hints. Keep all recorded
        # excerpts rather than forgetting evidence when the display hit changes.
        text = " ".join([c.title, c.snippet] + [str(e.get("excerpt", "")) for e in c.evidence])
        c.matched_hints = list(dict.fromkeys(c.matched_hints + _matched_hints(hints, text)))

    # 2) Require corroborating name evidence for shared-nick suggestions. A
    # different nonempty owner/title cannot be overridden by the username.
    members: dict[str, list[Candidate]] = {}
    singletons: list[Candidate] = []
    for c in candidates:
        h = _norm_handle(c.handle)
        owner_match = _title_name_matches(name, c.title, c.handle)
        empty_owner = not c.title.strip()
        named_handle = _handle_name_matches(name, c.handle)
        can_group = owner_match or (empty_owner and named_handle and c.name_match)
        if len(h) >= 4 and can_group:
            peers = members.setdefault(h, [])
            # Multiple account namespaces on one platform (e.g. YouTube's
            # /user/name versus /@name) must not silently form one identity.
            if any(peer.platform == c.platform for peer in peers):
                singletons.append(c)
            else:
                peers.append(c)
        else:
            singletons.append(c)

    groups: list[list[Candidate]] = list(members.values()) + [[c] for c in singletons]

    def _group_rank(g: list[Candidate]) -> tuple:
        return (
            any(c.name_match for c in g),         # a by-name identity leads
            max((len(c.matched_hints) for c in g), default=0),  # most hint evidence
            max((c.score for c in g), default=0.0),
        )

    groups.sort(key=_group_rank, reverse=True)
    for i, g in enumerate(groups, start=1):
        for c in g:
            c.group = i
            if len(g) > 1 and "possible_shared_username" not in c.match_reasons:
                c.match_reasons.append("possible_shared_username")
    return len(groups)
