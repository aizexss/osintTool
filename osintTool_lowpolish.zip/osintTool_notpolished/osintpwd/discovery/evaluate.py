"""Evaluate platform+URL labels; unknown accounts never count as incorrect.

Use --output to retain each run. Known-account recall is not overall recall.
Precision is accompanied by label coverage and is only computed on judged data.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict, is_dataclass
import json
from pathlib import Path
import time
from urllib.parse import parse_qs, unquote, urlsplit

_HOSTS = {
    'linkedin.com': 'linkedin', 'instagram.com': 'instagram',
    'facebook.com': 'facebook', 'fb.com': 'facebook', 'vk.com': 'vk',
    'vk.ru': 'vk', 'x.com': 'x', 'twitter.com': 'x',
    'github.com': 'github', 't.me': 'telegram', 'telegram.me': 'telegram',
    'tiktok.com': 'tiktok', 'youtube.com': 'youtube',
}
_CANONICAL_HOST = {v: k for k, v in reversed(list(_HOSTS.items()))}


def _mapping(value) -> dict:
    return asdict(value) if is_dataclass(value) else dict(value)


def account_key(value: dict) -> tuple[str, str] | None:
    """Retain platform and punctuation, omit tracking, unify known host aliases.

    Numeric Facebook URL forms resolve to the same ID. YouTube channel IDs
    remain case-sensitive; supported username URL paths do not.
    """
    try:
        parsed = urlsplit(str(value.get('url') or '').strip())
    except ValueError:
        return None
    if parsed.scheme not in {'http', 'https'} or not parsed.hostname:
        return None
    host = parsed.hostname.lower()
    inferred = next((platform for domain, platform in _HOSTS.items()
                     if host == domain or host.endswith('.' + domain)), '')
    platform = str(value.get('platform') or value.get('site') or inferred).lower()
    if (not platform or (inferred and platform != inferred)
            or (platform in _CANONICAL_HOST and inferred != platform)):
        return None
    path = unquote(parsed.path).rstrip('/')
    if not path:
        return None
    if platform == 'facebook':
        parts = path.split('/')
        pid = parse_qs(parsed.query).get('id', [''])[0]
        if path.lower() == '/profile.php' and pid.isdigit():
            path = '/profile.php?id=' + pid
        elif len(parts) >= 4 and parts[1].lower() == 'people' and parts[3].isdigit():
            path = '/profile.php?id=' + parts[3]
    if not (platform == 'youtube' and path.startswith('/channel/')):
        path = path.lower()
    canonical_host = _CANONICAL_HOST.get(platform, host.removeprefix('www.'))
    return platform, 'https://' + canonical_host + path


def labelled_keys(case: dict, field: str = 'expect') -> tuple[set, list[str]]:
    keys, warnings = set(), []
    for label in case.get(field, []):
        if isinstance(label, str):
            if label.startswith(('https://', 'http://')):
                label = {'url': label}
            else:
                platform = case.get('legacy_platform')
                if not platform:
                    warnings.append(f'{field}: bare handle {label!r} has no platform; excluded from identity metrics')
                    continue
                host = _CANONICAL_HOST.get(platform)
                prefix = '/in/' if platform == 'linkedin' else '/@' if platform in {'youtube', 'tiktok'} else '/'
                label = {'platform': platform, 'url': 'https://' + host + prefix + label} if host else {}
                warnings.append(f'{field}: legacy handle evaluated only on explicit platform {platform}')
        key = account_key(label) if isinstance(label, dict) else None
        if key:
            keys.add(key)
        else:
            warnings.append(f'{field}: invalid account label excluded')
    return keys, warnings


def score_result(case: dict, result, k: int = 10) -> dict:
    """Score a dataclass or saved JSON result without network access."""
    if k < 1:
        raise ValueError('k must be positive')
    data = _mapping(result)
    candidates = [_mapping(c) for c in data.get('candidates', [])]
    related = [_mapping(c) for c in data.get('related_accounts', [])]
    expected, warnings = labelled_keys(case)
    expected_related, wr = labelled_keys(case, 'expect_related')
    rejected, wn = labelled_keys(case, 'reject')
    warnings.extend(wr + wn)
    if expected & rejected:
        raise ValueError('An account cannot be both expected and rejected')
    keys = [account_key(c) for c in candidates]
    found = set(keys) - {None}
    related_found = {account_key(c) for c in related} - {None}
    rank = next((i + 1 for i, key in enumerate(keys) if key in expected), None)
    top = keys[:k]
    judged = [key for key in top if key in expected or key in rejected]
    correct = sum(key in expected for key in judged)
    evidence_count = sum(bool(c.get('evidence')) for c in candidates + related)
    total = len(candidates) + len(related)
    stats = data.get('stats') or {}
    return {
        'id': case.get('id', case.get('name', '')), 'name': case.get('name', ''),
        'proposals': len(candidates), 'related_proposals': len(related),
        'known_accounts': len(expected), 'known_found': len(expected & found),
        'known_recall': len(expected & found) / len(expected) if expected else None,
        'rank': rank, 'hit_at_k': int(rank is not None and rank <= k) if expected else None,
        'reciprocal_rank': 1 / rank if rank else 0.0 if expected else None,
        'precision_among_judged_at_k': correct / len(judged) if judged else None,
        'label_coverage_at_k': len(judged) / len(top) if top else None,
        'precision_at_k': correct / len(top) if top and len(judged) == len(top) else None,
        'known_related_accounts': len(expected_related),
        'known_related_found': len(expected_related & related_found),
        'related_recall': len(expected_related & related_found) / len(expected_related) if expected_related else None,
        'rejected_in_primary': len(rejected & found),
        'false_target_promotions': len({account_key(c) for c in candidates
                                       if c.get('name_match') or c.get('relation') in {'via_related', 'target_via_related'}} & rejected),
        'fallback_attempted': data.get('related_searched'),
        'related_people': len(data.get('related_people', [])),
        'target_via_related': sum(c.get('relation') in {'via_related', 'target_via_related'} for c in candidates),
        'with_evidence': evidence_count, 'evidence_total': total,
        'evidence_coverage': evidence_count / total if total else None,
        'query_calls': stats.get('search_queries'),
        'search_cache_hits': stats.get('search_cache_hits'),
        'query_errors': stats.get('query_errors'),
        'page_attempts': sum(stats.get(key, 0) for key in (
            'source_pages_read', 'profile_pages_read',
            'related_source_pages_read', 'related_profile_pages_read')) if stats else None,
        'page_errors': stats.get('page_errors'),
        'warnings': warnings,
    }


def summarize(rows: list[dict]) -> dict:
    def mean(key):
        values = [r[key] for r in rows if r.get(key) is not None]
        return sum(values) / len(values) if values else None
    def total(key):
        return sum(r.get(key, 0) or 0 for r in rows)
    nknown, nrelated = total('known_accounts'), total('known_related_accounts')
    return {
        'cases': len(rows), 'labelled_cases': sum(bool(r.get('known_accounts')) for r in rows),
        'known_accounts': nknown, 'known_found': total('known_found'),
        'known_recall': total('known_found') / nknown if nknown else None,
        'mean_hit_at_k': mean('hit_at_k'), 'mrr': mean('reciprocal_rank'),
        'known_related_accounts': nrelated, 'known_related_found': total('known_related_found'),
        'related_recall': total('known_related_found') / nrelated if nrelated else None,
        'false_target_promotions': total('false_target_promotions'),
        'with_evidence': total('with_evidence'), 'evidence_total': total('evidence_total'),
        'evidence_coverage': total('with_evidence') / total('evidence_total') if total('evidence_total') else None,
        'mean_seconds': mean('seconds'), 'errors': sum(bool(r.get('error')) for r in rows),
        'query_calls': total('query_calls'),
        'query_errors': total('query_errors'),
        'page_attempts': total('page_attempts'),
    }


def run(path: str, k: int = 10, output: str | None = None) -> dict:
    from . import discover
    from ..env import load_env
    load_env()
    payload = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    rows = []
    for case in payload['cases']:
        start = time.perf_counter()
        try:
            result = discover(case['name'], case.get('hints') or {})
            row = score_result(case, result, k)
            row['result'] = asdict(result)
        except Exception as exc:
            row = score_result(case, {'candidates': [], 'related_accounts': []}, k)
            row['error'] = f'{type(exc).__name__}: {exc}'
        row['seconds'] = round(time.perf_counter() - start, 3)
        rows.append(row)
        print(json.dumps({key: value for key, value in row.items() if key != 'result'}, ensure_ascii=False))
    report = {'schema_version': 2, 'k': k, 'cases': rows, 'summary': summarize(rows)}
    if output:
        Path(output).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report['summary'], ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('path', nargs='?', default='examples/discovery_eval.json')
    parser.add_argument('--k', type=int, default=10)
    parser.add_argument('--output')
    args = parser.parse_args()
    if args.k < 1:
        parser.error('--k must be positive')
    run(args.path, args.k, args.output)
