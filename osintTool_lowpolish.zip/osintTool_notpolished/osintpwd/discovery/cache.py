"""Bounded local search cache. Failure to read/write it never stops discovery."""
from __future__ import annotations

from dataclasses import asdict
from contextlib import closing
import hashlib
import json
import logging
import os
from pathlib import Path
import sqlite3
import time

from .models import SearchResult

MAX_ENTRIES = 512
RETENTION = 3600
_LOG = logging.getLogger(__name__)


def cache_path() -> Path | None:
    value = os.environ.get('OSINT_SEARCH_CACHE_PATH', '').strip()
    if value.lower() in ('off', 'none', '0'):
        return None
    return Path(value).expanduser() if value else Path(__file__).resolve().parents[2] / '.cache' / 'search.sqlite3'


def _key(scope: str, query: str, count: int) -> str:
    return hashlib.sha256(json.dumps([scope, query, count]).encode()).hexdigest()


def _connect(path: Path):
    # A short lock wait is preferable to holding up an online request.
    return sqlite3.connect(path, timeout=0.25)


def read(scope: str, query: str, count: int) -> tuple[float, list[SearchResult]] | None:
    path = cache_path()
    if path is None or not path.is_file():
        return None
    try:
        with closing(_connect(path)) as db:
            row = db.execute('SELECT saved, payload FROM responses WHERE key=?',
                             (_key(scope, query, count),)).fetchone()
        if row is None:
            return None
        age = time.time() - row[0]
        if not 0 <= age < RETENTION:
            return None
        payload = json.loads(row[1])
        hits = [SearchResult(**hit) for hit in payload]
        if not hits or any(not isinstance(hit.url, str) or not hit.url for hit in hits):
            return None
        return age, hits
    except (OSError, sqlite3.Error, ValueError, TypeError, OverflowError):
        _LOG.warning('Search disk cache unavailable; continuing without cached data')
        return None


def write(scope: str, query: str, count: int, hits: list[SearchResult]) -> None:
    path = cache_path()
    if path is None:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with closing(_connect(path)) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS responses '
                       '(key TEXT PRIMARY KEY, saved REAL NOT NULL, payload TEXT NOT NULL)')
            key = _key(scope, query, count)
            if hits:
                db.execute('INSERT OR REPLACE INTO responses VALUES (?, ?, ?)',
                           (key, time.time(), json.dumps([asdict(hit) for hit in hits], ensure_ascii=False)))
            else:
                db.execute('DELETE FROM responses WHERE key=?', (key,))
            db.execute('DELETE FROM responses WHERE saved <= ?', (time.time() - RETENTION,))
            db.execute('DELETE FROM responses WHERE key IN '
                       '(SELECT key FROM responses ORDER BY saved DESC LIMIT -1 OFFSET ?)',
                       (MAX_ENTRIES,))
    except (OSError, sqlite3.Error, ValueError, TypeError):
        _LOG.warning('Search disk cache unavailable; continuing with process cache')


def read_state(key: str) -> dict:
    """Health is independent of the short response TTL; deadlines use UTC time."""
    path = cache_path()
    if path is None or not path.is_file():
        return {}
    try:
        with closing(_connect(path)) as db:
            row = db.execute('SELECT payload FROM health WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else {}
    except (OSError, sqlite3.Error, ValueError, TypeError):
        return {}


def write_state(key: str, payload: dict) -> None:
    path = cache_path()
    if path is None:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with closing(_connect(path)) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS health (key TEXT PRIMARY KEY, saved REAL, payload TEXT)')
            db.execute('INSERT OR REPLACE INTO health VALUES (?, ?, ?)',
                       (key, time.time(), json.dumps(payload)))
            db.execute('DELETE FROM health WHERE saved < ?', (time.time() - 30 * 86400,))
    except (OSError, sqlite3.Error, ValueError, TypeError):
        _LOG.warning('Could not persist search health; process backoff remains active')
