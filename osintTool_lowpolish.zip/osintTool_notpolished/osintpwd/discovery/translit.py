"""Transliteration for name queries — both directions.

A RU/KZ person is written BOTH ways online: Cyrillic on VK / Instagram / local
media, Latin on LinkedIn / papers / GitHub. Searching only the typed form
silently misses half the footprint, so discovery runs the original plus the
other script. A name typed in Latin (e.g. "Muhammed Zhumali") is also searched
as «Мухаммед Жумали» — otherwise a Cyrillic-native person is missed entirely.

Cyrillic→Latin is exact; Latin→Cyrillic is a best-effort guess (romanisation is
lossy), used only to WIDEN recall — a wrong guess just returns nothing.
"""

from __future__ import annotations

import re

_MAP: dict[str, str] = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "yo",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "kh", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "shch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
    # Kazakh
    "ә": "a", "ғ": "gh", "қ": "q", "ң": "ng", "ө": "o", "ұ": "u", "ү": "u",
    "һ": "h", "і": "i",
}


def is_cyrillic(text: str) -> bool:
    return any("Ѐ" <= ch <= "ӿ" for ch in text)


def transliterate(text: str, *, j: str = "y") -> str:
    """Transliterate Cyrillic to Latin, preserving spacing and word casing.

    `j` sets how «й» is rendered — "y" (Aybar) or "i" (Aibar); both spellings
    are common for KZ/RU names, so callers try both to widen recall.
    """
    out: list[str] = []
    for ch in text:
        rep = j if ch.lower() == "й" else _MAP.get(ch.lower())
        if rep is None:
            out.append(ch)                  # non-Cyrillic passes through
            continue
        if ch.isupper() and rep:            # keep a leading capital ("Ж" -> "Zh")
            rep = rep[0].upper() + rep[1:]
        out.append(rep)
    return "".join(out)


# Latin → Cyrillic, greedy longest-match. Digraphs first, then single letters.
# Ambiguous targets (a→а not ә, u→у, i→и, y→й, o→о, h→х) collapse to the most
# common Russian rendering; that's fine — this only adds a recall query.
_RMAP_DIGRAPHS = (
    ("shch", "щ"), ("zh", "ж"), ("kh", "х"), ("ts", "ц"), ("ch", "ч"),
    ("sh", "ш"), ("yo", "ё"), ("yu", "ю"), ("ya", "я"), ("ye", "е"),
    ("gh", "г"),
)
_RMAP_SINGLE = {
    "a": "а", "b": "б", "v": "в", "g": "г", "d": "д", "e": "е", "z": "з",
    "i": "и", "y": "й", "k": "к", "l": "л", "m": "м", "n": "н", "o": "о",
    "p": "п", "r": "р", "s": "с", "t": "т", "u": "у", "f": "ф", "h": "х",
    "c": "к", "j": "ж", "q": "к", "w": "в", "x": "кс",
}


def is_latin(text: str) -> bool:
    return any("a" <= ch.lower() <= "z" for ch in text)


def to_cyrillic(text: str) -> str:
    """Best-effort Latin → Cyrillic for a name, preserving spacing and word
    casing. Lossy by nature (romanisation drops distinctions); used only to add
    a recall query, never as ground truth."""
    # Only ASCII letters are transliterated here. Unicode lowercasing can
    # expand a character (İ -> i + combining dot) and invalidate text offsets.
    low = ''.join(ch.lower() if ch.isascii() else ch for ch in text)
    out: list[str] = []
    i = 0
    while i < len(low):
        ch = text[i]
        if not ("a" <= low[i] <= "z"):
            out.append(ch)                      # non-Latin passes through
            i += 1
            continue
        matched = None
        for lat, cyr in _RMAP_DIGRAPHS:
            if low.startswith(lat, i):
                matched = (lat, cyr)
                break
        if matched:
            lat, rep = matched
            step = len(lat)
        else:
            rep = _RMAP_SINGLE.get(low[i], ch)
            step = 1
        # capitalise if the first source letter of this unit is uppercase
        if text[i].isupper() and rep:
            rep = rep[0].upper() + rep[1:]
        out.append(rep)
        i += step
    return "".join(out)


def romanized_name_variants(name: str) -> list[str]:
    """Forward transliteration and a bounded, common vowel+i/y alternate.

    Aibar/Aybar, Tsoi/Tsoy and Sergei/Sergey are common alternatives. This
    does not substitute every i/y (Kim must never become Kym), or generate
    arbitrary fuzzy edits. All name components still have to match.
    """
    variants = list(dict.fromkeys(transliterate(name, j=j) for j in ("y", "i")))
    for latin in variants[:]:
        alternate = re.sub(
            r"(?<=[aeou])[iy](?=[bcdfghjklmnpqrstvwxyz]|\b)",
            lambda m: ("y" if m[0].lower() == "i" else "i").upper()
            if m[0].isupper() else ("y" if m[0] == "i" else "i"),
            latin, flags=re.I,
        )
        if alternate.casefold() not in {v.casefold() for v in variants}:
            variants.append(alternate)
    return variants


def name_variants(name: str) -> list[str]:
    """The name plus its transliteration into the other script (deduplicated,
    original first).

    Cyrillic input → Latin (both «й»→y and «й»→i spellings, e.g. Aybar / Aibar).
    Latin input → Cyrillic plus a bounded vowel+i/y alternate (Aibar/Aybar,
    Tsoi/Tsoy). The original stays first, and at most four forms are emitted.
    The reverse transliteration is only a retrieval hint, never identity proof.
    """
    name = (name or "").strip()
    variants = [name] if name else []
    if not name:
        return variants
    if is_cyrillic(name):
        for latin in romanized_name_variants(name):
            latin = latin.strip()
            if latin and latin.lower() not in (v.lower() for v in variants):
                variants.append(latin)
    elif is_latin(name):
        cyr = to_cyrillic(name).strip()
        if cyr and cyr.lower() not in (v.lower() for v in variants):
            variants.append(cyr)
        for latin in romanized_name_variants(name):
            if latin.casefold() not in {v.casefold() for v in variants}:
                variants.append(latin)
                alternate_cyr = to_cyrillic(latin)
                if alternate_cyr.casefold() not in {v.casefold() for v in variants}:
                    variants.append(alternate_cyr)
    return variants[:4]
