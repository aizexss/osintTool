"""Read bounded public document text and explicitly published profile links."""

from __future__ import annotations

import re
import unicodedata
from io import BytesIO
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from .http import PoliteClient
from .models import Candidate

MAX_DOCUMENT_BYTES = 2 * 1024 * 1024
MAX_PUBLIC_TEXT = 24_000
MAX_PDF_PAGES = 5

_STOPWORDS = {
    "the", "and", "for", "with", "you", "your", "this", "that", "are", "was",
    "from", "have", "has", "not", "all", "profile", "instagram", "facebook",
    "linkedin", "photos", "videos", "followers", "following", "posts", "see",
    "log", "login", "sign", "www", "com", "http", "https", "photo", "video",
    "people", "page", "like", "likes", "share", "view", "views", "join",
}


def _meta(soup: BeautifulSoup, *, prop: str = "", name: str = "") -> str:
    if prop:
        tag = soup.find("meta", attrs={"property": prop})
        if tag and tag.get("content"):
            return tag["content"].strip()
    if name:
        tag = soup.find("meta", attrs={"name": name})
        if tag and tag.get("content"):
            return tag["content"].strip()
    return ""


def extract_public_text(html: str, *, include_comments: bool = False) -> str:
    """Keep preview metadata AND article/body text, preserving paragraphs.

    Metadata often survives a social login wall, while co-mentions normally live
    in the article body. Neither alone should displace the other.
    """
    html = (html or "")[:MAX_DOCUMENT_BYTES]
    soup = BeautifulSoup(html, "html.parser")
    parts = [
        _meta(soup, prop="og:title"),
        _meta(soup, prop="og:description"),
        _meta(soup, name="description"),
        soup.title.get_text(strip=True) if soup.title else "",
    ]
    for tag in soup.find_all(["script", "style", "noscript", "template", "nav", "footer"]):
        tag.decompose()
    if include_comments:
        # Social replies often sit outside <article>. Preserve author + message
        # together so a mention has a local context, not just a page-wide name.
        comments = soup.select('.reply, .wall_reply, .comment, [itemprop="comment"]')
        comment_text = []
        for tag in comments[:80]:
            if any(parent in comments for parent in tag.parents):
                continue
            comment_text.append(tag.get_text(' ', strip=True)[:1200])
        parts.extend('\n'.join(comment_text)[:8000].splitlines())
    body = ""
    readme = soup.select_one('article.markdown-body')
    if readme is not None:
        # GitHub already identifies the README. Generic article heuristics can
        # stop at installation code and lose the author's Contact section.
        blocks = readme.find_all(['p', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
                                  'blockquote', 'pre', 'td'])
        body = '\n'.join(tag.get_text(' ', strip=True) for tag in blocks)
        body = body or readme.get_text(' ', strip=True)
    if not body:
        try:
            import trafilatura

            body = trafilatura.extract(
                str(soup), include_comments=include_comments, include_tables=include_comments,
                favor_recall=True, deduplicate=True,
            ) or ""
        except Exception:  # optional extractor failure must not lose the document
            pass
    if not body:
        for tag in soup.find_all(["script", "style", "noscript", "template", "nav", "footer"]):
            tag.decompose()
        content = soup.find("main") or soup.find("article") or soup.body or soup
        blocks = content.find_all(["p", "li", "h1", "h2", "h3", "blockquote"])
        if blocks:
            body = "\n".join(re.sub(r"\s+", " ", tag.get_text(" ", strip=True))
                             for tag in blocks)
        else:
            body = re.sub(r"\s+", " ", content.get_text(" ", strip=True))
    parts.extend(body.splitlines())
    seen: set[str] = set()
    uniq = [p for p in parts if p and not (p in seen or seen.add(p))]
    return "\n".join(uniq)[:MAX_PUBLIC_TEXT]


def naive_keywords(text: str, limit: int = 40) -> list[str]:
    """Cheap keyword pull (pre-ML): meaningful words + capitalised names.

    This is a placeholder until the local NER model lands; it already gives
    the generator/evaluator useful person-specific tokens.
    """
    words = re.findall(r"[^\W\d_][^\W\d_’'\-]*(?:[’'\-][^\W\d_]+)*", text, re.UNICODE)
    out: list[str] = []
    seen: set[str] = set()
    for w in words:
        wl = w.lower()
        if len(w) < 3 or wl in _STOPWORDS or wl in seen:
            continue
        seen.add(wl)
        out.append(w)
        if len(out) >= limit:
            break
    return out


def _og_image(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    return _meta(soup, prop="og:image")


# LinkedIn (and others) reliably serve the public og: preview to social/search
# crawlers even when they 999/authwall a browser UA — that's how link previews
# work. Fetch those pages as a crawler.
_CRAWLER_UA = ("facebookexternalhit/1.1 "
               "(+http://www.facebook.com/externalhit_uatext.php)")


def _fetch_public(candidate: Candidate, client: PoliteClient):
    headers = None
    if "linkedin.com" in candidate.url:
        headers = {"User-Agent": _CRAWLER_UA}
    get = getattr(client, "get_public", client.get)
    resp = get(candidate.url, headers=headers)
    # LinkedIn's 999 = rate-limited; one retry as a crawler often clears it
    if (resp is None or resp.status_code == 999) and "linkedin.com" in candidate.url:
        resp = get(candidate.url, headers={"User-Agent": _CRAWLER_UA})
    return resp


# Social hosts we recognise in a profile's cross-links (rel=me / bio links).
from .candidates import SOCIAL_HOSTS as _SOCIAL_LINK_HOSTS


def extract_cross_links(html: str, source_url: str, *,
                        include_same_site: bool = False) -> list[dict]:
    """Cross-account links a profile declares (rel=me first, then any social-host
    hrefs) — this is how we reach the person's accounts whose HANDLE differs
    (e.g. a GitHub profile linking a Telegram @other_handle)."""
    from .candidates import PLATFORMS, _handle_from_url, canonical_profile_url

    soup = BeautifulSoup((html or "")[:MAX_DOCUMENT_BYTES], "html.parser")
    src_host = (urlparse(source_url).hostname or "").lower().removeprefix("www.")
    # Registered domain of the source. Same-site subdomains usually contain
    # chrome; LinkedIn's country subdomains also host public person profiles.
    src_domain = ".".join(src_host.split(".")[-2:])
    out: list[dict] = []
    seen: set[str] = set()
    for a in soup.find_all("a", href=True):
        try:
            href = urljoin(source_url, a["href"].strip())
            parsed = urlparse(href)
            host = (parsed.hostname or "").lower().removeprefix("www.")
        except ValueError:
            continue
        if parsed.scheme not in ("http", "https"):
            continue
        same_site = host == src_domain or host.endswith("." + src_domain)
        if same_site and not include_same_site:
            continue
        site = next((s for h, s in _SOCIAL_LINK_HOSTS.items()
                     if host == h or host.endswith("." + h)), None)
        if site not in PLATFORMS or not _handle_from_url(site, href):
            continue
        if same_site and host != src_host:
            regional_linkedin = site == "linkedin" and all(
                re.fullmatch(r"(?:[a-z]{2}\.)?linkedin\.com", h)
                for h in (src_host, host)
            )
            if not regional_linkedin:
                continue
        canonical = canonical_profile_url(site, href)
        key = canonical.lower()
        source_canonical = canonical_profile_url(site, source_url)
        if key == source_canonical.rstrip("/").lower():
            continue
        if key in seen:
            continue
        seen.add(key)
        rel = a.get("rel") or []
        if isinstance(rel, str):
            rel = rel.split()
        # The nearest small semantic block gives the name/link association;
        # a whole page would incorrectly attach every profile link to a name.
        block = a.find_parent(["p", "li", "figcaption", "td", "blockquote"])
        context = block.get_text(" ", strip=True) if block else a.get_text(" ", strip=True)
        boilerplate = bool(a.find_parent(["nav", "footer", "header", "aside"])
                           or a.find_parent(attrs={"role": re.compile(r"^(navigation|contentinfo|banner|complementary)$")}))
        out.append({"url": canonical, "site": site,
                    "rel_me": "me" in rel, "same_site": same_site,
                    "boilerplate": boilerplate,
                    "anchor": a.get_text(" ", strip=True)[:200],
                    "context": re.sub(r"\s+", " ", context)[:600],
                    "source_url": source_url})
        if len(out) >= 40:
            break
    # rel=me links are self-declared identity — surface them first
    out.sort(key=lambda x: not x["rel_me"])
    return out


def enrich_candidate(candidate: Candidate, client: PoliteClient) -> Candidate:
    """Fetch the candidate URL and fill public_text / keywords / image / links."""
    try:
        resp = _fetch_public(candidate, client)
    except Exception as exc:
        candidate.fetch_status = "error"
        candidate.fetch_error = f"request_failed:{type(exc).__name__}"
        return candidate
    if resp is None or resp.status_code >= 400:
        candidate.fetch_status = "error"
        candidate.fetch_error = ("no_response" if resp is None else
                                 (getattr(resp, "extensions", {}).get("read_error")
                                  or f"HTTP {resp.status_code}"))
        return candidate
    content = getattr(resp, "content", b"")
    if not isinstance(content, bytes):
        content = b""
    if len(content) > MAX_DOCUMENT_BYTES:
        candidate.fetch_status = "error"
        candidate.fetch_error = "document_exceeds_2_MiB"
        candidate.note = (candidate.note + " [reader: document exceeds 2 MiB]").strip()
        return candidate
    ctype = (getattr(resp, "headers", {}) or {}).get("content-type", "").lower()
    is_pdf = "application/pdf" in ctype or content.startswith(b"%PDF-")
    if is_pdf:
        try:
            from pypdf import PdfReader

            reader = PdfReader(BytesIO(content))
            pages: list[str] = []
            for page in reader.pages[:MAX_PDF_PAGES]:
                pages.append(page.extract_text() or "")
                if sum(map(len, pages)) >= MAX_PUBLIC_TEXT:
                    break
            text = "\n".join(pages)[:MAX_PUBLIC_TEXT]
        except Exception:
            candidate.fetch_status = "error"
            candidate.fetch_error = "PDF_text_unavailable"
            candidate.note = (candidate.note + " [reader: PDF text unavailable]").strip()
            return candidate
    else:
        if ctype and not any(t in ctype for t in ("html", "text/plain", "xml")):
            candidate.fetch_status = "empty"
            candidate.fetch_error = "unsupported_content_type"
            return candidate
        html = resp.text[:MAX_DOCUMENT_BYTES]
        text = extract_public_text(html, include_comments=candidate.platform == 'web')
        candidate.image_url = _og_image(html)
        candidate.public_links = extract_cross_links(html, candidate.url, include_same_site=True)
    # JavaScript shells can contain only zero-width formatting characters.
    # They are unreadable responses, not successfully examined documents.
    if not ''.join(ch for ch in text if unicodedata.category(ch) != 'Cf').strip():
        text = ''
    candidate.fetch_status = "ok" if text.strip() or candidate.public_links else "empty"
    candidate.fetch_error = 'no_readable_text' if candidate.fetch_status == 'empty' else ''
    # prefer richer of fetched text vs the SERP snippet we already had
    if candidate.platform != 'web' and len(text) < len(candidate.snippet):
        text = f"{text} {candidate.snippet}".strip()
    candidate.public_text = text[:MAX_PUBLIC_TEXT]
    candidate.keywords = naive_keywords(text)
    return candidate


def download_images(candidates, out_dir: str, client: PoliteClient) -> list[str]:
    """Download each candidate's public profile photo into out_dir.

    Returns the saved file paths. Used to feed EXIF / object detection.
    Note: platform CDNs usually strip EXIF from served images, so treat
    geotags from these as a bonus, not a guarantee.
    """
    import os

    os.makedirs(out_dir, exist_ok=True)
    saved: list[str] = []
    for i, c in enumerate(candidates):
        if not c.image_url:
            continue
        resp = client.get(c.image_url)
        if resp is None or resp.status_code >= 400 or not resp.content:
            continue
        ext = ".jpg"
        ctype = resp.headers.get("content-type", "")
        if "png" in ctype:
            ext = ".png"
        elif "webp" in ctype:
            ext = ".webp"
        path = os.path.join(out_dir, f"{c.platform}_{c.handle or i}{ext}")
        try:
            with open(path, "wb") as fh:
                fh.write(resp.content)
            saved.append(path)
        except OSError:
            continue
    return saved
