"""Per-run query reuse and observable, thread-safe search accounting."""
from __future__ import annotations

from concurrent.futures import Future
from dataclasses import replace
import threading
import time
from urllib.parse import urlsplit


def _valid_url(url):
    if not isinstance(url, str):
        return False
    try:
        parsed = urlsplit(url)
        return parsed.scheme in ('http', 'https') and bool(parsed.hostname)
    except (TypeError, ValueError):
        return False


class SearchRun:
    def __init__(self, backend, max_queries: int | None = None, journal=None):
        if max_queries is not None and (not isinstance(max_queries, int) or max_queries < 0):
            raise ValueError('max_queries must be a nonnegative integer or None')
        self.backend = backend
        self.max_queries = max_queries
        self._cache: dict[tuple[str, int, str, str, int], Future] = {}
        self._lock = threading.Lock()
        self.records: list[dict] = []
        self.cache_hits = 0
        self._queries_started = 0
        self._budget_skips: dict[tuple[str, int, str, str, int], dict] = {}
        self._reserved_queries = 0
        self.journal = journal

    def reserve_queries(self, count: int):
        """Hold capacity for a later phase, including late owner contradictions."""
        with self._lock:
            self._reserved_queries = max(0, min(count, self.max_queries or 0))

    @property
    def remaining_queries(self):
        with self._lock:
            return (None if self.max_queries is None else
                    max(0, self.max_queries - self._reserved_queries - self._queries_started))

    def is_available(self):
        return self.backend.is_available()

    @property
    def errors(self):
        return getattr(self.backend, 'errors', [])

    def search(self, query: str, max_results: int = 20):
        return self._search(query, max_results)

    def search_profiles(self, query: str, max_results: int = 20, *, platform: str, name: str):
        return self._search(query, max_results, platform, name)

    def search_publications(self, query: str, max_results: int = 20, *, name: str):
        return self._search(query, max_results, 'web', name)

    @property
    def supports_paging(self):
        return getattr(self.backend, 'supports_paging', callable(getattr(self.backend, 'search_page', None)))

    def search_page(self, query: str, max_results: int = 20, *, page: int = 2,
                    platform: str = '', name: str = ''):
        return self._search(query, max_results, platform, name, page)

    def _search(self, query: str, max_results: int, platform: str = '', name: str = '', page: int = 1):
        # A larger prior request can satisfy the smaller related-search request.
        # Generic hits cannot satisfy a profile-qualified lookup: they may have
        # stopped the provider chain at a directory or an unrelated account.
        key = (query, max_results, platform, name, page)
        with self._lock:
            prior = next((future for (q, n, p, target, cached_page), future in self._cache.items()
                          if q == query and n >= max_results and (p, target, cached_page) == (platform, name, page)), None)
            owner = prior is None
            if owner:
                if self.max_queries is not None and self._queries_started >= self.max_queries - self._reserved_queries:
                    self._budget_skips[key] = {'query': query, 'max_results': max_results,
                                               'platform': platform, 'target_name': name,
                                               'page': page,
                                               'reason': 'reserved_for_related' if self._reserved_queries else 'budget_exhausted'}
                    return []
                self._budget_skips.pop(key, None)
                self._queries_started += 1
                sequence = self._queries_started
                prior = self._cache[key] = Future()
            else:
                self.cache_hits += 1
        if not owner:
            return [replace(hit) for hit in prior.result()[:max_results]]
        started = time.monotonic()
        record = {'query': query, 'page': page, 'max_results': max_results, 'status': 'ok', 'sequence': sequence}
        if platform:
            record.update(platform=platform, target_name=name,
                          mode='publications' if platform == 'web' else 'profiles')
        try:
            saved = self.journal.lookup(key) if self.journal else None
            profile_search = getattr(self.backend, 'search_profiles', None)
            if saved is not None:
                hits = saved
                record['resumed'] = True
            elif page > 1:
                hits = self.backend.search_page(query, max_results=max_results, page=page,
                                               **({'platform': platform, 'name': name} if platform else {})) or []
            elif platform == 'web':
                publication_search = getattr(self.backend, 'search_publications', None)
                hits = (publication_search(query, max_results=max_results, name=name)
                        if callable(publication_search) else self.backend.search(query, max_results=max_results)) or []
            elif platform and callable(profile_search):
                hits = profile_search(query, max_results=max_results, platform=platform, name=name) or []
            else:
                hits = self.backend.search(query, max_results=max_results) or []
            record['invalid_results'] = sum(not _valid_url(hit.url) for hit in hits)
            hits = [hit for hit in hits if _valid_url(hit.url)]
            provider = getattr(self.backend, 'name', '')
            hits = [replace(hit, query=query, page=page, provider=hit.provider or provider) for hit in hits]
            record.update(results=len(hits), providers=sorted({h.provider for h in hits}))
            record['result_urls'] = [h.url for h in hits]
            record.update(cached_results=sum(h.cached for h in hits),
                          stale_results=sum(h.stale for h in hits),
                          partial_results=sum(h.partial for h in hits))
            if not hits:
                record['status'] = 'empty'
                query_attempts = [r for r in getattr(self.backend, 'attempts', [])
                                  if r['query'] == query and r.get('page', 1) == page]
                if (any(r['status'] in ('error', 'cooldown') for r in query_attempts)
                        and not any(r['status'] in ('ok', 'empty') for r in query_attempts)):
                    record['status'] = 'unavailable'
                statuses = getattr(self.backend, 'provider_statuses', lambda: [])()
                record['partial_query'] = (any(r['status'] in ('error', 'cooldown') for r in query_attempts)
                    or any(r['status'] == 'cooldown' or any(e['status'] == 'cooldown'
                           for e in r.get('engine_selection', {}).get('engines', [])) for r in statuses))
            if self.journal:
                self.journal.save(key, record, hits)
            prior.set_result(hits)
            return [replace(hit) for hit in hits]
        except Exception as exc:
            record.update(status='error', error=type(exc).__name__, results=0)
            prior.set_exception(exc)
            raise
        finally:
            record['seconds'] = round(time.monotonic() - started, 3)
            with self._lock:
                self.records.append(record)

    def stats(self):
        attempts = list(getattr(self.backend, 'attempts', []))
        statuses = getattr(self.backend, 'provider_statuses', lambda: [])()
        degraded = (any(r['status'] in ('error', 'cooldown') for r in attempts)
                    or any(r.get('partial_results') for r in self.records)
                    or any('engine ' in e for e in self.errors)
                    or any(r['status'] == 'cooldown' for r in statuses)
                    or any(e['status'] == 'cooldown' for r in statuses
                           for e in r.get('engine_selection', {}).get('engines', [])))
        with self._lock:
            budget_skips = list(self._budget_skips.values())
        return {'search_queries': len(self.records), 'search_cache_hits': self.cache_hits,
                'search_query_budget': self.max_queries,
                'resumed_queries': sum(bool(r.get('resumed')) for r in self.records),
                'search_budget_exhausted': any(r['reason'] == 'budget_exhausted' for r in budget_skips),
                'search_reserved_queries': self._reserved_queries,
                'budget_skipped_queries': len(budget_skips),
                'budget_skips': sorted(budget_skips, key=lambda r: (r['query'], r['platform'])),
                'query_errors': sum(r['status'] in ('error', 'unavailable') for r in self.records),
                'unavailable_queries': sum(r['status'] == 'unavailable' for r in self.records),
                'empty_queries': sum(r['status'] == 'empty' for r in self.records),
                'provider_requests': sum(r.get('requested', True) for r in attempts),
                'provider_skipped_requests': sum(r['status'] == 'cooldown' for r in attempts),
                'provider_statuses': statuses,
                'search_degraded': degraded,
                'cached_results': sum(r.get('cached_results', 0) for r in self.records),
                'stale_results': sum(r.get('stale_results', 0) for r in self.records),
                'partial_results': sum(r.get('partial_results', 0) for r in self.records),
                'provider_cache_hits': getattr(self.backend, 'provider_cache_hits', 0),
                'provider_response_cache_hits': getattr(self.backend, 'provider_response_cache_hits', 0),
                'provider_errors': sum(r['status'] == 'error' for r in attempts),
                'provider_attempts': sorted(attempts, key=lambda r: (r['query'], r['provider'])),
                'queries': sorted(self.records, key=lambda r: r['query'])}
