"""Online discovery layer (the ONLY networked part of the tool).

Given a person's name plus disambiguators, it locates candidate public
profiles (Instagram / Facebook / LinkedIn) via search-engine dorking and
extracts the public text those pages expose to bots (og:/meta tags). A human
confirms which candidates are the real target before anything is trusted.

Reality: none of the three platforms offer a free people-search API and all
block scraping / hide content behind login. So we do NOT try to reliably
scrape post bodies — we harvest the public link-preview metadata that is
actually served, and lean on human-in-the-loop confirmation.
"""

from .models import Candidate, DiscoveryResult, SearchResult
from .pipeline import discover, enrich

__all__ = ["Candidate", "DiscoveryResult", "SearchResult", "discover", "enrich"]
