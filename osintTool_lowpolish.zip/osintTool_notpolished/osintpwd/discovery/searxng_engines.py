"""Learn working engines from the instance's own responses, without a fixed list."""
from __future__ import annotations

from dataclasses import dataclass
import re
import threading
import time
from . import cache



def engine_error(raw: str) -> str:
    for token, label in (('captcha', 'challenge'), ('too many', 'rate_limited'),
                         ('rate', 'rate_limited'), ('timeout', 'timeout'),
                         ('timed out', 'timeout'), ('parsing', 'parse_error'),
                         ('connection', 'connection_error'), ('access denied', 'access_denied')):
        if token in raw.casefold():
            return label
    return 'engine_error'


def valid_engine(value) -> bool:
    return isinstance(value, str) and re.fullmatch(r'[a-zA-Z0-9_. -]{1,60}', value) is not None


@dataclass
class Engine:
    successes: int = 0
    used: int = 0
    retry_at: float = 0
    reason: str = ''
    paging: bool = False
    failures: int = 0


class EnginePool:
    def __init__(self, scope: str = ''):
        self.lock = threading.Lock()
        self.engines: dict[str, Engine] = {}
        self.requests = 0
        self.calibrated_at = 0.0
        self.last_selected: list[str] = []
        self.scope = scope
        self.inventory_known = False
        self.inventory_at = 0.0
        self.inventory_lock = threading.Lock()
        saved = cache.read_state('engines:' + scope) if scope else {}
        for name, state in saved.get('engines', {}).items():
            if valid_engine(name):
                remaining = max(0, min(86400, state.get('retry_at', 0) - time.time()))
                if state.get('reason') == 'challenge' and name == 'duckduckgo':
                    remaining = min(remaining, 300 * (2 ** min(3, max(0, state.get('failures', 1) - 1))))
                self.engines[name] = Engine(successes=state.get('successes', 0),
                    retry_at=time.monotonic() + remaining if remaining else 0,
                    reason=state.get('reason', '') if remaining else '', paging=state.get('paging', False),
                    failures=state.get('failures', 0))

    def refresh_inventory(self, client, base: str) -> None:
        with self.inventory_lock:
            if self.inventory_at and time.monotonic() - self.inventory_at < 600:
                return
            self.inventory_at = time.monotonic()
            try:
                response = client.get(base + '/config', request_attempts=1, timeout=5)
                data = response.json() if response is not None and response.status_code == 200 else {}
                if not isinstance(data, dict) or not isinstance(data.get('engines'), list):
                    return
                enabled = {e['name']: e for e in data['engines'] if isinstance(e, dict)
                           and valid_engine(e.get('name')) and e.get('enabled')
                           and 'general' in e.get('categories', [])
                           and ('web' in e.get('categories', []) or
                                (e.get('categories') == ['general'] and e.get('paging')))}
                with self.lock:
                    self.engines = {name: self.engines.get(name, Engine()) for name in enabled}
                    for name, e in enabled.items():
                        self.engines[name].paging = bool(e.get('paging'))
                    self.inventory_known = True
            except Exception:
                # Older/private instances may not expose /config. Learn from
                # responses once, but never retry known cooling engines blindly.
                return

    def _persist(self):
        if self.scope:
            now = time.monotonic()
            cache.write_state('engines:' + self.scope, {'engines': {
                name: {'successes': e.successes, 'reason': e.reason, 'paging': e.paging, 'failures': e.failures,
                       'retry_at': time.time() + max(0, e.retry_at - now)}
                for name, e in self.engines.items()}})

    def choose(self, page: int = 1) -> list[str] | None:
        with self.lock:
            now = time.monotonic()
            self.requests += 1
            ready = [name for name, state in self.engines.items()
                     if state.retry_at <= now and (page == 1 or state.paging)]
            blocked = len(ready) < len(self.engines)
            # The first query discovers the actual instance defaults. Recalibrate
            # after ten minutes when doing so will not retry a cooling engine.
            if page == 1 and not self.inventory_known and (not self.engines or
                    (not blocked and now - self.calibrated_at >= 600)):
                self.calibrated_at = now
                self.last_selected = []
                return []
            if not ready:
                self.last_selected = []
                return None  # No eligible source; do not fall back to defaults.
            ready.sort(key=lambda name: (-self.engines[name].successes, self.engines[name].used, name))
            selected = ready[:2]
            # A third slot probes recovered/less-used sources. Do not permanently
            # lock the instance to the first source that happened to return a hit.
            other = [name for name in ready if name not in selected]
            if other:
                selected.append(min(other, key=lambda name: (self.engines[name].used, name)))
            for name in selected:
                self.engines[name].used = self.requests
            self.last_selected = selected
            return selected

    def observe(self, data: dict, selected: list[str]) -> None:
        with self.lock:
            now = time.monotonic()
            failed = set()
            for item in data.get('unresponsive_engines', []):
                if not isinstance(item, (list, tuple)) or len(item) < 2 or not valid_engine(item[0]):
                    continue
                name, reason = item[0], engine_error(str(item[1]))
                state = self.engines.setdefault(name, Engine())
                # Two in-flight queries failing together are one failure episode.
                if state.retry_at <= now or state.reason != reason:
                    state.reason = reason
                    state.failures += 1
                    base = {'challenge': 300 if name == 'duckduckgo' else 3600, 'rate_limited': 180,
                        'timeout': 60, 'connection_error': 60, 'parse_error': 300}.get(reason, 300)
                    state.retry_at = now + min(14400, base * 2 ** min(3, state.failures - 1))
                failed.add(name)
            successful = set()
            for item in data.get('results', []):
                names = item.get('engines') or [item.get('engine')]
                if isinstance(names, list):
                    successful.update(name for name in names if valid_engine(name))
            for name in (set(selected) | successful) - failed:
                state = self.engines.setdefault(name, Engine())
                if state.retry_at > now and name not in successful:
                    continue
                state.retry_at, state.reason = 0, ''
                state.failures = 0
                if name in successful:
                    state.successes += 1
            self._persist()

    def snapshot(self) -> dict:
        with self.lock:
            now = time.monotonic()
            return {'selected': list(self.last_selected), 'inventory_known': self.inventory_known,
                    'selection': 'adaptive' if self.last_selected else 'paused' if self.engines or self.inventory_known else 'instance_defaults',
                    'engines': [{'engine': name, 'status': 'cooldown' if state.retry_at > now else 'ready',
                                 'reason': state.reason, 'retry_after_seconds': max(0, int(state.retry_at - now)),
                                 'successful_queries': state.successes}
                                for name, state in sorted(self.engines.items())]}


_POOLS: dict[str, EnginePool] = {}
_LOCK = threading.Lock()


def engine_pool(scope: str) -> EnginePool:
    with _LOCK:
        if scope not in _POOLS:
            if len(_POOLS) >= 32:
                _POOLS.pop(next(iter(_POOLS)))
            _POOLS[scope] = EnginePool(scope)
        return _POOLS[scope]
