"""Small public-reference benchmark. Run the same command against either source tree.

No passwords, cookies or API keys are exported. Unknown accounts stay unlabelled.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import threading
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(Path(args.source_root).resolve()))
    from osintpwd.env import load_env
    from osintpwd.discovery.pipeline import discover
    from osintpwd.discovery.http import PoliteClient
    from osintpwd.discovery.search import default_backend
    from dataclasses import asdict
    load_env()
    # Reference label is platform-specific; other proposals are NOT negatives.
    cases = [('Linus Torvalds', 'github', 'torvalds')]
    report = {'scope': 'discover, username_scan=False; one labelled public reference; no precision estimate',
              'source_root': str(Path(args.source_root).resolve()), 'cases': []}
    for name, platform, handle in cases:
        records = []
        lock = threading.Lock()
        with PoliteClient(min_interval=0.3, timeout=15, max_retries=2) as client:
            backend = default_backend(client)
            original = backend.search
            def recorded(query, max_results=20):
                start = time.perf_counter()
                hits = original(query, max_results=max_results)
                with lock:
                    records.append({'query': query, 'seconds': round(time.perf_counter()-start, 3),
                                    'hits': [asdict(hit) for hit in hits]})
                return hits
            backend.search = recorded
            start = time.perf_counter()
            result = discover(name, backend=backend, username_scan=False)
            seconds = time.perf_counter() - start
        rank = next((i+1 for i,c in enumerate(result.candidates)
                     if c.platform == platform and c.handle.lower() == handle), None)
        row = {'name': name, 'expected': {'platform': platform, 'url': 'https://github.com/torvalds'},
               'seconds': round(seconds, 2), 'queries': len(records), 'candidate_count': len(result.candidates),
               'known_account_rank': rank, 'known_account_recall': int(rank is not None),
               'hit_at_10': int(rank is not None and rank <= 10), 'result': asdict(result), 'searches': records}
        report['cases'].append(row)
        print(json.dumps({k:v for k,v in row.items() if k not in ('result','searches')}, ensure_ascii=False), flush=True)
    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
