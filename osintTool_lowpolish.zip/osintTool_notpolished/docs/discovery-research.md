# Discovery: current design and limits

Updated 2026-09-27. This document describes the saved implementation, rather
than earlier prototypes. Measured results are in [the quality report](discovery-quality-report.md).

## Retrieval and identity

Keep every recognised profile in the bounded returned search results, including
weak matches. Rank owner-name/title and full-name-handle evidence ahead of mere
mentions. Merge repeated source records; repetition does not add an identity
bonus. The score is an uncalibrated rank. Groups are possible shared-username
hypotheses, not verified identities.

The default fallback provider chain is Serper, Google CSE, SearXNG (when
configured), DuckDuckGo. One nonempty provider wins each query. SearchRun deduplicates
concurrent identical queries and records query/provider/count/time/error data.
There is no RRF, provider pagination, persistent cache or adaptive ML ranker.

## Public sources and co-mentions

Main HTML text extraction uses Trafilatura, retaining metadata as a separate
text portion. BeautifulSoup provides the fallback. PDF text is bounded to five
pages; DOCX and OCR are not implemented in the discovery reader.

Reference: [Trafilatura Python usage](https://trafilatura.readthedocs.io/en/latest/usage-python.html).

Defaults: eight concurrent search workers; four initial source documents; two
initial profile documents; at most three concurrent initial page reads. Source
selection avoids filling all slots with one social host's indexed posts. Document
processing retains 24,000 text characters; public GET streams at most 2 MiB and
checks up to five redirects. Public IP/DNS checks are preflight checks, not a
pinned-address transport or complete defence against DNS rebinding. Search-provider
requests use the separate regular client so explicitly configured local SearXNG
continues to work.

The automatic related stage runs without strong owner-name candidates. Manual
continuation can also run after unsuitable namesake results. It reuses source
text, considers at most two associates, reads at most two extra source pages
when necessary and at most two associate profiles total. Only one hop is made.
Name-attached links and explicit platform mentions preserve the entire source
chain. A person mentioned in an associate profile is not automatically its owner.
Boilerplate links and substring name collisions are excluded from that claim.

Open-source availability is limited by indexing, login walls, deleted pages,
provider failures and extraction errors. All suggestions still require human
assessment. A co-mention does not establish a relationship between people.

## UI and data contract

Discovery, continuation and the CLI share the core implementation. The API adds
serialization and validation, not a separate retrieval algorithm. The UI shows
source excerpts, matching reasons, weak username evidence, related accounts and
partial failures. JSON export retains source text and query statistics. Manual
continuation preserves earlier results and separate run statistics. It does not
persist an analyst's selections across browser sessions.

Playwright is an optional Bing search backend only. There is no automatic
JavaScript page renderer; adding one should be justified by measured missing
accounts on an independent labelled set. No new browser dependencies were added.

## Reproducible evaluation

`tests/discovery_benchmark.py` runs identical stored search/HTML inputs against
any source snapshot with all real HTTP disabled. NER is deterministic in this
fixture suite, so it does not measure spaCy accuracy. The metric implementation
is the same for both versions, and both result files retain a fixture hash.

Use `platform + canonical URL` in `expect`, `expect_related` and `reject`.
Known-account recall measures only labelled known accounts. Unknown proposals
are not counted as false positives. `precision_at_k` is null when any returned
top-k proposal is unjudged; judged-only precision has a separate field and
coverage. `related_searched` is an attempt flag, separate from people found,
associate accounts proposed and target accounts reached through them.

Page counters ending in `_read` mean attempts; `_ok` means useful text/links
were returned. Offline processing time is not a measure of live latency. Live
runs are point measurements: provider and index changes confound comparisons.
Use a separate held-out RU/KZ/Latin dataset before claiming population accuracy.
