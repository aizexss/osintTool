# Adaptive discovery and CAPTCHA limits — 29 September 2026

The dashboard still has one analysis action and a total budget of 24 logical
queries. Verification is intentionally focused on critical evidence gates and
real exported runs, rather than an expanding synthetic accuracy benchmark.

## Implemented

- At most two follow-up searches from an observed name-matching profile:
  username plus name components, and exact profile address for backlinks.
- Follow-ups replace long-tail retries within the existing query budget.
  Partial-name and username-only suggestions cannot seed these searches.
- A pivot result must actually contain the observed handle before it receives
  a speculative page read. Engines can ignore exact query terms.
- Final source admission still requires a local name mention or an explicit,
  non-navigation link to a name-matching profile.
- Name context requires adjacent name components (either order, with one
  optional middle name/initial). Two different people in a directory no longer
  combine into one match. Contact-broker pages are excluded from publications.
- `stats.query_yield` and the dashboard disclosure show query-level retained
  accounts/materials, first-seen findings, URL repeats, cache use and failures.
  These are retrieval counts, not identity precision or recall. Username scans
  are counted separately; user confirmation is never inferred from retrieval.

## Live observations

An uncached browser run for the supplied `Zhumali Muhammed` query completed in
51.1 seconds: 24 logical queries, 25 provider requests, 146 raw hits, 30 repeated
URLs, 8 account suggestions (one full-name LinkedIn match) and one repository
with an author mention. Both adaptive queries executed, but added zero new
retained accounts/materials in this case. No universal improvement is claimed.

A subsequent cached run completed in 15.4 seconds and exposed a false source
match: `Muhammed Saeed` and `Zhazira Zhumali` in one directory excerpt. That live
finding led to the tighter name-context rule above. It also exposed unwanted
contact-broker pages. The final browser run completed in 14.5 seconds with
24 logical queries, 3 provider requests and 149 cached hits. It retained all
8 account suggestions and the repository; the contact-broker and mixed-name
sources were absent. This is a cache-assisted rerun, not an uncached speed
benchmark. `final-results.json` and `query-report.png` record the final state.

Focused checks cover publication admission, pivot budget, duplicate counting,
co-mention handling and the existing dashboard interactions. A full-suite rerun
was intentionally not used as the quality criterion.

Local evidence directory:
`C:\Users\aibar\AppData\Local\Temp\osint-adaptive-20260929-142431`.

## CAPTCHA: practical next steps, not implemented workarounds

Live engine diagnostics showed Yahoo supplying successful results while Google
and DuckDuckGo reported challenges; Brave reported rate limits and Yandex a
parse error. Changing user-agent strings or enabling more engines does not
establish that they are usable. The existing 1.5-second provider pacing, cache,
low concurrency and cooldowns remain active.

1. Preserve provider/engine cooldowns across service restarts, then send one
   recovery probe before returning an engine to normal use. Currently cooldown
   state in the Python layer is process-local. Honour upstream suspension times.
2. Offer optional manual recovery in a browser using the server's external IP.
   Verify that the engine works afterwards; a successful browser challenge does
   not establish that a separate HTTP client/session is unblocked. Analysis can
   continue with available providers in the meantime.
3. Diversify actual usable indexes and compare retained findings, not raw hit
   counts. Do not describe Startpage as CAPTCHA-free: its current SearXNG docs
   describe a CPU-intensive proof-of-work challenge and an inactive default.
4. For a more reliable independent index, optionally integrate Brave Search API
   for a few high-value queries per analysis, keeping the same single button.
   This adapter is not present yet. Published Search pricing is $5/1000 requests
   with $5 monthly credit; signup/key/card and suitable result-storage rights
   must be checked. No signup, payment, key access or API integration was done.

Official references checked on 29 September 2026:

- [Google: unusual traffic](https://support.google.com/websearch/answer/86640?hl=en)
- [SearXNG: answer CAPTCHA from server IP](https://docs.searxng.org/admin/answer-captcha.html)
- [SearXNG suspension settings](https://docs.searxng.org/admin/settings/settings_search.html)
- [SearXNG Startpage engine](https://docs.searxng.org/dev/engines/online/startpage.html)
- [Brave API pricing and requirements](https://brave.com/search/api/)

Photo-based identity/account matching was not added. Image-duplicate search or
comparison of non-facial details remains a separate, unanswered scope choice.
