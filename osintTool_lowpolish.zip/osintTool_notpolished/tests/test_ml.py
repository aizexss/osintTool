"""Offline tests for the ML enrichment layer (no heavy models needed)."""

from __future__ import annotations

import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from osintpwd.ml.enricher import enrich_profile  # noqa: E402
from osintpwd.ml.exif import ExifData, _to_degrees, _tokens_from_exif  # noqa: E402
from osintpwd.ml.gazetteer import match_interests  # noqa: E402
from osintpwd.ml.ner import extract_entities  # noqa: E402
from osintpwd.models import Profile  # noqa: E402

SAMPLE = (
    "Aslan Serikov from Almaty. Huge Khabib Nurmagomedov and Real Madrid fan. "
    "Drives a Toyota Camry. Married in 2018. Contact aslan.serikov@mail.kz @asik_94"
)


def test_gazetteer_matches():
    found = {t for t, _ in match_interests(SAMPLE)}
    assert "khabib" in found
    assert "realmadrid" in found
    assert "toyota" in found or "camry" in found


def test_ner_rulebased():
    ent = extract_entities(SAMPLE, use_spacy=False)
    assert "2018" in ent.years
    assert any("aslan" in e.lower() for e in ent.emails)
    assert "asik_94" in ent.handles
    assert any("Almaty" in p for p in ent.proper_nouns)
    assert "khabib" in ent.interests


def test_ner_tokens_flatten():
    ent = extract_entities(SAMPLE, use_spacy=False)
    toks = [t.lower() for t in ent.all_tokens()]
    assert "2018" in toks
    assert "khabib" in toks


def test_to_degrees():
    assert abs(_to_degrees((43, 15, 0)) - 43.25) < 1e-9


def test_exif_tokens():
    d = ExifData(path="x.jpg", datetime="2021:07:14 18:33:02",
                 camera_make="Apple", camera_model="iPhone 12")
    toks = _tokens_from_exif(d)
    assert "2021" in toks and "21" in toks
    assert "Apple" in toks
    assert "iPhone12" in toks


def test_exif_on_plain_image_no_crash():
    from PIL import Image
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "plain.png")
        Image.new("RGB", (8, 8), (120, 120, 120)).save(p)
        from osintpwd.ml.exif import extract_exif
        data = extract_exif(p)
        assert data.gps_lat is None  # no exif, but no exception


def test_enrich_profile_from_text():
    base = Profile(first_name="Aslan", last_name="Serikov", city="Almaty")
    res = enrich_profile(base, text=SAMPLE, use_spacy=False)
    assert "khabib" in [i.lower() for i in res.profile.interests]
    assert 2018 in res.profile.significant_years
    # the enriched profile should now reject a Khabib-based password
    from osintpwd import evaluate_password
    v = evaluate_password("khabibNurmagomedov777", res.profile)
    assert not v.allowed


def _run_all():
    fns = [g for n, g in sorted(globals().items()) if n.startswith("test_")]
    passed = 0
    for fn in fns:
        try:
            fn()
        except AssertionError as e:
            print(f"FAIL {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            print(f"ERROR {fn.__name__}: {e!r}")
        else:
            passed += 1
            print(f"ok   {fn.__name__}")
    print(f"\n{passed}/{len(fns)} passed")
    return passed == len(fns)


if __name__ == "__main__":
    raise SystemExit(0 if _run_all() else 1)
