import os
import subprocess
import sys

import httpx

from osintpwd.discovery import cache, search
from osintpwd.discovery.models import SearchResult


def test_cache_survives_another_process_and_keeps_provenance(tmp_path, monkeypatch):
    path = tmp_path / 'cache.sqlite3'
    monkeypatch.setenv('OSINT_SEARCH_CACHE_PATH', str(path))
    program = """
from osintpwd.discovery import cache
from osintpwd.discovery.models import SearchResult
cache.write('scope', 'Dana Kim', 10, [SearchResult(url='https://example.org/dana',
    provider='searxng:brave', query='Dana Kim', retrieved_at='2026-09-29T00:00:00Z')])
"""
    subprocess.run([sys.executable, '-c', program], check=True, env=os.environ.copy())
    hit = search._cached_response('scope', 'Dana Kim', 10)[0]
    assert hit.cached and not hit.stale
    assert hit.provider == 'searxng:brave'
    assert hit.retrieved_at == '2026-09-29T00:00:00Z'
    assert search._cached_response('other-key-scope', 'Dana Kim', 10) is None


def test_disk_stale_only_on_failure_and_empty_refresh_invalidates(tmp_path, monkeypatch):
    monkeypatch.setenv('OSINT_SEARCH_CACHE_PATH', str(tmp_path / 'cache.sqlite3'))
    now = [10000.0]
    monkeypatch.setattr(cache.time, 'time', lambda: now[0])
    cache.write('scope', 'query', 10, [SearchResult(url='https://example.org')])
    now[0] += 601
    assert search._cached_response('scope', 'query', 10) is None
    hit = search._cached_response('scope', 'query', 10, stale=True)[0]
    assert hit.stale and hit.cache_age_seconds >= 601
    search._remember_response('scope', 'query', 10, [])
    search._RESPONSE_CACHE.clear()
    assert search._cached_response('scope', 'query', 10, stale=True) is None


def test_expired_disk_entries_and_corruption_do_not_stop_search(tmp_path, monkeypatch):
    path = tmp_path / 'cache.sqlite3'
    monkeypatch.setenv('OSINT_SEARCH_CACHE_PATH', str(path))
    monkeypatch.setattr(cache.time, 'time', lambda: 1000)
    cache.write('scope', 'query', 10, [SearchResult(url='https://example.org')])
    monkeypatch.setattr(cache.time, 'time', lambda: 5000)
    assert cache.read('scope', 'query', 10) is None
    path.write_bytes(b'corrupt fixture')
    assert cache.read('scope', 'query', 10) is None
    cache.write('scope', 'query', 10, [SearchResult(url='https://example.org')])


def test_disk_entry_limit(tmp_path, monkeypatch):
    monkeypatch.setenv('OSINT_SEARCH_CACHE_PATH', str(tmp_path / 'cache.sqlite3'))
    monkeypatch.setattr(cache, 'MAX_ENTRIES', 2)
    for i in range(3):
        monkeypatch.setattr(cache.time, 'time', lambda i=i: 1000 + i)
        cache.write('scope', str(i), 10, [SearchResult(url='https://example.org')])
    assert cache.read('scope', '0', 10) is None
    assert cache.read('scope', '2', 10)


def test_cached_partial_response_still_marks_search_incomplete(tmp_path, monkeypatch):
    from osintpwd.discovery.retrieval import SearchRun
    monkeypatch.setenv('OSINT_SEARCH_CACHE_PATH', str(tmp_path / 'cache.sqlite3'))
    class Client:
        def get(self, *args, **kwargs):
            return httpx.Response(200, json={'results': [{'url': 'https://example.org', 'engine': 'brave'}],
                                             'unresponsive_engines': [['google', 'CAPTCHA']]})
    def run():
        return SearchRun(search.FallbackBackend([search.SearxngBackend('http://fixture.example', Client())]))
    first = run()
    assert first.search('Dana Kim')[0].partial
    search._RESPONSE_CACHE.clear()
    second = run()
    assert second.search('Dana Kim')[0].cached
    assert second.stats()['search_degraded']
    assert second.stats()['provider_requests'] == 0
