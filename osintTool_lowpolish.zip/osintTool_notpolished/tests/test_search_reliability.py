"""Regression coverage for provider configuration, outages and query reuse."""

from concurrent.futures import ThreadPoolExecutor
import threading

import httpx
import pytest

from osintpwd.discovery.models import SearchResult
from osintpwd.discovery.retrieval import SearchRun
from osintpwd.discovery.search import FallbackBackend, SearxngBackend, SerperBackend


NAME = "Aslan Serikov"
URL = "https://linkedin.com/in/aslan-serikov"


class Client:
    def __init__(self, response):
        self.response = response
        self.calls = []

    def get(self, url, **kwargs):
        if url.endswith('/config'):
            return httpx.Response(404)
        self.calls.append((url, kwargs))
        return self.response() if callable(self.response) else self.response

    post = get


def test_searxng_respects_instance_engines_by_default(monkeypatch):
    monkeypatch.delenv("OSINT_SEARXNG_ENGINES", raising=False)
    client = Client(httpx.Response(200, json={"results": [
        {"url": URL, "title": NAME, "engine": "duckduckgo"},
    ]}))
    hit = SearxngBackend("http://localhost:8080", client).search(NAME)[0]
    assert "engines" not in client.calls[0][1]["params"]
    assert hit.url == URL and hit.provider == "searxng:duckduckgo"


def test_searxng_keeps_explicit_engine_override(monkeypatch):
    monkeypatch.setenv("OSINT_SEARXNG_ENGINES", " bing,duckduckgo ")
    client = Client(httpx.Response(200, json={"results": []}))
    SearxngBackend("http://localhost:8080", client).search(NAME)
    assert client.calls[0][1]["params"]["engines"] == "bing,duckduckgo"


def test_searxng_engine_outages_are_visible_without_losing_partial_results(monkeypatch):
    monkeypatch.delenv("OSINT_SEARXNG_ENGINES", raising=False)
    client = Client(httpx.Response(200, json={
        "results": [{"url": URL, "title": NAME}],
        "unresponsive_engines": [
            ["google", "CAPTCHA token=synthetic-secret"],
            ["brave", "Too many requests: synthetic-secret"],
            ["yandex", "parsing error for synthetic-secret"],
            ["private/token=synthetic-secret", "unknown synthetic-secret"],
        ],
    }))
    backend = FallbackBackend([SearxngBackend("http://localhost:8080", client)])
    assert backend.search(NAME)[0].url == URL
    assert "searxng: engine google: challenge" in backend.errors
    assert "searxng: engine brave: rate_limited" in backend.errors
    assert "searxng: engine yandex: parse_error" in backend.errors
    assert "synthetic-secret" not in repr((backend.errors, backend.attempts))


@pytest.mark.parametrize("status,message,label", [
    (400, "Not enough credits", "insufficient_credits"),
    (400, "Insufficient credits", "insufficient_credits"),
    (401, "private synthetic-secret", "authentication_failed"),
    (403, "private synthetic-secret", "authentication_failed"),
])
def test_serper_fatal_account_error_disables_only_this_run(status, message, label):
    client = Client(httpx.Response(status, json={"message": message}))
    serper = SerperBackend("synthetic-key", client)
    fallback = FallbackBackend([serper])
    assert fallback.search(NAME) == []
    assert fallback.search(NAME + " LinkedIn") == []
    assert len(client.calls) == 1
    assert not serper.is_available()
    assert any(label in item for item in fallback.errors)
    assert "synthetic-secret" not in repr((fallback.errors, fallback.attempts))
    assert SerperBackend("synthetic-key", client).is_available()


def test_serper_query_specific_400_does_not_disable_provider():
    client = Client(httpx.Response(400, json={"message": "Query pattern not allowed"}))
    serper = SerperBackend("synthetic-key", client)
    fallback = FallbackBackend([serper])
    assert fallback.search(NAME) == []
    assert serper.is_available()
    client.response = httpx.Response(200, json={"organic": [{"link": URL, "title": NAME}]})
    assert fallback.search(NAME + " LinkedIn")[0].url == URL
    assert len(client.calls) == 2


def test_concurrent_serper_credit_failure_uses_one_http_probe():
    entered, release = threading.Event(), threading.Event()
    barrier = threading.Barrier(8)

    def exhausted():
        entered.set()
        assert release.wait(3)
        return httpx.Response(400, json={"message": "Not enough credits"})

    client = Client(exhausted)
    fallback = FallbackBackend([SerperBackend("synthetic-key", client)])

    def search(index):
        barrier.wait(timeout=3)
        return fallback.search(f"{NAME} {index}")

    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(search, index) for index in range(8)]
        try:
            assert entered.wait(3)
        finally:
            release.set()
        assert [future.result(timeout=3) for future in futures] == [[]] * 8
    assert len(client.calls) == 1


class Backend:
    def __init__(self, name, hits):
        self.name, self.hits = name, hits
        self.calls = []

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        self.calls.append((query, max_results))
        return self.hits[:max_results]


def test_provider_cache_reuses_generic_hits_but_continues_qualified_fallback():
    first = Backend("first", [SearchResult("https://example.org/news", "Public article")])
    second = Backend("second", [SearchResult(URL, NAME)])
    backend = FallbackBackend([first, second])
    run = SearchRun(backend)
    assert run.search(NAME)[0].url == "https://example.org/news"
    recovered = run.search_profiles(NAME, max_results=10, platform="linkedin", name=NAME)
    assert recovered[0].url == URL
    assert len(first.calls) == len(second.calls) == 1
    assert run.stats()["provider_requests"] == 2
    assert run.stats()["provider_cache_hits"] == 1


def test_provider_cache_is_shared_by_target_but_not_by_provider():
    first = Backend("first", [SearchResult(URL, NAME)])
    other = "https://linkedin.com/in/synthetic-other"
    second = Backend("second", [SearchResult(other, "Dias Muratov")])
    backend = FallbackBackend([first, second])
    assert backend.search_profiles("same", platform="linkedin", name=NAME)[0].url == URL
    assert backend.search_profiles("same", platform="linkedin", name="Dias Muratov")[0].url == other
    assert len(first.calls) == len(second.calls) == 1


def test_provider_cache_keeps_caller_mutations_out_and_honors_larger_requests():
    provider = Backend("fixture", [SearchResult(URL, NAME), SearchResult(URL + "-2", NAME)])
    backend = FallbackBackend([provider])
    backend.search(NAME, max_results=1)[0].title = "Caller change"
    assert backend.search(NAME, max_results=1)[0].title == NAME
    assert len(backend.search(NAME, max_results=2)) == 2
    assert len(provider.calls) == 2


def test_failed_provider_attempt_is_not_cached():
    class Transient(Backend):
        def search(self, query, max_results=20):
            if not self.calls:
                self.calls.append((query, max_results))
                raise RuntimeError("temporary")
            return super().search(query, max_results)

    provider = Transient("fixture", [SearchResult(URL, NAME)])
    backend = FallbackBackend([provider])
    assert backend.search(NAME) == []
    assert backend.search(NAME)[0].url == URL
    assert len(provider.calls) == 2
