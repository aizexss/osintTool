"""Synthetic owner-name cases: a first-name match must not hide another surname."""
import pytest

from osintpwd.discovery.candidates import classify, is_name_match
from osintpwd.discovery.models import SearchResult


NAME = 'Асель Исаханова'
URL = 'https://linkedin.com/in/synthetic-owner'


@pytest.mark.parametrize('title', [
    'Асель Каримова | LinkedIn',
    'Каримова Асель - Developer',
    'Asel Karimova | LinkedIn',
    'Karimova Asel',
    'асель каримова',
    'АСЕЛЬ КАРИМОВА',
    'Асель Каримова (@synthetic_owner) • Instagram',
    'synthetic-owner (Асель Каримова) · GitHub',
])
def test_other_stated_surname_stays_a_flagged_partial_suggestion(title):
    found = classify(NAME, {}, 'linkedin', [SearchResult(URL, title)])
    assert len(found) == 1
    assert not found[0].name_match
    assert 'owner_name_conflict' in found[0].match_reasons


def test_handle_snippet_and_hints_cannot_override_another_stated_surname():
    hit = SearchResult('https://linkedin.com/in/asel-isakhanova',
                       'Asel Karimova - Engineer', 'Асель Исаханова, Almaty, Acme')
    assert not is_name_match('Asel Isakhanova', hit, 'asel-isakhanova')
    found = classify(NAME, {'city': 'Almaty', 'employer': 'Acme'}, 'linkedin', [hit])
    assert len(found) == 1 and not found[0].name_match
    assert 'owner_name_conflict' in found[0].match_reasons


@pytest.mark.parametrize('title', [
    'Асель Исаханова | LinkedIn', 'Исаханова Асель',
    'Asel Isakhanova', 'Isakhanova Asel', 'Asel Isahanova',
    'Әсел Исаханова',
])
def test_full_names_and_transliterations_are_not_rejected(title):
    assert len(classify(NAME, {}, 'linkedin', [SearchResult(URL, title)])) == 1


@pytest.mark.parametrize('title', ['', 'Асель', 'Асель И.', 'Asel I.',
                                   'Instagram', 'Public member', 'Асель - Психолог'])
def test_missing_or_ambiguous_surname_stays_an_unconfirmed_suggestion(title):
    found = classify(NAME, {}, 'linkedin', [SearchResult(URL, title)])
    if title in {'', 'Instagram', 'Public member'}:
        assert found == []  # a generic search hit supplies no relevance evidence
        return
    assert len(found) == 1
    assert not found[0].name_match
    if title.startswith(('Асель', 'Asel')):
        assert 'owner_name_incomplete' in found[0].match_reasons


@pytest.mark.parametrize('reverse', [False, True])
def test_titleless_duplicate_cannot_hide_a_conflicting_owner(reverse):
    hits = [SearchResult(URL, 'Асель Каримова'), SearchResult(URL, '')]
    found = classify(NAME, {}, 'linkedin', hits[::-1] if reverse else hits)
    assert len(found) == 1 and not found[0].name_match
    assert 'owner_name_conflict' in found[0].match_reasons


def test_single_name_search_does_not_invent_a_surname_constraint():
    assert len(classify('Асель', {}, 'linkedin', [SearchResult(URL, 'Асель Каримова')])) == 1


def test_bio_suffix_does_not_supply_a_conflicting_surname():
    hit = SearchResult(URL, 'Асель Исаханова | colleague of Асель Каримова')
    assert classify(NAME, {}, 'linkedin', [hit])[0].name_match


def test_related_person_is_compared_against_their_own_name():
    hit = SearchResult(URL, 'Асель Каримова', 'Работает с Асель Исаханова')
    assert not classify(NAME, {}, 'linkedin', [hit])[0].name_match
    assert classify('Асель Каримова', {}, 'linkedin', [hit])[0].name_match


@pytest.mark.parametrize('title', ['Асель Нурлановна Исаханова',
                                   'Исаханова Асель Нурлановна', 'Assel Isakhanova',
                                   'Asel in Almaty', 'Asel with Friends', 'Асель из Алматы',
                                   'Contact Us', 'Follow Me'])
def test_middle_names_spelling_variants_and_generic_labels_are_not_conflicts(title):
    hit = SearchResult(URL, title)
    rejected = set()
    found = classify(NAME, {}, 'linkedin', [hit], rejected_urls=rejected)
    assert rejected == set()
    if title in {'Contact Us', 'Follow Me'}:
        assert found == []
        # Generic anchors remain eligible when an explicit page link supplies
        # context; they are missing evidence, never contradictory owners.
        assert len(classify(NAME, {}, 'linkedin', [hit], linked_context=True)) == 1
    else:
        assert len(found) == 1
