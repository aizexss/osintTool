"""Concurrent query limits and bounded process-cache behavior."""

from concurrent.futures import ThreadPoolExecutor

import httpx
import pytest

from osintpwd.discovery import search
from osintpwd.discovery.models import SearchResult
from osintpwd.discovery.retrieval import SearchRun
from osintpwd.discovery.search import FallbackBackend, GoogleCSEBackend, SearxngBackend, SerperBackend


NAME = 'Aslan Serikov'
URL = 'https://linkedin.com/in/aslan-serikov'


class Backend:
    name = 'fixture'

    def __init__(self):
        self.calls = []

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        self.calls.append(query)
        return [SearchResult(URL, NAME)]


def test_budget_is_atomic_across_concurrent_queries():
    backend = Backend()
    run = SearchRun(backend, max_queries=3)
    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(run.search, [f'query {i}' for i in range(20)]))
    assert sum(bool(hits) for hits in results) == len(backend.calls) == 3
    stats = run.stats()
    assert stats['search_queries'] == 3
    assert stats['budget_skipped_queries'] == 17
    assert stats['search_budget_exhausted'] is True
    assert stats['empty_queries'] == stats['query_errors'] == 0


def test_cached_queries_remain_available_after_budget_exhaustion():
    backend = Backend()
    run = SearchRun(backend, max_queries=1)
    assert run.search(NAME)
    assert run.search('another query') == []
    assert run.search(NAME, max_results=10)[0].url == URL
    assert run.search(NAME)[0].title == NAME
    assert len(backend.calls) == 1
    assert run.stats()['search_cache_hits'] == 2
    assert run.stats()['budget_skipped_queries'] == 1


def test_repeated_skipped_query_is_counted_once():
    run = SearchRun(Backend(), max_queries=0)
    assert run.search(NAME) == run.search(NAME) == []
    assert run.stats()['search_queries'] == 0
    assert run.stats()['budget_skipped_queries'] == 1


def test_default_budget_is_unlimited_and_negative_budget_is_invalid():
    backend = Backend()
    run = SearchRun(backend)
    for i in range(30):
        assert run.search(str(i))
    assert len(backend.calls) == 30
    assert run.stats()['search_budget_exhausted'] is False
    with pytest.raises(ValueError):
        SearchRun(backend, max_queries=-1)


class Client:
    def __init__(self, data):
        self.data = data
        self.calls = []

    def get(self, url, **kwargs):
        if url.endswith('/config'):
            return httpx.Response(404)
        self.calls.append(url)
        if isinstance(self.data, Exception):
            raise self.data
        return httpx.Response(200, json=self.data)

    post = get


@pytest.fixture(autouse=True)
def isolate_process_cache(monkeypatch):
    monkeypatch.delenv('OSINT_SEARXNG_ENGINES', raising=False)
    with search._RESPONSE_CACHE_LOCK:
        search._RESPONSE_CACHE.clear()
    yield
    with search._RESPONSE_CACHE_LOCK:
        search._RESPONSE_CACHE.clear()


def searx(client, url='http://localhost:8080'):
    return FallbackBackend([SearxngBackend(url, client)])


def test_positive_response_reused_across_runs_with_provenance_and_copy_isolation():
    client = Client({'results': [{'url': URL, 'title': NAME, 'engine': 'duckduckgo'}]})
    first = SearchRun(searx(client))
    first.search(NAME)[0].title = 'caller mutation'
    second = SearchRun(searx(client))
    hit = second.search(NAME)[0]
    assert len(client.calls) == 1
    assert (hit.title, hit.query, hit.provider) == (NAME, NAME, 'searxng:duckduckgo')
    assert second.stats()['provider_response_cache_hits'] == 1
    assert second.stats()['provider_requests'] == 0


def test_positive_response_expires(monkeypatch):
    now = [1000.0]
    monkeypatch.setattr(search.time, 'monotonic', lambda: now[0])
    client = Client({'results': [{'url': URL, 'title': NAME}]})
    assert searx(client).search(NAME)
    now[0] += search._RESPONSE_CACHE_TTL + 1
    assert searx(client).search(NAME)
    assert len(client.calls) == 2


@pytest.mark.parametrize('first_data', [{'results': []}, RuntimeError('temporary')])
def test_empty_and_error_responses_are_not_cached(first_data):
    client = Client(first_data)
    assert searx(client).search(NAME) == []
    client.data = {'results': [{'url': URL, 'title': NAME}]}
    assert searx(client).search(NAME)[0].url == URL
    assert len(client.calls) == 2


def test_searx_endpoint_and_engine_override_have_separate_caches(monkeypatch):
    client = Client({'results': [{'url': URL, 'title': NAME}]})
    assert searx(client).search(NAME)
    assert searx(client, 'http://localhost:8081').search(NAME)
    monkeypatch.setenv('OSINT_SEARXNG_ENGINES', 'duckduckgo')
    assert searx(client).search(NAME)
    assert len(client.calls) == 3


@pytest.mark.parametrize('provider', ['serper', 'google_cse'])
def test_credentials_are_hashed_and_isolate_provider_caches(provider):
    client = Client({'organic': [{'link': URL, 'title': NAME}],
                     'items': [{'link': URL, 'title': NAME}]})

    def make(key, cx='engine-one'):
        backend = (SerperBackend(key, client) if provider == 'serper'
                   else GoogleCSEBackend(key, cx, client))
        return FallbackBackend([backend])

    assert make('first-synthetic-secret').search(NAME)
    assert make('second-synthetic-secret').search(NAME)
    assert make('first-synthetic-secret').search(NAME)
    assert len(client.calls) == 2
    assert 'synthetic-secret' not in repr(search._RESPONSE_CACHE)
    if provider == 'google_cse':
        assert make('first-synthetic-secret', 'engine-two').search(NAME)
        assert len(client.calls) == 3


def test_process_cache_is_bounded_by_least_recent_use(monkeypatch):
    monkeypatch.setattr(search, '_RESPONSE_CACHE_MAX_ENTRIES', 2)
    client = Client({'results': [{'url': URL, 'title': NAME}]})
    for query in ('one', 'two', 'one', 'three'):
        assert searx(client).search(query)
    assert len(search._RESPONSE_CACHE) == 2
    assert len(client.calls) == 3
    assert searx(client).search('two')
    assert len(client.calls) == 4


def test_custom_backends_never_share_process_responses():
    first, second = Backend(), Backend()
    assert FallbackBackend([first]).search(NAME)
    assert FallbackBackend([second]).search(NAME)
    assert first.calls == second.calls == [NAME]
    assert not search._RESPONSE_CACHE
