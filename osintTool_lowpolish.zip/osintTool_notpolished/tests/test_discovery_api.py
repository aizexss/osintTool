"""The dashboard exposes the same suggestions/evidence as the core pipeline."""
from unittest.mock import patch

from fastapi.testclient import TestClient

from osintpwd.discovery.models import Candidate, DiscoveryResult
from osintpwd.web.app import app


def fixture_result():
    return DiscoveryResult(
        query_name='Aslan Serikov', candidates=[Candidate(
            platform='github', url='https://github.com/fixture', handle='fixture',
            title='Aslan Serikov', snippet='Public engineering work', name_match=True,
            related_person='Dias Muratov', relation='via_related',
            evidence=[{'kind': 'co_mention', 'source_url': 'https://example.org/article',
                       'excerpt': 'Aslan Serikov and Dias Muratov'}])],
        related_searched=True, errors=['related search: provider unavailable'],
        stats={'search_queries': 4})


def test_api_preserves_core_evidence_and_errors_without_confirming_accounts():
    result = fixture_result()
    with patch('osintpwd.discovery.discover', return_value=result) as search:
        response = TestClient(app).post('/api/discover', json={'name': ' Aslan  Serikov ', 'city': 'Almaty'})
    assert response.status_code == 200
    data = response.json()
    assert data['candidates'][0]['evidence'] == result.candidates[0].evidence
    assert data['candidates'][0]['snippet'] == result.candidates[0].snippet
    assert data['candidates'][0]['confirmed'] is False
    assert data['related_searched'] is True
    assert data['notes'] == result.errors
    assert data['stats']['search_queries'] == 4
    assert data['profile']['custom'] == []
    search.assert_called_once_with('Aslan Serikov', {'city': 'Almaty'}, username_scan=True,
                                  username_provider='maigret', enrich_profiles=4,
                                  query_budget=48, search_mode='keyless')


def test_manual_related_endpoint_retains_source_text():
    long_source = 'Background. ' * 100 + 'Aslan Serikov worked with Dias Muratov.'
    with patch('osintpwd.discovery.pipeline.discover_related', return_value=fixture_result()) as search:
        response = TestClient(app).post('/api/discover/related', json={
            'name': 'Aslan Serikov', 'web_info': [{'url': 'https://example.org/article',
                                                 'excerpt': long_source}]})
    assert response.status_code == 200
    assert search.call_args.args[2][0]['excerpt'] == long_source
    assert response.json()['candidates'][0]['related_person'] == 'Dias Muratov'


def test_discovery_input_rejects_blank_names_and_non_web_sources():
    client = TestClient(app)
    assert client.post('/api/discover', json={'name': '   '}).status_code == 422
    assert client.post('/api/discover/related', json={
        'name': 'Aslan Serikov', 'web_info': [{'url': 'file:///secret'}]}).status_code == 422
