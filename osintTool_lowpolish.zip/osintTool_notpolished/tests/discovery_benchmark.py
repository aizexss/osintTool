"""Run identical offline retrieval fixtures against any checkout.

Example:
  python tests/discovery_benchmark.py --source-root C:/snapshot --output before.json
  python tests/discovery_benchmark.py --output after.json

The evaluator is always loaded from this harness's checkout so metric semantics
are identical for old and new source. HTTP and NER are fixture-only. Recorded
timings are local processing times, never estimates of live search latency.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import re
import sys
import threading
import time
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]


def benchmark(source_root: Path, fixture_path: Path) -> dict:
    source_root = source_root.resolve()
    sys.path.insert(0, str(source_root))
    from osintpwd.discovery import pipeline, related
    from osintpwd.discovery.models import SearchResult
    import httpx

    loaded = Path(pipeline.__file__).resolve()
    if not loaded.is_relative_to(source_root):
        raise RuntimeError(f"Wrong source imported: {loaded}; expected {source_root}")
    spec = importlib.util.spec_from_file_location("benchmark_metrics", ROOT / "osintpwd/discovery/evaluate.py")
    metrics = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metrics)
    fixture_bytes = fixture_path.read_bytes()
    fixtures = json.loads(fixture_bytes.decode("utf-8-sig"))
    rows = []

    for case in fixtures["cases"]:
        query_log, page_log, fallback_calls = [], [], []
        log_lock = threading.Lock()

        class FixtureBackend:
            name = last_used = "offline-fixture"
            errors = []

            def is_available(self):
                return True

            def search(self, query, max_results=20):
                with log_lock:
                    query_log.append(query)
                for rule in case.get("rules", []):
                    exact = rule.get("exact")
                    if exact is not None and query != exact:
                        continue
                    if not all(term.lower() in query.lower() for term in rule.get("contains", [])):
                        continue
                    return [SearchResult(**hit) for hit in rule.get("hits", [])][:max_results]
                return []

        class FixtureClient:
            def __init__(self, *args, **kwargs):
                pass

            def get(self, url, **kwargs):
                page_log.append(url)
                html = case.get("pages", {}).get(url)
                return httpx.Response(200 if html is not None else 404,
                                      text=html or "", headers={"content-type": "text/html; charset=utf-8"},
                                      request=httpx.Request("GET", url))

            def close(self):
                pass

        def fixture_people(context):
            # NER quality is held fixed; these tests isolate extraction and flow.
            names = [n for n in case.get("ner_people", [])
                     if re.search(r"\b" + re.escape(n) + r"\b", context, re.I)]
            return names, set()

        original_related = related.discover_via_related

        def traced_related(*args, **kwargs):
            fallback_calls.append(True)
            return original_related(*args, **kwargs)

        params = {"name": case["name"], "hints": case.get("hints", {}),
                  "backend": FixtureBackend(), "username_scan": False,
                  "fetch_pages": 4, "related_search": "auto"}
        params = {key: val for key, val in params.items() if key in inspect.signature(pipeline.discover).parameters}
        start = time.perf_counter()
        error = None
        with patch.object(pipeline, "PoliteClient", FixtureClient), \
             patch.object(related, "PoliteClient", FixtureClient), \
             patch.object(related, "_people_in", fixture_people), \
             patch.object(related, "discover_via_related", traced_related), \
             patch.object(httpx.Client, "request", side_effect=AssertionError("Live HTTP is forbidden in offline benchmark")):
            try:
                data = asdict(pipeline.discover(**params))
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"
                data = {"candidates": [], "related_accounts": [], "related_people": [], "errors": [error]}
        row = metrics.score_result(case, data)
        row.update({"seconds": round(time.perf_counter() - start, 6),
                    "fallback_attempted": bool(fallback_calls),
                    "fallback_flag": data.get("related_searched"),
                    "query_calls": len(query_log), "page_calls": len(page_log)})
        checks = {}
        if case.get("expect"):
            checks["all_known_target_accounts"] = row["known_recall"] == 1
        if case.get("expect_related"):
            checks["all_known_related_accounts"] = row["related_recall"] == 1
        if "expect_fallback" in case:
            checks["fallback_trigger"] = row["fallback_attempted"] == case["expect_fallback"]
        if case.get("reject"):
            checks["no_false_target_promotion"] = row["false_target_promotions"] == 0
        if case.get("expect_no_people"):
            checks["no_unrelated_people"] = row["related_people"] == 0
        for expected in case.get("expect_attributes", []):
            key = metrics.account_key(expected)
            candidate = next((c for c in data["candidates"] if metrics.account_key(c) == key), {})
            for field in ("name_match", "related_person"):
                if field in expected:
                    checks["attribute_" + field] = candidate.get(field) == expected[field]
            if "matched_hint" in expected:
                checks["attribute_matched_hint"] = expected["matched_hint"] in candidate.get("matched_hints", [])
        if error:
            row["error"] = error
            checks["completed"] = False
        row["checks"] = checks
        row["passed"] = bool(checks) and all(checks.values())
        row["result"] = data
        row["queries"] = query_log
        row["page_urls"] = page_log
        rows.append(row)
        print(json.dumps({key: value for key, value in row.items() if key not in {"result", "queries", "page_urls"}}, ensure_ascii=False))

    summary = metrics.summarize(rows)
    summary.update({"scenarios_passed": sum(r["passed"] for r in rows),
                    "checks_passed": sum(sum(r["checks"].values()) for r in rows),
                    "checks_total": sum(len(r["checks"]) for r in rows),
                    "expected_fallback_cases": sum(c.get("expect_fallback") is True for c in fixtures["cases"]),
                    "fallback_cases_triggered": sum(r["fallback_attempted"] for c, r in zip(fixtures["cases"], rows) if c.get("expect_fallback") is True),
                    "query_calls": sum(r["query_calls"] for r in rows),
                    "page_calls": sum(r["page_calls"] for r in rows)})
    source_hashes = {}
    for name in ("pipeline.py", "candidates.py", "related.py", "enrich.py", "models.py"):
        source_hashes[name] = hashlib.sha256((source_root / "osintpwd/discovery" / name).read_bytes()).hexdigest()
    return {"schema_version": 1, "kind": "synthetic_offline", "source_root": str(source_root),
            "source_hashes": source_hashes, "fixture_sha256": hashlib.sha256(fixture_bytes).hexdigest(),
            "scope": fixtures["description"], "k": 10, "cases": rows, "summary": summary}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=ROOT)
    parser.add_argument("--fixtures", type=Path, default=ROOT / "examples/discovery_benchmark.json")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = benchmark(args.source_root, args.fixtures)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))
