"""An article extractor must not drop author evidence at the end of a README."""
import trafilatura

from osintpwd.discovery.enrich import extract_public_text
from osintpwd.discovery.pipeline import _info_contexts


def test_readme_author_after_usage_survives_article_extractor_truncation(monkeypatch):
    monkeypatch.setattr(trafilatura, 'extract', lambda *a, **k: 'Project description\nRequirements')
    html = '''<html><title>GitHub - user/ModelComparison</title><body>
        <nav>Unrelated navigation</nav><article class="markdown-body entry-content">
        <h1>Model comparison</h1><p>Project description</p><h2>Requirements</h2>
        <pre>pip install numpy</pre><h2>Usage</h2><p>Run the notebook</p>
        <h2>Contact</h2><p><strong>Author:</strong> Muhammed Zhumali</p>
        </article><aside>Unrelated sidebar</aside></body></html>'''
    text = extract_public_text(html)
    assert 'Author: Muhammed Zhumali' in text
    assert 'Unrelated navigation' not in text and 'Unrelated sidebar' not in text
    assert _info_contexts('Zhumali Muhammed', {'excerpt': text}, ['Zhumali Muhammed'])
