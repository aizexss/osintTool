"""Offline tests for the nomad face_recog output reader (synthetic clusters)."""

from __future__ import annotations

import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from osintpwd.ml.faces_nomad import (  # noqa: E402
    _crop_to_source_stem, read_identity,
)


def _make_output(root: str, layout: dict[str, list[str]]) -> str:
    """layout: cluster_name -> list of crop filenames."""
    out = os.path.join(root, "output")
    for cluster, crops in layout.items():
        cdir = os.path.join(out, "clusters", cluster)
        os.makedirs(cdir, exist_ok=True)
        for c in crops:
            open(os.path.join(cdir, c), "w").close()
    return out


def test_crop_stem_parsing():
    assert _crop_to_source_stem("abc123_face0.jpg") == "abc123"
    assert _crop_to_source_stem("instagram_asik_face2.png") == "instagram_asik"
    assert _crop_to_source_stem("noface.jpg") == "noface"


def test_read_and_confirm_same_person():
    with tempfile.TemporaryDirectory() as d:
        out = _make_output(d, {
            "person_0000": ["instagram_asik_face0.jpg",
                            "linkedin_aslan_face0.jpg",
                            "facebook_aslan_face1.jpg"],
            "person_0001": ["someone_else_face0.jpg"],
            "noise_unrecognized": ["blurry_face0.jpg"],
        })
        rep = read_identity(out)
        assert rep.available
        assert len(rep.clusters) == 2          # noise excluded
        same, mapping = rep.same_person(
            ["instagram_asik.jpg", "linkedin_aslan.jpg", "facebook_aslan.jpg"])
        assert same is True
        assert set(mapping.values()) == {"person_0000"}


def test_different_people_not_confirmed():
    with tempfile.TemporaryDirectory() as d:
        out = _make_output(d, {
            "person_0000": ["instagram_asik_face0.jpg"],
            "person_0001": ["linkedin_other_face0.jpg"],
        })
        rep = read_identity(out)
        same, _ = rep.same_person(["instagram_asik.jpg", "linkedin_other.jpg"])
        assert same is False


def test_missing_output_dir_graceful():
    rep = read_identity("/nonexistent/path/xyz")
    assert rep.available is False
    assert rep.clusters == {}


def _run_all():
    fns = [g for n, g in sorted(globals().items()) if n.startswith("test_")]
    passed = 0
    for fn in fns:
        try:
            fn()
        except AssertionError as e:
            print(f"FAIL {fn.__name__}: {e}")
        except Exception as e:  # noqa: BLE001
            print(f"ERROR {fn.__name__}: {e!r}")
        else:
            passed += 1
            print(f"ok   {fn.__name__}")
    print(f"\n{passed}/{len(fns)} passed")
    return passed == len(fns)


if __name__ == "__main__":
    raise SystemExit(0 if _run_all() else 1)
