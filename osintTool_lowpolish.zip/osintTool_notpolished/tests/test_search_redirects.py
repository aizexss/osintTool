"""Search wrappers must preserve valid profile destinations, without guessing."""
import base64
from urllib.parse import quote

import pytest

from osintpwd.discovery.search import _decode_bing_redirect, _unwrap_ddg


TARGET = 'https://www.linkedin.com/in/synthetic-example'


@pytest.mark.parametrize('prefix', ['/l/', '//duckduckgo.com/l/', 'https://duckduckgo.com/l/'])
def test_ddg_relative_and_absolute_wrappers(prefix):
    assert _unwrap_ddg(prefix + '?uddg=' + quote(TARGET, safe='')) == TARGET


def test_ddg_does_not_decode_destination_twice_or_unwrap_impostors():
    target = 'https://linkedin.com/in/name%2Dencoded'
    assert _unwrap_ddg('/l/?uddg=' + quote(target, safe='')) == target
    impostor = 'https://notduckduckgo.com/l/?uddg=' + quote(TARGET, safe='')
    assert _unwrap_ddg(impostor) == impostor


@pytest.mark.parametrize('target', [TARGET, 'a1' + base64.urlsafe_b64encode(TARGET.encode()).decode().rstrip('=')])
def test_bing_plain_and_base64_destinations(target):
    assert _decode_bing_redirect('https://www.bing.com/ck/a?u=' + quote(target, safe='')) == TARGET


@pytest.mark.parametrize('url', [
    'https://www.bing.com/ck/a?x=missing',
    'https://www.bing.com/ck/a?u=a1broken',
    'https://www.bing.com/ck/a?u=javascript%3Aalert(1)',
    'https://notbing.com/ck/a?u=' + quote(TARGET, safe=''),
])
def test_bing_invalid_wrappers_preserve_original(url):
    assert _decode_bing_redirect(url) == url
