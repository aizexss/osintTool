"""Behavioural tests for the offline password engine.

Run:  python -m pytest tests/ -q      (or)   python tests/test_core.py
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from osintpwd import Config, Profile, evaluate_password, generate_wordlist  # noqa: E402


def _profile() -> Profile:
    return Profile(
        first_name="Aslan", last_name="Serikov", nickname="asik",
        birth_year=1994, city="Almaty", employer="AcmeBank",
        pets=["Barsik"], interests=["Khabib Nurmagomedov", "UFC", "Real Madrid"],
    )


def test_base_tokens_split_multiword():
    p = Profile(interests=["Khabib Nurmagomedov"])
    toks = p.base_tokens()
    assert "khabibnurmagomedov" in toks
    assert "khabib" in toks
    assert "nurmagomedov" in toks


def test_wordlist_nonempty_and_bounded():
    words = generate_wordlist(_profile(), Config(max_words=5000))
    assert len(words) > 100
    assert len(words) <= 5000
    assert all(len(w) >= 4 for w in words)
    assert len(words) == len(set(words))  # de-duplicated


def test_reject_obvious_personal():
    p = _profile()
    for pw in ["khabibNurmagomedov777", "Almaty2020", "Barsik123", "Aslan1994"]:
        v = evaluate_password(pw, p)
        assert not v.allowed, f"should reject {pw}"
        assert v.matched_tokens


def test_reject_leet_variant():
    v = evaluate_password("Kh@bib_2018!", _profile())
    assert not v.allowed
    assert "khabib" in v.matched_tokens


def test_allow_unrelated_strong():
    for pw in ["correct-horse-battery-staple", "Tr0ub4dour&3", "9x!Qm#zL2vP"]:
        v = evaluate_password(pw, _profile())
        assert v.allowed, f"should allow {pw}"


def test_empty_profile_allows():
    v = evaluate_password("anything123", Profile())
    assert v.allowed


def _run_all():
    fns = [g for name, g in sorted(globals().items()) if name.startswith("test_")]
    passed = 0
    for fn in fns:
        try:
            fn()
        except AssertionError as e:
            print(f"FAIL {fn.__name__}: {e}")
        else:
            passed += 1
            print(f"ok   {fn.__name__}")
    print(f"\n{passed}/{len(fns)} passed")
    return passed == len(fns)


if __name__ == "__main__":
    raise SystemExit(0 if _run_all() else 1)
