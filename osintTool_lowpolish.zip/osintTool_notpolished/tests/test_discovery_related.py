"""Public-reader and one-hop regressions; fixtures never access the network."""
from __future__ import annotations

import httpx
import pytest

from osintpwd.discovery import related
from osintpwd.discovery.enrich import (
    MAX_DOCUMENT_BYTES, MAX_PUBLIC_TEXT, enrich_candidate, extract_cross_links,
    extract_public_text,
)
from osintpwd.discovery.models import Candidate, SearchResult


class Client:
    def __init__(self, pages=None):
        self.pages = pages or {}
        self.calls = []

    def get(self, url, **kwargs):
        self.calls.append(url)
        page = self.pages.get(url)
        if isinstance(page, httpx.Response):
            return page
        return httpx.Response(200 if page is not None else 404,
                              text=page or "", headers={"content-type": "text/html"})

    def close(self):
        pass


class Backend:
    name = "fixture"
    last_used = "fixture"

    def __init__(self, callback=lambda q: []):
        self.callback = callback
        self.calls = []

    def search(self, query, max_results=20):
        self.calls.append(query)
        return self.callback(query)[:max_results]


@pytest.fixture(autouse=True)
def deterministic_names(monkeypatch):
    monkeypatch.setattr(related, "_people_in", lambda ctx: (related._PERSON.findall(ctx), set()))


def test_reader_retains_metadata_and_article_comention():
    text = extract_public_text('''<html><head><title>Interview</title>
        <meta name="description" content="Local technology news"></head><body>
        <nav>Navigation junk</nav><article><p>Aslan Serikov met Dias Muratov.</p>
        <p>Their project is about clean energy.</p></article></body></html>''')
    assert "Interview" in text and "Local technology news" in text
    assert "Aslan Serikov met Dias Muratov." in text
    assert "Navigation junk" not in text


def test_reader_bounds_documents_and_reports_fetch_failure():
    large = httpx.Response(200, content=b"x" * (MAX_DOCUMENT_BYTES + 1))
    c = enrich_candidate(Candidate("web", "https://news.test/large"),
                         Client({"https://news.test/large": large}))
    assert not c.public_text and c.fetch_status == "error"
    assert c.fetch_error == "document_exceeds_2_MiB"
    c = enrich_candidate(Candidate("web", "https://news.test/missing"), Client())
    assert c.fetch_status == "error" and c.fetch_error == "HTTP 404"
    assert len(extract_public_text("<p>" + "Text " * 20_000 + "</p>")) <= MAX_PUBLIC_TEXT


def test_profile_links_exclude_posts_and_unsupported_hosts():
    html = '''<p>Aslan Serikov: <a href="https://instagram.com/aslan">Instagram</a></p>
       <a href="https://instagram.com/p/123">post</a>
       <a href="https://github.com/aslan/repository">repo</a>
       <a href="https://behance.net/aslan">unsupported</a>
       <a href="https://notinstagram.com/aslan">lookalike</a>
       <a href="javascript:alert(1)">bad</a>'''
    links = extract_cross_links(html, "https://news.test/interview")
    assert len(links) == 1
    assert links[0]["anchor"] == "Instagram"
    assert links[0]["context"] == "Aslan Serikov: Instagram"


def test_public_links_mark_site_boilerplate_without_losing_source_record():
    links = extract_cross_links('''<article><p><a href="https://github.com/asik">Aslan Serikov</a></p></article>
        <footer><a rel="me" href="https://github.com/newsroom">Newsroom</a></footer>
        <div role="navigation"><a href="https://instagram.com/news">News</a></div>''',
        "https://news.test/article")
    by_url = {link["url"]: link for link in links}
    assert not by_url["https://github.com/asik"]["boilerplate"]
    assert by_url["https://github.com/newsroom"]["boilerplate"]
    assert by_url["https://github.com/newsroom"]["rel_me"]
    assert by_url["https://instagram.com/news"]["boilerplate"]


def test_related_keeps_people_sharing_name_and_uses_kazakh_alias():
    people = related.nearby_people("Aslan Serikov", [
        ("https://news.test/1", "Aslan Serikov and Aslan Muratov met Dias Serikov."),
        ("https://news.test/2", "Аслан Сериков және Әли Қожахмет келді."),
    ], limit=5)
    assert {p["name"] for p in people} == {"Aslan Muratov", "Dias Serikov", "Әли Қожахмет"}
    assert all(p["evidence"][0]["source_url"] for p in people)


def test_article_body_finds_associate_missing_from_metadata():
    url = "https://news.test/article"
    def answer(q):
        if q == '"Aslan Serikov"':
            return [SearchResult(url, "Interview with Aslan Serikov", "Local news")]
        if q == 'site:instagram.com "Dias Muratov"':
            return [SearchResult("https://instagram.com/dias", "Dias Muratov", "")]
        return []
    result = related.discover_via_related("Aslan Serikov", Backend(answer),
        client=Client({url: "<article><p>Aslan Serikov met Dias Muratov.</p></article>"}),
        variants=["Aslan Serikov"], read_pages=1)
    assert result["people"] == ["Dias Muratov"]
    assert any(c.handle == "dias" and c.relation == "related_person" for c in result["candidates"])
    assert result["stats"]["related_source_pages_ok"] == 1


def test_joint_snippet_cannot_promote_associate_to_target():
    def answer(q):
        if '"Dias Muratov"' in q:
            return [SearchResult("https://instagram.com/dias", "Dias Muratov",
                                 "Working with Aslan Serikov")]
        return []
    result = related.discover_via_related("Aslan Serikov", Backend(answer), client=Client(),
        sources=[("https://news.test/team", "Aslan Serikov met Dias Muratov.")], read_pages=0)
    assert result["candidates"]
    assert all(not c.name_match and c.relation == "related_person" for c in result["candidates"])
    assert result["stats"]["via_related_found"] == 0


def test_same_platform_one_hop_retains_complete_source_chain():
    def answer(q):
        if q == 'site:instagram.com "Dias Muratov"':
            return [SearchResult("https://instagram.com/dias", "Dias Muratov", "")]
        return []
    source = "https://news.test/team"
    page = '<p>Co-founder <a href="/asik">Aslan Serikov</a></p>'
    backend = Backend(answer)
    result = related.discover_via_related("Aslan Serikov", backend,
        client=Client({"https://instagram.com/dias": page}),
        sources=[(source, "Aslan Serikov met Dias Muratov.")], read_pages=1)
    found = next(c for c in result["candidates"] if c.handle == "asik")
    assert found.name_match and found.relation == "via_related"
    assert found.related_person == "Dias Muratov"
    assert any(e["kind"] == "co_mention" and e["source_url"] == source for e in found.evidence)
    assert any(e["kind"] == "name_attached_profile_link"
               and e["source_url"] == "https://instagram.com/dias" for e in found.evidence)
    assert '"Aslan Serikov"' not in backend.calls  # supplied evidence reused
    assert result["stats"]["related_profile_pages_read"] == 1
    assert result["stats"]["related_profile_pages_ok"] == 1


def test_pagewide_target_mention_does_not_attach_unrelated_profile():
    def answer(q):
        if q == 'site:instagram.com "Dias Muratov"':
            return [SearchResult("https://instagram.com/dias", "Dias Muratov", "")]
        return []
    page = '<p>Aslan Serikov visited.</p><p><a href="/unrelated">My friend</a></p>'
    result = related.discover_via_related("Aslan Serikov", Backend(answer),
        client=Client({"https://instagram.com/dias": page}),
        sources=[("https://news.test/team", "Aslan Serikov met Dias Muratov.")], read_pages=1)
    assert not any(c.handle == "unrelated" for c in result["candidates"])


def test_group_anchor_does_not_establish_single_account_owner():
    assert not related._link_names_target({"anchor": "Aslan Serikov and Dias Muratov"},
                                          ["Aslan Serikov"])
    assert related._link_names_target({"anchor": "Aslan Serikov (@asik)"}, ["Aslan Serikov"])


def test_explicit_name_attached_mention_is_one_hop_lead():
    def answer(q):
        if q == 'site:instagram.com "Dias Muratov"':
            return [SearchResult("https://instagram.com/dias", "Dias Muratov", "")]
        return []
    result = related.discover_via_related("Aslan Serikov", Backend(answer),
        client=Client({"https://instagram.com/dias": "<p>Aslan Serikov: @asik</p>"}),
        sources=[("https://news.test/team", "Aslan Serikov met Dias Muratov.")], read_pages=1)
    found = next(c for c in result["candidates"] if c.handle == "asik")
    assert found.relation == "via_related"
    assert any(e["kind"] == "name_attached_mention" for e in found.evidence)


def test_pdf_reader_uses_public_text_and_returns_sanitized_error():
    candidate = enrich_candidate(Candidate("web", "https://news.test/broken.pdf"),
        Client({"https://news.test/broken.pdf": httpx.Response(
            200, content=b"%PDF-not a real PDF", headers={"content-type": "application/pdf"})}))
    assert candidate.fetch_status == "error"
    assert candidate.fetch_error == "PDF_text_unavailable"
