"""Publication recall stays independent of account success and requires evidence."""
import httpx
import pytest

from osintpwd.discovery import pipeline
from osintpwd.discovery.candidates import _handle_from_url
from osintpwd.discovery.enrich import enrich_candidate
from osintpwd.discovery.models import Candidate, SearchResult
from osintpwd.discovery.sources import build_info_queries, canonical_source_url

NAME = 'Zhumali Muhammed'
LI = 'https://linkedin.com/in/muhalek'
ARTICLE = 'https://news.example/report'
COMMENT = 'https://vk.com/wall-123_456?reply=78'


class Backend:
    name = 'fixture'
    errors = []

    def __init__(self, rows):
        self.rows, self.calls = rows, []

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        self.calls.append(query)
        return self.rows.get(query, [])


class Client:
    def __init__(self, *args, **kwargs):
        pass

    def close(self):
        pass


def run(monkeypatch, rows, bodies=None, links=None, budget=24):
    reads = []
    backend = Backend(rows)

    def enrich(page, client):
        reads.append(page.url)
        page.public_text = (bodies or {}).get(page.url, '')
        page.public_links = (links or {}).get(page.url, [])
        page.fetch_status = 'ok'
        return page

    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    monkeypatch.setattr(pipeline, 'enrich_candidate', enrich)
    result = pipeline.discover(NAME, backend=backend, username_scan=False,
        enrich_profiles=0, fetch_pages=4, related_search='off', query_budget=budget)
    return result, reads, backend.calls


def test_publication_queries_keep_capacity_after_linkedin_matches(monkeypatch):
    queries = build_info_queries(NAME, [NAME, 'Жумали Мухаммед'], {}, ('vk', 'linkedin'))
    vk_query = next(q for q in queries if 'site:vk.com/wall' in q)
    result, reads, calls = run(monkeypatch, {
        f'site:linkedin.com/in "{NAME}"': [SearchResult(LI, NAME)],
        vk_query: [SearchResult(COMMENT, 'Обсуждение проекта', 'Открытые комментарии')],
        f'"{NAME}"': [SearchResult(ARTICLE, 'Report', 'Project results')],
    }, {ARTICLE: 'Authors: Muhammed Zhumali.', COMMENT: 'Zhumali Muhammed: спасибо за статью!'})
    assert set(queries) <= set(calls)
    assert len(calls) <= 24
    assert result.stats['publication_queries'] == len(queries) + result.stats['publication_recovery_queries']
    assert any(c.url == LI and c.name_match for c in result.candidates)
    assert {w['url'] for w in result.web_info} == {ARTICLE, COMMENT}
    assert len(reads) <= 4
    assert next(w for w in result.web_info if w['url'] == COMMENT)['source_type'] == 'comment'


def test_dork_result_needs_body_or_profile_evidence_not_query_alone(monkeypatch):
    query = build_info_queries(NAME, [NAME], {}, ('vk',))[0]
    result, reads, _ = run(monkeypatch, {query: [SearchResult(ARTICLE, 'Report', 'Welcome')]},
                            {ARTICLE: 'Completely unrelated text'})
    assert reads == [ARTICLE]
    assert result.web_info == []


@pytest.mark.parametrize('boilerplate,expected', [(False, True), (True, False)])
def test_explicit_profile_link_is_a_connection_but_footer_is_not(monkeypatch, boilerplate, expected):
    result, _, _ = run(monkeypatch, {
        f'site:linkedin.com/in "{NAME}"': [SearchResult(LI, NAME)],
        f'"{NAME}"': [SearchResult(ARTICLE, 'Project update', 'Team report')],
    }, {ARTICLE: 'Contact: @muhalek'}, {ARTICLE: [{'url': LI, 'site': 'linkedin',
        'context': 'Contact: @muhalek', 'anchor': '@muhalek', 'boilerplate': boilerplate}]})
    assert bool(result.web_info) is expected
    if expected:
        assert result.web_info[0]['evidence_kind'] == 'profile_link'
        assert result.web_info[0]['profile_connection']['profile_url'] == LI


def test_vk_overlay_comments_are_documents_and_keep_comment_ids(monkeypatch):
    overlay = 'https://vk.ru/id123?w=wall-123_456&reply=78&utm_source=test'
    assert canonical_source_url(overlay) == COMMENT
    assert _handle_from_url('vk', overlay) is None
    result, _, _ = run(monkeypatch, {f'"{NAME}"': [
        SearchResult(overlay, NAME, 'Комментарий о проекте'),
        SearchResult(COMMENT, NAME, 'Вторая поисковая выдержка'),
        SearchResult(COMMENT.replace('78', '79'), NAME, 'Другой комментарий'),
        SearchResult('https://vk.com/', NAME, NAME),
        SearchResult('https://vk.com/login', NAME, NAME),
    ]})
    assert len(result.web_info) == 2
    first = next(w for w in result.web_info if w['url'] == COMMENT)
    assert len(first['search_evidence']) == 2
    assert not any(c.platform == 'vk' for c in result.candidates)


def test_generic_name_in_nickname_does_not_link_unrelated_article(monkeypatch):
    result, _, _ = run(monkeypatch, {f'"{NAME}"': [SearchResult(ARTICLE, 'Report', '@muhalek')]},
                           {ARTICLE: 'Written by @muhalek'})
    assert not result.web_info


def test_observed_profile_drives_bounded_backlink_read_with_evidence(monkeypatch):
    backlink = '"linkedin.com/in/muhalek" -site:linkedin.com'
    result, reads, calls = run(monkeypatch, {
        f'site:linkedin.com/in "{NAME}"': [SearchResult(LI, NAME)],
        f'"{NAME}"': [SearchResult('https://other.example/report', 'Unrelated report')],
        backlink: [SearchResult(ARTICLE, 'Project page', 'Team contact: muhalek'),
                   SearchResult('https://vk.com/', NAME)],
    }, {ARTICLE: 'Contact @muhalek'}, {ARTICLE: [{'url': LI, 'site': 'linkedin',
        'context': 'Project contact: @muhalek', 'boilerplate': False}]})
    assert backlink in calls and '"muhalek" ("Zhumali" OR "Muhammed")' in calls
    assert len(calls) <= 24 and len(reads) <= 4
    assert result.web_info[0]['url'] == ARTICLE
    assert result.web_info[0]['profile_connection']['profile_url'] == LI
    assert len(result.stats['search_pivots']) == 2
    report = result.stats['query_yield']
    assert report['retained_accounts'] == 1 and report['retained_publications'] == 1
    assert next(r for r in report['rows'] if r['query'] == backlink)['new_publications'] == 1
    assert not result.candidates[0].confirmed


def test_partial_name_is_not_an_anchor_and_a_backlink_query_is_not_proof(monkeypatch):
    from osintpwd.discovery.pivots import build_pivot_queries
    assert build_pivot_queries(NAME, [Candidate('linkedin', LI, handle='muhalek')]) == []
    result, reads, _ = run(monkeypatch, {
        f'site:linkedin.com/in "{NAME}"': [SearchResult(LI, NAME)],
        '"linkedin.com/in/muhalek" -site:linkedin.com': [
            SearchResult(ARTICLE, 'Welcome', 'Contact @muhalek'),
            SearchResult('https://other.example/unrelated', 'Robert Mihalek')],
    }, {ARTICLE: 'Unrelated text, no profile link'})
    assert ARTICLE in reads and not result.web_info
    assert 'https://other.example/unrelated' not in reads


@pytest.mark.parametrize('url', ['https://[broken', 'https://example.org:invalid/path', 'javascript:alert(1)'])
def test_invalid_source_urls_are_rejected(url):
    assert canonical_source_url(url) == ''


def test_reader_retains_comment_author_and_body_outside_article():
    html = '''<html><head><title>Project report</title></head><body><main><article>
      <p>The project covers engineering experiments and their results.</p></article>
      <div class="reply"><a class="author" href="/id42">Zhumali Muhammed</a>
      <div class="reply_text">Спасибо, участвовал в этом проекте.</div></div>
      <footer><div class="comment">Footer noise</div></footer></main></body></html>'''

    class PublicClient:
        def get(self, url, **kwargs):
            return httpx.Response(200, text=html, headers={'content-type': 'text/html'})

    page = enrich_candidate(Candidate('web', COMMENT), PublicClient())
    assert page.fetch_status == 'ok'
    assert 'Zhumali Muhammed Спасибо, участвовал в этом проекте.' in page.public_text
    assert 'Footer noise' not in page.public_text


def test_directory_cannot_join_names_of_different_people_into_target():
    from osintpwd.discovery.related import target_contexts
    assert not target_contexts(NAME, 'Muhammed Saeed · Cabin Crew · Phone · Email · Zhazira Zhumali')
    assert not target_contexts(NAME, 'Muhammed Saeed and Zhumali joined the meeting')
    assert target_contexts(NAME, 'Author: Muhammed Zhumali')
    assert target_contexts(NAME, 'Author: Muhammed A. Zhumali')
    assert target_contexts(NAME, 'Author: Muhammed Arman Zhumali')
    assert pipeline._is_junk_info('https://rocketreach.co/zhumali-muhammed-email_123')


def test_article_search_continues_after_irrelevant_nonempty_provider_and_generic_cache():
    from osintpwd.discovery.search import FallbackBackend
    from osintpwd.discovery.retrieval import SearchRun
    query = 'site:vk.com "Zhumali" "Muhammed"'
    noisy = Backend({query: [SearchResult('https://vk.com/topic/volvo', NAME),
                              SearchResult('https://news.example/unrelated', 'Other person')]})
    good = Backend({query: [SearchResult(COMMENT, 'Discussion', NAME + ': спасибо!')]})
    noisy.name, good.name = 'noisy', 'good'
    run = SearchRun(FallbackBackend([noisy, good]))
    assert run.search(query)[0].url.endswith('/topic/volvo')
    hits = run.search_publications(query, name=NAME)
    assert hits[0].url == COMMENT
    assert len(noisy.calls) == len(good.calls) == 1
    assert not any(h.url.endswith('/topic/volvo') for h in hits)
    assert run.records[-1]['mode'] == 'publications'


def test_recovery_and_body_reads_find_materials_after_accounts_already_matched(monkeypatch):
    from osintpwd.discovery.sources import build_info_recovery_queries
    from osintpwd.discovery.translit import name_variants
    from osintpwd.discovery.candidates import PLATFORMS
    recovery = build_info_recovery_queries(NAME, name_variants(NAME), PLATFORMS, need_web=True, need_vk=True)
    vk_query = next(q for q in recovery if q.startswith('site:vk.com '))
    articles = [f'https://news{i}.example/report' for i in range(3)]
    result, reads, calls = run(monkeypatch, {
        f'site:linkedin.com/in "{NAME}"': [SearchResult(LI, NAME)],
        recovery[0]: [SearchResult(url, 'Project report', 'Details in the article') for url in articles],
        vk_query: [SearchResult(COMMENT, 'Discussion', 'Replies')],
    }, {url: 'Written by Muhammed Zhumali.' for url in [*articles, COMMENT]}, budget=48)
    assert vk_query in calls
    assert {w['url'] for w in result.web_info} == {*articles, COMMENT}
    assert len(reads) == 4
    d = result.stats['publication_diagnostics']
    assert d['vk_queries'] >= 3 and d['read_pages'] == 4
    assert d['retained_sources'] == 4 and not d['read_errors']


def test_simple_vk_scopes_never_accept_navigation_as_a_document():
    from osintpwd.discovery.sources import is_publication_url
    assert is_publication_url(COMMENT)
    assert is_publication_url('https://vk.ru/topic-12_34')
    assert not is_publication_url('https://vk.com/topic/volvo')
    queries = build_info_queries(NAME, [NAME, 'Жумали Мухаммед'], {}, ('vk',))
    assert all(' OR ' not in q for q in queries)


def test_zero_width_script_shell_is_not_a_successfully_read_document():
    class PublicClient:
        def get(self, url, **kwargs):
            return httpx.Response(200, text='<html><body>\u200c\u200b<script>loadApp()</script></body></html>',
                                  headers={'content-type': 'text/html'})
    page = enrich_candidate(Candidate('web', COMMENT), PublicClient())
    assert page.fetch_status == 'empty'
    assert page.fetch_error == 'no_readable_text'
    assert not page.public_text.strip()
