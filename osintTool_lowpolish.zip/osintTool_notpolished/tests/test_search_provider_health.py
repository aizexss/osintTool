"""Offline DDG health, concurrency, and per-request retry-budget regressions."""

from concurrent.futures import ThreadPoolExecutor
import threading
import re

import httpx
import pytest

from osintpwd.discovery import http
from osintpwd.discovery.http import PoliteClient
from osintpwd.discovery.search import DuckDuckGoBackend, FallbackBackend


NAME = "Aslan Serikov"
PROFILE_URL = "https://linkedin.com/in/aslan-serikov"
RESULT_HTML = f'''<html><div class="result">
    <a class="result__a" href="{PROFILE_URL}">{NAME} | LinkedIn</a>
    <div class="result__snippet">Synthetic public profile.</div>
    </div></html>'''
EMPTY_HTML = '<html><div class="no-results">No results found.</div></html>'


class RecordingClient:
    def __init__(self, response):
        self.response = response
        self.calls = []
        self.lock = threading.Lock()

    def post(self, url, **kwargs):
        with self.lock:
            self.calls.append((url, kwargs))
        if callable(self.response):
            return self.response()
        return self.response


def unavailable_search(backend, query, *, require_error=False):
    """First failures are observable; disabled follow-ups may fail or be empty."""
    try:
        results = backend.search(query)
    except RuntimeError as exc:
        assert re.fullmatch(
            r"DuckDuckGo unavailable: (HTTP \d{3}|request failed|challenge page)", str(exc),
        )
        return []
    assert not require_error, "first provider failure must be visible to fallback"
    assert results == []
    return results


def test_concurrent_gated_first_queries_share_one_health_probe():
    entered = threading.Event()
    release = threading.Event()
    start = threading.Barrier(8)

    def gated_response():
        entered.set()
        assert release.wait(3), "probe was never released"
        return httpx.Response(202, text="Challenge required")

    client = RecordingClient(gated_response)
    backend = DuckDuckGoBackend(client)

    def search(index):
        start.wait(timeout=3)
        return unavailable_search(backend, f"{NAME} query {index}")

    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(search, index) for index in range(8)]
        try:
            assert entered.wait(3)
        finally:
            release.set()
        assert [future.result(timeout=3) for future in futures] == [[]] * 8
    assert len(client.calls) == 1
    assert backend.is_available() is False


@pytest.mark.parametrize("status", [202, 403, 429, 500, 503, 599])
def test_gated_or_failed_status_disables_instance(status):
    client = RecordingClient(httpx.Response(status, text="Unavailable"))
    backend = DuckDuckGoBackend(client)
    unavailable_search(backend, NAME, require_error=True)
    unavailable_search(backend, f"{NAME} LinkedIn")
    assert len(client.calls) == 1
    assert backend.is_available() is False


@pytest.mark.parametrize("html", [
    '<html><form id="challenge-form"><input name="token"></form></html>',
    '<html><form id="img-form"><input name="token"></form></html>',
    '<html><form action="//duckduckgo.com/anomaly.js"><input></form></html>',
    '<html><div class="anomaly-modal">Please select all squares containing a duck.</div></html>',
    '<html><form><input type="password" name="password"></form></html>',
])
def test_http_200_bot_challenge_disables_instance(html):
    client = RecordingClient(httpx.Response(200, text=html))
    backend = DuckDuckGoBackend(client)
    unavailable_search(backend, NAME, require_error=True)
    unavailable_search(backend, f"{NAME} LinkedIn")
    assert len(client.calls) == 1
    assert backend.is_available() is False


def test_genuine_empty_http_200_keeps_backend_available():
    client = RecordingClient(httpx.Response(200, text=EMPTY_HTML))
    backend = DuckDuckGoBackend(client)
    assert backend.search(NAME) == []
    assert backend.is_available() is True
    assert backend.search(f"{NAME} LinkedIn") == []
    assert len(client.calls) == 2
    assert backend.is_available() is True


def test_failed_transport_disables_instance():
    client = RecordingClient(None)
    backend = DuckDuckGoBackend(client)
    unavailable_search(backend, NAME, require_error=True)
    unavailable_search(backend, f"{NAME} LinkedIn")
    assert len(client.calls) == 1
    assert backend.is_available() is False


def test_raised_transport_timeout_disables_instance():
    def timed_out():
        raise httpx.ReadTimeout("synthetic timeout")

    client = RecordingClient(timed_out)
    backend = DuckDuckGoBackend(client)
    unavailable_search(backend, NAME, require_error=True)
    unavailable_search(backend, f"{NAME} LinkedIn")
    assert len(client.calls) == 1
    assert backend.is_available() is False


def test_disabling_one_instance_does_not_disable_new_instance():
    client = RecordingClient(httpx.Response(202))
    first = DuckDuckGoBackend(client)
    unavailable_search(first, NAME, require_error=True)
    second = DuckDuckGoBackend(client)
    assert second.is_available() is True
    client.response = httpx.Response(200, text=RESULT_HTML)
    assert second.search(NAME)[0].url == PROFILE_URL
    unavailable_search(first, NAME)
    assert len(client.calls) == 2


def test_healthy_requests_can_overlap_after_initial_probe():
    client = RecordingClient(httpx.Response(200, text=RESULT_HTML))
    backend = DuckDuckGoBackend(client)
    assert backend.search(NAME)[0].url == PROFILE_URL
    simultaneous_requests = threading.Barrier(2)

    def healthy_response():
        simultaneous_requests.wait(timeout=3)
        return httpx.Response(200, text=RESULT_HTML)

    client.response = healthy_response
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(backend.search, f"{NAME} {index}") for index in range(2)]
        assert [future.result(timeout=4)[0].url for future in futures] == [PROFILE_URL] * 2
    assert len(client.calls) == 3


def test_healthy_ddg_preserves_fallback_query_and_provider_metadata():
    class EmptyBackend:
        name = "fixture_empty"

        def is_available(self):
            return True

        def search(self, query, max_results=20):
            return []

    client = RecordingClient(httpx.Response(200, text=RESULT_HTML))
    backend = FallbackBackend([EmptyBackend(), DuckDuckGoBackend(client)])
    query = f'site:linkedin.com/in "{NAME}"'
    hits = backend.search(query)
    assert len(hits) == 1
    assert (hits[0].url, hits[0].title, hits[0].snippet) == (
        PROFILE_URL, f"{NAME} | LinkedIn", "Synthetic public profile.",
    )
    assert (hits[0].provider, hits[0].query) == ("duckduckgo", query)
    assert backend.last_used == "duckduckgo"
    assert [(row["provider"], row["status"], row["results"]) for row in backend.attempts] == [
        ("fixture_empty", "empty", 0), ("duckduckgo", "ok", 1),
    ]


def test_ddg_sets_short_timeout_and_single_attempt_budget():
    client = RecordingClient(httpx.Response(200, text=EMPTY_HTML))
    assert DuckDuckGoBackend(client).search(NAME) == []
    url, options = client.calls[0]
    assert url == DuckDuckGoBackend.URL
    assert options["data"] == {"q": NAME}
    assert options["timeout"] == 6.0
    assert options["request_attempts"] == 1


def test_fallback_records_sanitized_ddg_failure_and_skips_disabled_provider():
    private_body = "synthetic-secret-token-do-not-expose"
    client = RecordingClient(httpx.Response(202, text=private_body))
    backend = FallbackBackend([DuckDuckGoBackend(client)])
    assert backend.search(NAME) == []
    assert len(backend.attempts) == 1
    failure = backend.attempts[0]
    assert (failure["provider"], failure["status"], failure["results"]) == (
        "duckduckgo", "error", 0,
    )
    assert "HTTP 202" in failure["detail"]
    assert any("HTTP 202" in note for note in backend.errors)
    assert private_body not in repr((backend.attempts, backend.errors))
    assert backend.search(f"{NAME} LinkedIn") == []
    assert len(backend.attempts) == len(client.calls) == 1


@pytest.fixture
def mock_client(monkeypatch):
    monkeypatch.setattr(http.time, "sleep", lambda seconds: None)
    clients = []

    def make(failure):
        requests = []

        def handler(request):
            requests.append(request)
            if failure == "timeout":
                raise httpx.ReadTimeout("synthetic timeout", request=request)
            return httpx.Response(500, text="synthetic upstream failure")

        client = PoliteClient(min_interval=0)
        client._client.close()
        client._client = httpx.Client(transport=httpx.MockTransport(handler))
        clients.append(client)
        return client, requests

    yield make
    for client in clients:
        client.close()


@pytest.mark.parametrize("failure", ["500", "timeout"])
def test_default_http_client_keeps_three_attempts(mock_client, failure):
    client, requests = mock_client(failure)
    response = client.get("https://provider.example/search")
    assert len(requests) == 3
    assert client.max_retries == 3
    if failure == "timeout":
        assert response is None
    else:
        assert response.status_code == 500


@pytest.mark.parametrize("failure", ["500", "timeout"])
def test_ddg_failure_uses_only_one_actual_transport_attempt(mock_client, failure):
    client, requests = mock_client(failure)
    backend = DuckDuckGoBackend(client)
    unavailable_search(backend, NAME, require_error=True)
    unavailable_search(backend, f"{NAME} LinkedIn")
    assert len(requests) == 1
    assert backend.is_available() is False
    assert client.max_retries == 3
    assert requests[0].extensions["timeout"]["read"] == 6.0


@pytest.mark.parametrize("failure", ["500", "timeout"])
def test_attempt_override_is_consumed_and_does_not_change_later_defaults(mock_client, failure):
    client, requests = mock_client(failure)
    client.post("https://provider.example/search", request_attempts=1)
    assert len(requests) == 1
    client.get("https://provider.example/search")
    assert len(requests) == 4
    assert client.max_retries == 3
