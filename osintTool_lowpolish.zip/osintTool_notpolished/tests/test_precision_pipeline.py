"""Precision guards through the complete retrieval pipeline, without network."""
from osintpwd.discovery import pipeline
from osintpwd.discovery.models import SearchResult


class Client:
    def __init__(self, *args, **kwargs):
        pass

    def close(self):
        pass


class Backend:
    name = 'fixture'
    errors = []

    def __init__(self, hits):
        self.hits = hits
        self.calls = []
        self.targets = []

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        self.calls.append(query)
        return self.hits.get(query, [])[:max_results]

    def search_profiles(self, query, max_results=20, *, platform, name):
        self.targets.append(name)
        return self.search(query, max_results)


def test_shared_short_surname_does_not_stop_token_quoted_recovery(monkeypatch):
    name = 'Elena Kim'
    query = 'site:linkedin.com/in "Elena" "Kim"'
    backend = Backend({
        'site:linkedin.com/in "Elena Kim"': [
            SearchResult('https://linkedin.com/in/elena-kim', 'Oleg Kim')],
        query: [SearchResult('https://linkedin.com/in/elena-real', 'Kim Elena')],
    })
    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    monkeypatch.setattr(pipeline, 'name_variants', lambda name: [name])
    result = pipeline.discover(name, backend=backend, platforms=('linkedin',),
        username_scan=False, fetch_pages=0, enrich_profiles=0, related_search='off')
    assert [c.url for c in result.candidates if c.name_match] == ['https://linkedin.com/in/elena-real']
    assert result.candidates[0].name_match
    weak = next(c for c in result.candidates if c.url.endswith('/elena-kim'))
    assert not weak.name_match and 'owner_name_conflict' in weak.match_reasons
    assert query in backend.calls
    assert f'{name} LinkedIn' not in backend.calls
    assert result.stats['owner_conflict_suggestions'] == 1


def test_query_alias_is_never_treated_as_a_different_requested_owner(monkeypatch):
    name = 'Dina Kim'
    backend = Backend({'site:linkedin.com/in "Dina Kim"': [
        SearchResult('https://linkedin.com/in/dina-kim', name)],
        'site:linkedin.com/in "Dena Kim"': [
        SearchResult('https://linkedin.com/in/dina-kim', name)]})
    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    monkeypatch.setattr(pipeline, 'name_variants', lambda name: [name, 'Dena Kim'])
    result = pipeline.discover(name, backend=backend, platforms=('linkedin',),
        username_scan=False, fetch_pages=0, enrich_profiles=0, related_search='off')
    assert [c.url for c in result.candidates] == ['https://linkedin.com/in/dina-kim']
    assert result.candidates[0].name_match
    assert set(backend.targets) == {name}
    assert not result.excluded_profile_urls


def test_read_budget_skips_weak_profiles_and_unrelated_source_pages(monkeypatch):
    name = 'Elena Kim'
    article = 'https://news.example/interview'
    backend = Backend({f'"{name}"': [
        SearchResult('https://linkedin.com/in/generic-member', 'Elena'),
        SearchResult('https://news.example/oleg', 'Oleg Kim interview'),
        SearchResult(article, 'Interview', 'Elena Kim described the project.'),
    ]})
    reads = []

    def enrich(candidate, client):
        reads.append(candidate.url)
        return candidate

    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    monkeypatch.setattr(pipeline, 'name_variants', lambda name: [name])
    monkeypatch.setattr(pipeline, 'enrich_candidate', enrich)
    result = pipeline.discover(name, backend=backend, platforms=('linkedin',),
        username_scan=False, fetch_pages=4, enrich_profiles=2, related_search='off')
    assert reads == [article, 'https://news.example/oleg']  # bounded body probe, not a display pass
    assert len(result.candidates) == 1 and not result.candidates[0].name_match
    assert [source['url'] for source in result.web_info] == [article]


def test_bounded_search_prioritizes_linkedin_and_skips_redundant_aliases(monkeypatch):
    name = 'Elena Kim'
    first = 'site:linkedin.com/in "Elena Kim"'
    backend = Backend({first: [SearchResult('https://linkedin.com/in/elena-kim', name)]})
    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    monkeypatch.setattr(pipeline, 'name_variants', lambda name: [name, 'Елена Ким'])
    result = pipeline.discover(name, backend=backend, platforms=('linkedin', 'github'),
        username_scan=False, fetch_pages=0, enrich_profiles=0, related_search='off', query_budget=8)
    assert backend.calls[0] == first
    assert sum('linkedin' in query.replace('-site:linkedin.com', '') for query in backend.calls) == 1
    assert len(backend.calls) <= 8
    assert any(c.platform == 'linkedin' and c.name_match for c in result.candidates)


def test_bounded_search_stops_before_query_limit_and_reports_partial_run(monkeypatch):
    backend = Backend({})
    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    result = pipeline.discover('Elena Kim', backend=backend, username_scan=False,
        fetch_pages=0, enrich_profiles=0, related_search='auto', query_budget=3)
    assert len(backend.calls) == 3
    assert result.stats['search_budget_exhausted']
    assert result.stats['budget_skipped_queries'] > 0
