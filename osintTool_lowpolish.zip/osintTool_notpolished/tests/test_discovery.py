"""Offline tests for the discovery classifier (no network)."""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from osintpwd.discovery.candidates import (  # noqa: E402
    _handle_from_url, build_extra_query, build_queries, classify, is_name_match,
)
from osintpwd.discovery.models import Candidate, SearchResult  # noqa: E402
from osintpwd.discovery.identity import annotate_identity  # noqa: E402
from osintpwd.discovery.pipeline import discover  # noqa: E402
from osintpwd.discovery.search import _decode_bing_redirect  # noqa: E402
from osintpwd.discovery.related import nearby_people  # noqa: E402
from osintpwd.discovery.translit import name_variants  # noqa: E402
from osintpwd.discovery.pipeline import _is_junk_info  # noqa: E402
from osintpwd.discovery.enrich import extract_cross_links  # noqa: E402


def test_is_junk_info_filters_aggregators_but_allows_publication_evidence():
    assert _is_junk_info("https://socialcatfish.com/directory/ai/15/")
    assert not _is_junk_info("https://www.tiktok.com/@x/video/76472365765")
    assert _is_junk_info("https://vk.com/")
    assert _is_junk_info("https://spokeo.com/whatever")
    assert not _is_junk_info("https://tengrinews.kz/news/article")
    assert not _is_junk_info("https://kbtu.edu.kz/alumni")


def test_extract_cross_links_relme_only_no_same_site_noise():
    html = ('<a rel="me" href="https://t.me/aizexssdev">tg</a>'
            '<a href="https://docs.github.com/help">docs</a>'      # same-site noise
            '<a href="https://vk.com/someone">vk</a>')
    links = extract_cross_links(html, "https://github.com/aizexss")
    sites = [l["site"] for l in links]
    assert "telegram" in sites and "vk" in sites      # real cross-links kept
    assert "github" not in sites                       # same-site chrome dropped
    assert links[0]["rel_me"] is True                  # rel=me surfaced first


def test_name_variants_both_j_spellings():
    v = name_variants("Айбар Ибрагимов")
    assert "Aibar Ibragimov" in v and "Aybar Ibragimov" in v   # ай -> ai and ay


def test_name_variants_latin_to_cyrillic():
    # a Cyrillic-native person typed in Latin must also be searched in Cyrillic
    v = name_variants("Muhammed Zhumali")
    assert v[0] == "Muhammed Zhumali"
    assert "Мухаммед Жумали" in v          # zh->ж, digraph handling, capitals
    assert "Аслан Сериков" in name_variants("Aslan Serikov")


def test_handle_rejects_lookalike_domains():
    assert _handle_from_url("facebook", "https://myfacebook.com/zuck") is None
    assert _handle_from_url("instagram", "https://notinstagram.com/leomessi") is None
    # a genuine subdomain is still accepted
    assert _handle_from_url("facebook", "https://m.facebook.com/zuck") == "zuck"


def test_score_matches_whole_words_not_substrings():
    hit = SearchResult("https://linkedin.com/in/someone", "climbing club", "")
    cands = classify("Li Wang", {}, "linkedin", [hit])
    # "Li" must NOT match inside "climbing"; without any evidence it is noise.
    assert cands == []


def test_nearby_people_finds_comentions_not_target_or_orgs():
    sources = [
        ("https://a.kz/1", "Aslan Serikov and Dias Muratov launched a startup in Almaty."),
        ("https://b.kz/2", "Interview with Aslan Serikov; his colleague Dias Muratov commented."),
        ("https://c.kz/3", "Aslan Serikov studied at KBTU University."),
    ]
    names = [p["name"] for p in nearby_people("Aslan Serikov", sources, 3)]
    assert "Dias Muratov" in names          # co-mentioned person is found
    assert "Aslan Serikov" not in names      # the target itself is excluded
    assert not any("University" in n for n in names)   # orgs excluded


def test_nearby_people_ignores_people_outside_target_context():
    # A person in a paragraph WITHOUT the target must not be picked up.
    sources = [("https://x.kz/1",
                "Aslan Serikov opened a cafe.\nSeparately, Bruce Wayne bought a tower.")]
    names = [p["name"] for p in nearby_people("Aslan Serikov", sources, 5)]
    assert "Bruce Wayne" not in names


def test_linkedin_handle():
    assert _handle_from_url("linkedin", "https://www.linkedin.com/in/satyanadella/") == "satyanadella"
    assert _handle_from_url("linkedin", "https://linkedin.com/feed/") is None
    assert _handle_from_url("linkedin", "https://linkedin.com/company/microsoft") is None


def test_instagram_handle():
    assert _handle_from_url("instagram", "https://instagram.com/leomessi") == "leomessi"
    assert _handle_from_url("instagram", "https://instagram.com/p/Cabc123/") is None
    assert _handle_from_url("instagram", "https://instagram.com/explore/") is None


def test_facebook_rejects_ui_pages():
    assert _handle_from_url("facebook", "https://www.facebook.com/FIND-FRIENDS/") is None
    assert _handle_from_url("facebook", "https://www.facebook.com/watch") is None
    assert _handle_from_url("facebook", "https://www.facebook.com/zuck") == "zuck"
    assert _handle_from_url("facebook", "https://facebook.com/profile.php?id=1000123") == "1000123"


def test_wrong_host_rejected():
    assert _handle_from_url("linkedin", "https://instagram.com/in/foo") is None


def test_build_queries_shape():
    qs = build_queries("Aslan Serikov", {"city": "Almaty"})
    platforms = {p for p, _ in qs}
    assert {"linkedin", "instagram", "facebook", "vk"} <= platforms
    assert all('"Aslan Serikov"' in q for _, q in qs)
    # every platform keeps a name-only query (recall) AND gets a hint query
    assert any('"Almaty"' not in q for _, q in qs)   # name-only present
    assert any('"Almaty"' in q for _, q in qs)        # hint query present


def test_build_queries_name_only_when_no_hints():
    qs = build_queries("Aslan Serikov", {})
    assert len(qs) == 4 and all('"Aslan Serikov"' in q for _, q in qs)


def test_new_platform_handles():
    assert _handle_from_url("vk", "https://vk.com/durov") == "durov"
    assert _handle_from_url("vk", "https://vk.com/wall12_345") is None
    assert _handle_from_url("x", "https://x.com/jack") == "jack"
    assert _handle_from_url("x", "https://twitter.com/jack") == "jack"
    assert _handle_from_url("x", "https://x.com/home") is None
    assert _handle_from_url("github", "https://github.com/torvalds") == "torvalds"
    assert _handle_from_url("github", "https://github.com/features") is None
    assert _handle_from_url("telegram", "https://t.me/durov") == "durov"
    assert _handle_from_url("telegram", "https://t.me/s/durov") is None
    assert _handle_from_url("tiktok", "https://www.tiktok.com/@charlidamelio") == "charlidamelio"
    assert _handle_from_url("youtube", "https://www.youtube.com/@mkbhd") == "mkbhd"
    assert _handle_from_url("youtube", "https://www.youtube.com/watch") is None
    # look-alike host still rejected
    assert _handle_from_url("github", "https://notgithub.com/torvalds") is None


def test_classify_scores_and_dedups():
    results = [
        SearchResult("https://linkedin.com/in/aslanserikov",
                     "Aslan Serikov - AcmeBank", "Almaty"),
        SearchResult("https://linkedin.com/in/aslanserikov",  # dup
                     "Aslan Serikov", ""),
        SearchResult("https://linkedin.com/feed/", "noise", ""),
    ]
    cands = classify("Aslan Serikov", {"city": "Almaty", "employer": "AcmeBank"},
                     "linkedin", results)
    assert len(cands) == 1
    assert cands[0].handle == "aslanserikov"
    assert cands[0].score > 0.5


def test_facebook_people_url_extracts_id():
    # facebook.com/people/<Name>/<id>/ is a real profile shape — must NOT be dropped
    assert _handle_from_url(
        "facebook",
        "https://www.facebook.com/people/Aslan-Serikov/100012345678/") == "100012345678"
    assert _handle_from_url(
        "facebook", "https://facebook.com/people/Jane-Doe/61550000000000") == "61550000000000"


def test_is_name_match_by_text_and_by_handle():
    # full name present in the title -> match, even if the handle is a nickname
    hit = SearchResult("https://instagram.com/asik_almaty", "Aslan Serikov (@asik)", "")
    assert is_name_match("Aslan Serikov", hit, "asik_almaty")
    # handle IS the name -> match, even with an empty title/snippet
    hit2 = SearchResult("https://instagram.com/aslan.serikov", "", "")
    assert is_name_match("Aslan Serikov", hit2, "aslan.serikov")
    # unrelated namesake fragments -> not a match
    hit3 = SearchResult("https://instagram.com/climber", "Climbing club Almaty", "")
    assert not is_name_match("Li Wang", hit3, "climber")
    # surname-first / separator-joined handles still count as by-name
    blank = SearchResult("https://t.me/serikovaslan", "", "")
    assert is_name_match("Aslan Serikov", blank, "serikovaslan")
    assert is_name_match("Aslan Serikov", blank, "aslan_serikov_kz")
    # a lone first name is NOT a full by-name match (avoids flagging every "Aslan")
    assert not is_name_match("Aslan Serikov", SearchResult("x", "", ""), "aslan")


def test_classify_flags_and_floors_name_match():
    hits = [SearchResult("https://instagram.com/aslan.serikov",
                         "Aslan Serikov", "Almaty")]
    cands = classify("Aslan Serikov", {}, "instagram", hits)
    assert cands[0].name_match is True
    assert cands[0].score >= 0.5          # a by-name hit always ranks as a real find


def test_classify_ranks_name_matches_first():
    hits = [
        SearchResult("https://instagram.com/randomuser", "Some Page", ""),       # no name
        SearchResult("https://instagram.com/aslan.serikov", "Aslan Serikov", ""),  # by name
    ]
    cands = classify("Aslan Serikov", {}, "instagram", hits)
    assert cands[0].name_match and cands[0].handle == "aslan.serikov"


def test_build_extra_query_sweeps_all_networks():
    q = build_extra_query("Aslan Serikov")
    assert '"Aslan Serikov"' in q
    for frag in ("site:x.com", "site:github.com", "site:t.me",
                 "site:tiktok.com", "site:youtube.com"):
        assert frag in q


def test_identity_groups_same_handle_across_networks():
    cands = [
        Candidate(platform="instagram", url="https://instagram.com/satyanadella",
                  handle="satyanadella", name_match=True, score=0.95),
        Candidate(platform="x", url="https://x.com/satyanadella",
                  handle="satyanadella", name_match=True, score=0.85),
        Candidate(platform="linkedin", url="https://linkedin.com/in/satya-nadella-b1566318",
                  handle="satya-nadella-b1566318", name_match=True, score=0.67),
    ]
    n = annotate_identity("Satya Nadella", {}, cands)
    # the two real @satyanadella accounts are ONE identity; the hashed LinkedIn
    # slug is a different account -> a second identity. Never merged blindly.
    assert n == 2
    ig = next(c for c in cands if c.platform == "instagram")
    x = next(c for c in cands if c.platform == "x")
    li = next(c for c in cands if c.platform == "linkedin")
    assert ig.group == x.group and ig.group != li.group


def test_identity_records_matched_hints_and_ranks_group_one():
    cands = [
        Candidate(platform="linkedin", url="u1", handle="aslan-serikov-111",
                  title="Aslan Serikov - Google", snippet="Almaty", name_match=True,
                  score=0.6),
        Candidate(platform="linkedin", url="u2", handle="aslan-serikov-222",
                  title="Aslan Serikov - AcmeBank Almaty", snippet="", name_match=True,
                  score=0.6),
    ]
    annotate_identity("Aslan Serikov", {"city": "Almaty", "employer": "AcmeBank"}, cands)
    hinted = next(c for c in cands if c.handle == "aslan-serikov-222")
    assert set(hinted.matched_hints) == {"Almaty", "AcmeBank"}
    assert hinted.group == 1          # most hint evidence -> ranked identity #1


def test_discover_is_concurrency_safe_with_mock_backend():
    # A backend called concurrently must still yield the same candidates.
    class FB:
        name = "fb"; last_used = "fb"; errors = []
        def is_available(self): return True
        def search(self, query, max_results=20):
            q = query.lower()
            if "site:instagram.com" in q and "aslan serikov" in q:
                return [SearchResult("https://instagram.com/aslan.serikov",
                                     "Aslan Serikov", "Almaty")]
            if "site:github.com" in q or "site:x.com" in q:
                return [SearchResult("https://github.com/aslanserikov",
                                     "Aslan Serikov", "")]
            return []
    r = discover("Aslan Serikov", backend=FB(), username_scan=False)
    handles = {c.handle for c in r.candidates}
    assert "aslan.serikov" in handles and "aslanserikov" in handles
    assert all(c.name_match for c in r.candidates)


def test_bing_redirect_decode():
    import base64
    real = "https://www.linkedin.com/in/satyanadella"
    enc = "a1" + base64.urlsafe_b64encode(real.encode()).decode().rstrip("=")
    wrapped = f"https://www.bing.com/ck/a?!&&p=xyz&u={enc}&ntb=1"
    assert _decode_bing_redirect(wrapped) == real
    # non-bing url passes through untouched
    assert _decode_bing_redirect(real) == real


def _run_all():
    fns = [g for n, g in sorted(globals().items()) if n.startswith("test_")]
    passed = 0
    for fn in fns:
        try:
            fn()
        except AssertionError as e:
            print(f"FAIL {fn.__name__}: {e}")
        else:
            passed += 1
            print(f"ok   {fn.__name__}")
    print(f"\n{passed}/{len(fns)} passed")
    return passed == len(fns)


if __name__ == "__main__":
    raise SystemExit(0 if _run_all() else 1)
