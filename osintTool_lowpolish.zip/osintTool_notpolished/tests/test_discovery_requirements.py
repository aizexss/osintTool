"""The two user requirements under the real shared query budget."""
import pytest

from osintpwd.discovery import pipeline, related
from osintpwd.discovery.config import discovery_query_budget
from osintpwd.discovery.models import Candidate, SearchResult
from osintpwd.discovery.retrieval import SearchRun


class Client:
    def __init__(self, *args, **kwargs):
        pass

    def close(self):
        pass


class Backend:
    name = 'fixture'
    errors = []

    def __init__(self, named=False):
        self.calls = []
        self.named = named

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        self.calls.append(query)
        if query == '"Elena Kim"':
            return [SearchResult('https://news.test/team', 'Elena Kim met Dias Muratov and Anna Petrova.'),
                    SearchResult('https://instagram.com/elena', 'Elena Kim' if self.named else 'Elena Ivanova')]
        if query == '"Dias Muratov"':
            return [SearchResult('https://instagram.com/dias', 'Dias Muratov')]
        if query == '"Anna Petrova"':
            return [SearchResult('https://github.com/anna', 'Anna Petrova')]
        return []


@pytest.mark.parametrize('late_conflict', [False, True])
def test_partial_matches_stay_and_both_people_receive_real_queries(monkeypatch, late_conflict):
    def enrich(c, client):
        c.fetch_status = 'ok'
        if c.handle == 'elena':
            c.title = 'Elena Ivanova'
        if c.handle == 'dias':
            c.public_links = [{'site': 'github', 'url': 'https://github.com/target-public',
                               'anchor': 'Elena Kim', 'context': 'Elena Kim: profile'}]
        return c

    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    monkeypatch.setattr(pipeline, 'enrich_candidate', enrich)
    monkeypatch.setattr(related, 'enrich_candidate', enrich)
    monkeypatch.setattr(related, '_people_in', lambda ctx: (related._PERSON.findall(ctx), set()))
    monkeypatch.setattr(pipeline, 'name_variants', lambda name: [name])
    backend = Backend(late_conflict)
    result = pipeline.discover('Elena Kim', backend=backend, query_budget=24,
                               username_scan=False, fetch_pages=0, enrich_profiles=1)
    weak = next(c for c in result.candidates if c.handle == 'elena')
    assert not weak.name_match and 'owner_name_conflict' in weak.match_reasons
    assert result.related_searched and result.stats['related_query_reserve'] == 6
    assert '"Dias Muratov"' in backend.calls and '"Anna Petrova"' in backend.calls
    assert 0 < result.stats['related_queries'] <= 6
    assert len(backend.calls) == result.stats['search_queries'] <= 24
    assert {'Dias Muratov', 'Anna Petrova'} == set(result.related_people)
    target = next(c for c in result.candidates if c.handle == 'target-public')
    assert target.relation == 'via_related' and target.name_match
    assert any(e['source_url'] == 'https://news.test/team' for e in target.evidence)
    assert any(e['source_url'] == 'https://instagram.com/dias' for e in target.evidence)
    assert result.stats['related_search_status'] == 'partial_budget'


def test_skipped_related_queries_are_not_reported_as_executed(monkeypatch):
    monkeypatch.setattr(related, '_people_in', lambda ctx: (related._PERSON.findall(ctx), set()))
    result = related.discover_via_related('Elena Kim', SearchRun(Backend(), max_queries=0),
        client=Client(), read_pages=0,
        sources=[('https://news.test/team', 'Elena Kim met Dias Muratov.')])
    assert result['stats']['related_queries'] == result['stats']['related_account_queries'] == 0
    assert result['stats']['related_search_status'] == 'budget_exhausted'


def test_dashboard_budget_is_configurable_and_validated(monkeypatch):
    monkeypatch.delenv('OSINT_QUERY_BUDGET', raising=False)
    assert discovery_query_budget() == 48
    monkeypatch.setenv('OSINT_QUERY_BUDGET', '96')
    assert discovery_query_budget() == 96
    monkeypatch.setenv('OSINT_QUERY_BUDGET', 'invalid')
    assert discovery_query_budget() == 48


def test_feed_context_does_not_attach_every_other_author_but_partial_handles_survive():
    page = Candidate('linkedin', 'https://linkedin.com/in/elena', title='Elena Kim', name_match=True)
    context = 'Elena Kim liked this. News from Dias Muratov. Elena Kim liked this.'
    page.public_links = [
        {'site': 'linkedin', 'url': 'https://linkedin.com/in/dias', 'anchor': 'Dias Muratov', 'context': context},
        {'site': 'github', 'url': 'https://github.com/elena7', 'anchor': 'GitHub', 'context': context},
    ]
    found = pipeline._linked_candidates('Elena Kim', ['Elena Kim'], {}, page, owner=page)
    assert [c.handle for c in found] == ['elena7']
    assert not found[0].name_match
