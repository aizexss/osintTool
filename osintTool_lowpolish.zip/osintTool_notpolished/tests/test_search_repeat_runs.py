"""Repeated runs must preserve useful evidence without hammering blocked APIs."""
from concurrent.futures import ThreadPoolExecutor
import threading

import httpx

from osintpwd.discovery import search
from osintpwd.discovery.candidates import classify
from osintpwd.discovery.models import SearchResult
from osintpwd.discovery.provider_state import ProviderState, response_error
from osintpwd.discovery.retrieval import SearchRun
from osintpwd.discovery.search import FallbackBackend, SearxngBackend, SerperBackend


class Client:
    def __init__(self, response):
        self.response = response
        self.calls = 0

    def get(self, *args, **kwargs):
        if args[0].endswith('/config'):
            return httpx.Response(200, json={'engines': [
                {'name': name, 'enabled': True, 'categories': ['general', 'web'], 'paging': True}
                for name in ('bing', 'google', 'google cse')]})
        self.calls += 1
        return self.response() if callable(self.response) else self.response

    post = get


def searx(client):
    return FallbackBackend([SearxngBackend('http://local.fixture', client)])


def success():
    return httpx.Response(200, json={'results': [
        {'url': 'https://github.com/dana-kim', 'title': 'Dana Kim', 'engine': 'bing'}]})


def test_cooldown_survives_new_runs_and_expires(monkeypatch):
    now = [1000.0]
    monkeypatch.setattr(search.time, 'monotonic', lambda: now[0])
    client = Client(httpx.Response(429, headers={'Retry-After': '120'}))
    first = SearchRun(searx(client))
    assert first.search('one') == []
    second = SearchRun(searx(client))
    assert second.search('two') == []
    assert client.calls == 1
    stats = second.stats()
    assert stats['provider_requests'] == 0
    assert stats['provider_skipped_requests'] == 1
    assert stats['search_degraded']
    assert stats['provider_statuses'][0]['retry_after_seconds'] == 120
    now[0] += 121
    client.response = success()
    assert searx(client).search('two')
    assert client.calls == 2


def test_credits_are_probed_once_across_runs_and_key_change_has_own_scope():
    client = Client(httpx.Response(400, json={'message': 'Not enough credits'}))
    for i in range(3):
        assert FallbackBackend([SerperBackend('fixture-key', client)]).search(str(i)) == []
    assert client.calls == 1
    FallbackBackend([SerperBackend('changed-key', client)]).search('one')
    assert client.calls == 2


def test_stale_success_survives_outage_with_age_and_original_provenance(monkeypatch):
    now = [1000.0]
    monkeypatch.setattr(search.time, 'monotonic', lambda: now[0])
    client = Client(success())
    original = searx(client).search('Dana Kim')[0]
    now[0] += search._RESPONSE_CACHE_TTL + 1
    client.response = httpx.Response(503)
    run = SearchRun(searx(client))
    hit = run.search('Dana Kim')[0]
    assert hit.stale and hit.cached
    assert hit.cache_age_seconds == search._RESPONSE_CACHE_TTL + 1
    assert hit.provider == 'searxng:bing'
    assert hit.retrieved_at == original.retrieved_at
    evidence = classify('Dana Kim', {}, 'github', [hit])[0].evidence[0]
    assert evidence['stale'] and evidence['retrieved_at']
    assert run.stats()['provider_errors'] == 1
    assert run.stats()['stale_results'] == 1
    assert searx(client).search('Dana Kim')[0].stale
    assert client.calls == 2
    now[0] += search._RESPONSE_CACHE_STALE_TTL
    assert searx(client).search('Dana Kim') == []


def test_genuine_empty_does_not_resurrect_stale_success(monkeypatch):
    now = [1000.0]
    monkeypatch.setattr(search.time, 'monotonic', lambda: now[0])
    client = Client(success())
    assert searx(client).search('Dana Kim')
    now[0] += search._RESPONSE_CACHE_TTL + 1
    client.response = httpx.Response(200, json={'results': []})
    assert searx(client).search('Dana Kim') == []
    client.response = httpx.Response(503)
    assert searx(client).search('Dana Kim') == []


def test_empty_with_engine_failures_is_degraded_but_does_not_disable_healthy_engine():
    client = Client(httpx.Response(200, json={'results': [],
        'unresponsive_engines': [['google', 'CAPTCHA'], ['google cse', 'Too many requests']]}))
    run = SearchRun(searx(client))
    assert run.search('one') == []
    assert run.stats()['provider_errors'] == 1
    assert run.stats()['search_degraded']
    assert 'google cse' in ' '.join(run.errors)
    client.response = success()
    assert run.search('two')


def test_concurrent_runs_share_one_successful_query():
    client = Client(success())
    gate = threading.Barrier(6)
    def run(_):
        gate.wait(3)
        return searx(client).search('Dana Kim')[0]
    with ThreadPoolExecutor(max_workers=6) as pool:
        hits = list(pool.map(run, range(6)))
    assert client.calls == 1
    assert sum(h.cached for h in hits) == 5


def test_provider_pacing_reserves_spacing(monkeypatch):
    now, sleeps = [100.0], []
    monkeypatch.setattr(search.time, 'monotonic', lambda: now[0])
    def sleep(delay):
        sleeps.append(delay)
        now[0] += delay
    monkeypatch.setattr(search.time, 'sleep', sleep)
    state = ProviderState()
    for _ in range(3):
        with state.lock:
            state.wait(1.5)
    assert sleeps == [1.5, 1.5]


def test_different_queries_can_overlap_but_share_two_provider_slots():
    gate = threading.Barrier(2)
    def respond():
        gate.wait(timeout=3)
        return success()
    client = Client(respond)
    with ThreadPoolExecutor(max_workers=4) as pool:
        hits = list(pool.map(lambda i: searx(client).search(str(i)), range(4)))
    assert len(hits) == client.calls == 4


def test_retry_after_date_and_invalid_values(monkeypatch):
    monkeypatch.setattr(search.time, 'time', lambda: 0)
    assert response_error('fixture', httpx.Response(429, headers={
        'Retry-After': 'Thu, 01 Jan 1970 00:02:00 GMT'})).cooldown == 120
    for value in ('nan', 'inf', 'bad', '-1'):
        assert response_error('fixture', httpx.Response(429, headers={'Retry-After': value})).cooldown == 60
