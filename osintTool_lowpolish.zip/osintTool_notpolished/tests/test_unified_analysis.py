from osintpwd.discovery import pipeline, maigret_scan
from osintpwd.discovery.models import SearchResult


class Backend:
    name = 'fixture'
    errors = []

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        return [SearchResult('https://github.com/dana', title='Dana Kim')]


class Client:
    def __init__(self, *args, **kwargs):
        pass

    def close(self):
        pass


def test_automatic_username_checks_keep_uncertainty_and_flag_other_owners(monkeypatch):
    calls = []
    def scan(handle):
        calls.append(handle)
        return {'provider': 'maigret', 'cached': False, 'partial': True,
                'checks': [{'site': 'threads', 'status': 'unavailable'}],
                'accounts': [
                    {'site': 'steam', 'url': 'https://steamcommunity.com/id/dana', 'title': 'dana',
                     'evidence': [{'provider': 'maigret', 'source_url': 'https://steamcommunity.com/id/dana'}]},
                    {'site': 'facebook', 'url': 'https://facebook.com/dana', 'title': 'Oleg Kim'},
                ]}
    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    monkeypatch.setattr(maigret_scan, 'scan_username', scan)
    result = pipeline.discover('Dana Kim', backend=Backend(), platforms=('github',),
                               username_provider='maigret', fetch_pages=0,
                               enrich_profiles=0, related_search='off')
    assert calls == ['dana']
    assert result.stats['search_degraded']
    assert len(result.stats['username_scans']) == 1
    other = next(c for c in result.candidates if c.url == 'https://facebook.com/dana')
    assert not other.name_match and 'owner_name_conflict' in other.match_reasons
    weak = next(c for c in result.candidates if c.platform == 'steam')
    assert not weak.confirmed and not weak.name_match and weak.relation == 'username'
    assert weak.evidence[0]['provider'] == 'maigret'


def test_username_owner_conflict_flags_previously_retrieved_url(monkeypatch):
    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    monkeypatch.setattr(maigret_scan, 'scan_username', lambda h: {
        'provider': 'maigret', 'cached': False, 'partial': False, 'checks': [],
        'accounts': [{'site': 'github', 'url': 'https://github.com/dana', 'title': 'Oleg Kim'}]})
    result = pipeline.discover('Dana Kim', backend=Backend(), platforms=('github',),
                               username_provider='maigret', fetch_pages=0,
                               enrich_profiles=0, related_search='off')
    assert len(result.candidates) == 1 and not result.candidates[0].name_match
    assert result.candidates[0].title == 'Oleg Kim'
    assert 'owner_name_conflict' in result.candidates[0].match_reasons
    assert result.excluded_profile_urls == []
