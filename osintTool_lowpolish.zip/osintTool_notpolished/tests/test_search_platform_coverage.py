"""Account namespaces, cross-links, bounded coverage, and owner precision."""
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from osintpwd.discovery.candidates import (
    PLATFORMS, _handle_from_url, canonical_profile_url, classify, build_extra_queries)
from osintpwd.discovery.config import DiscoveryConfig
from osintpwd.discovery.enrich import extract_cross_links
from osintpwd.discovery.models import SearchResult, DiscoveryResult
from osintpwd.discovery.pipeline import discover
from osintpwd.discovery.search import build_backends
from osintpwd.web.app import app


@pytest.mark.parametrize('platform,url,canonical', [
    ('threads', 'https://www.threads.net/@Dana.Kim?hl=en', 'https://threads.com/@dana.kim'),
    ('steam', 'https://steamcommunity.com/id/Dana_Kim/', 'https://steamcommunity.com/id/dana_kim'),
    ('steam', 'https://steamcommunity.com/profiles/76561198000000000', 'https://steamcommunity.com/profiles/76561198000000000'),
    ('reddit', 'https://old.reddit.com/u/Dana_Kim/', 'https://reddit.com/user/dana_kim'),
    ('bluesky', 'https://bsky.app/profile/dana-kim.bsky.social', 'https://bsky.app/profile/dana-kim.bsky.social'),
    ('twitch', 'https://www.twitch.tv/dana_kim', 'https://twitch.tv/dana_kim'),
    ('gitlab', 'https://gitlab.com/dana-kim', 'https://gitlab.com/dana-kim'),
    ('medium', 'https://medium.com/@DanaKim', 'https://medium.com/@danakim'),
    ('soundcloud', 'https://soundcloud.com/dana-kim', 'https://soundcloud.com/dana-kim'),
    ('ok', 'https://ok.ru/profile/1234567890', 'https://ok.ru/profile/1234567890'),
    ('ok', 'https://ok.ru/dana.kim', 'https://ok.ru/dana.kim'),
    ('tiktok', 'https://www.tiktok.com/@dana.kim', 'https://tiktok.com/@dana.kim'),
])
def test_profile_classification_and_extracted_links_share_registry(platform, url, canonical):
    assert canonical_profile_url(platform, url) == canonical
    title = 'Steam Community :: Dana Kim' if platform == 'steam' else 'Dana Kim'
    candidate = classify('Dana Kim', {}, platform, [SearchResult(url, title)])[0]
    assert candidate.name_match and not candidate.confirmed
    assert candidate.url == canonical
    links = extract_cross_links(f'<p>Dana Kim <a rel="me" href="{url}">Dana Kim</a></p>',
                                'https://example.org/bio')
    assert links[0]['site'] == platform and links[0]['url'] == canonical


@pytest.mark.parametrize('platform,path', [
    ('threads', 'https://threads.com/@danakim/post/123'),
    ('threads', 'https://threads.com/search'),
    ('steam', 'https://steamcommunity.com/id/danakim/games'),
    ('steam', 'https://steamcommunity.com/groups/danakim'),
    ('steam', 'https://steamcommunity.com/profiles/1234'),
    ('reddit', 'https://reddit.com/r/danakim'),
    ('reddit', 'https://reddit.com/user/danakim/comments/123'),
    ('bluesky', 'https://bsky.app/profile/dana.bsky.social/post/123'),
    ('twitch', 'https://twitch.tv/directory'),
    ('gitlab', 'https://gitlab.com/danakim/project'),
    ('gitlab', 'https://gitlab.com/users'),
    ('medium', 'https://medium.com/@danakim/an-article'),
    ('soundcloud', 'https://soundcloud.com/danakim/track'),
    ('ok', 'https://ok.ru/group/123'),
    ('threads', 'https://threads.com.evil.example/@danakim'),
])
def test_nonprofiles_and_lookalikes_are_not_accounts(platform, path):
    assert _handle_from_url(platform, path) is None


def test_steam_numeric_vanity_and_numeric_identity_remain_distinct():
    assert canonical_profile_url('steam', 'https://steamcommunity.com/id/76561198000000000') != \
        canonical_profile_url('steam', 'https://steamcommunity.com/profiles/76561198000000000')


@pytest.mark.parametrize('label', ['fan page', 'Fans', 'parody', 'Unofficial', 'фан-клуб'])
def test_fan_label_overrides_full_name_handle_but_remains_reviewable(label):
    candidates = classify('Dana Kim', {}, 'threads', [SearchResult(
        'https://threads.net/@danakim', 'Dana Kim — ' + label)])
    assert len(candidates) == 1
    assert not candidates[0].name_match
    assert candidates[0].score <= .35
    assert 'fan_or_parody' in candidates[0].match_reasons


def test_keyless_excludes_keys_even_when_priority_override_includes_them():
    config = DiscoveryConfig(serper_key='synthetic', google_cse_key='synthetic', google_cse_cx='id',
        searxng_url='http://localhost:8080', search_mode='keyless',
        backend_order=('serper', 'google_cse', 'searxng', 'duckduckgo'))
    assert [b.name for b in build_backends(config, object())] == ['searxng', 'duckduckgo']


def test_focused_search_routes_keyless_mode_and_validates_platforms():
    with patch('osintpwd.discovery.discover', return_value=DiscoveryResult(query_name='Dana Kim')) as call:
        response = TestClient(app).post('/api/discover', json={
            'name': 'Dana Kim', 'search_mode': 'keyless', 'platforms': ['steam', 'threads']})
    assert response.status_code == 200
    assert call.call_args.kwargs['search_mode'] == 'keyless'
    assert call.call_args.kwargs['platforms'] == ('steam', 'threads')
    for body in ({'search_mode': 'invalid'}, {'platforms': ['evil']}, {'platforms': []}):
        assert TestClient(app).post('/api/discover', json={'name': 'Dana Kim', **body}).status_code == 422


def test_new_networks_are_covered_within_web_budget():
    class Backend:
        name = 'fixture'
        def is_available(self):
            return True
        def search(self, query, max_results=20):
            return []
    result = discover('Dana Kim', backend=Backend(), query_budget=24,
                      username_scan=False, fetch_pages=0, enrich_profiles=0, related_search='off')
    queries = ' '.join(row['query'] for row in result.stats['queries'])
    for domain in ('threads.com', 'threads.net', 'steamcommunity.com', 'tiktok.com',
                   'reddit.com', 'bsky.app', 'twitch.tv', 'gitlab.com', 'medium.com', 'soundcloud.com', 'ok.ru'):
        assert 'site:' + domain in queries
    assert result.stats['search_queries'] <= 24
    assert len(PLATFORMS) == 18
    assert len(build_extra_queries('Dana Kim', ('steam',))) == 1


def test_named_broad_result_with_unrelated_handle_beats_name_only_dork_hit():
    broad = classify('Dana Kim', {}, 'github', [SearchResult(
        'https://github.com/quiet-engineer', 'Dana Kim', query='"Dana Kim"')])[0]
    exact_handle = classify('Dana Kim', {}, 'instagram', [SearchResult(
        'https://instagram.com/danakim', 'Dana Kim', 'Official verified 100k followers',
        query='site:instagram.com "Dana Kim"')])[0]
    assert broad.score > exact_handle.score
    assert not broad.confirmed and not exact_handle.confirmed


def test_fixed_discovery_benchmark_including_related_regressions():
    import importlib.util
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    spec = importlib.util.spec_from_file_location('search_benchmark', root / 'tests/discovery_benchmark.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    report = module.benchmark(root, root / 'examples/discovery_benchmark.json')
    assert report['summary']['scenarios_passed'] == report['summary']['cases']
    assert report['summary']['false_target_promotions'] == 0
