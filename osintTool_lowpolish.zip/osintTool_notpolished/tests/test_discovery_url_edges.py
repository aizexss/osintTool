"""Profile URL boundaries, using synthetic accounts and no network calls."""

from urllib.parse import quote

import pytest

from osintpwd.discovery.candidates import _handle_from_url, classify
from osintpwd.discovery.models import SearchResult


@pytest.mark.parametrize("url", [
    "https://l.facebook.com/l.php?u=https%3A%2F%2Fexample.org%2Fperson",
    "https://facebook.com/login.php?next=%2Fperson",
    "https://facebook.com/sharer.php?u=https%3A%2F%2Fexample.org",
    "https://facebook.com/permalink.php?story_fbid=456&id=123",
    "https://facebook.com/share?href=https%3A%2F%2Fexample.org",
    "https://facebook.com/dialog",
    "https://facebook.com/profile.php?id=not-a-numeric-id",
    "https://facebook.com/profile.php?id=123&id=456",
    "https://facebook.com/people/Example-Person/not-a-numeric-id",
    "https://facebook.com/people/Example-Person/123/photos/456",
])
def test_facebook_nonprofiles_never_invent_an_account(url):
    assert classify("Example Person", {}, "facebook", [SearchResult(url, "Example Person")]) == []


def test_facebook_numeric_profile_aliases_keep_id_and_evidence():
    urls = [
        "https://m.facebook.com/people/Example-Person/12345/",
        "https://facebook.com/profile.php?id=12345&ref=search",
        "https://fb.com/12345",
    ]
    found = classify("Example Person", {}, "facebook", [SearchResult(url, "Example Person") for url in urls])
    assert len(found) == 1
    assert found[0].url == "https://facebook.com/profile.php?id=12345"
    assert len(found[0].evidence) == 3
    assert _handle_from_url("facebook", "https://facebook.com/example.person") == "example.person"


@pytest.mark.parametrize("host", ["docs.github.com", "support.github.com", "gist.github.com"])
def test_github_service_hosts_never_become_main_site_accounts(host):
    url = f"https://{host}/exampleperson"
    assert classify("Example Person", {}, "github", [SearchResult(url, "Example Person")]) == []


def test_github_main_and_www_aliases_still_merge():
    urls = ["https://www.github.com/ExamplePerson", "https://github.com/exampleperson"]
    found = classify("Example Person", {}, "github", [SearchResult(url, "Example Person") for url in urls])
    assert len(found) == 1
    assert found[0].url == "https://github.com/exampleperson"


@pytest.mark.parametrize("handle", ["аслансериков", "қазақша", "人", "किरण", "anna·maria"])
def test_youtube_international_handles_survive_raw_and_encoded_urls(handle):
    raw = f"https://youtube.com/@{handle}"
    encoded = f"https://www.youtube.com/@{quote(handle, safe='')}?feature=shared"
    found = classify("Example Person", {}, "youtube", [SearchResult(raw, "Example Person"),
                                                        SearchResult(encoded, "Example Person")])
    assert len(found) == 1
    assert found[0].handle == handle
    assert found[0].url == "https://youtube.com/@" + quote(handle.casefold(), safe="-._")
    assert len(found[0].evidence) == 2


@pytest.mark.parametrize("path", [
    "/watch?v=synthetic", "/shorts/synthetic", "/@exampleperson/video/synthetic",
    "/@example%2Fperson", "/@example%20person", "/@example%00person",
    "/@example%F0%9F%98%80person", "/@.exampleperson", "/@exampleperson-",
])
def test_youtube_nonprofiles_and_invalid_handle_characters_stay_rejected(path):
    assert _handle_from_url("youtube", "https://youtube.com" + path) is None


def test_youtube_channel_id_case_and_namespaces_stay_distinct():
    urls = ["https://youtube.com/channel/UCExamplePerson", "https://youtube.com/user/exampleperson",
            "https://youtube.com/@exampleperson"]
    found = classify("Example Person", {}, "youtube", [SearchResult(url, "Example Person") for url in urls])
    assert len(found) == 3
    assert {c.url for c in found} == set(urls)


def test_telegram_username_domain_alias_merges_without_losing_sources():
    urls = ["https://ExamplePerson.t.me/", "https://t.me/exampleperson?profile",
            "https://telegram.me/exampleperson"]
    found = classify("Example Person", {}, "telegram", [SearchResult(url, "Example Person") for url in urls])
    assert len(found) == 1
    assert found[0].url == "https://t.me/exampleperson"
    assert len(found[0].evidence) == 3


@pytest.mark.parametrize("url", [
    "https://exampleperson.t.me/123", "https://exampleperson.t.me/otherperson",
    "https://share.t.me/", "https://login.t.me/", "https://contact.t.me/",
    "https://nested.exampleperson.t.me/", "https://a.t.me/", "https://t.me/oauth?startapp=synthetic",
])
def test_telegram_post_service_and_invalid_domain_aliases_stay_rejected(url):
    assert _handle_from_url("telegram", url) is None
