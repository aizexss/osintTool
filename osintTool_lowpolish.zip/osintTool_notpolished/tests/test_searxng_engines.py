import httpx
import pytest

from osintpwd.discovery import searxng_engines as engines
from osintpwd.discovery.provider_state import ProviderError
from osintpwd.discovery.search import SearxngBackend


def test_learns_actual_sources_and_recovers_with_bounded_fanout(monkeypatch):
    now = [1000]
    monkeypatch.setattr(engines.time, 'monotonic', lambda: now[0])
    pool = engines.EnginePool()
    assert pool.choose() == []
    pool.observe({'results': [{'engines': ['custom search', 'brave']}],
                  'unresponsive_engines': [['google', 'CAPTCHA'], ['yahoo', 'timeout']]}, [])
    assert set(pool.choose()) == {'custom search', 'brave'}
    now[0] += 61
    assert 'yahoo' in pool.choose()
    assert 'google' not in pool.choose()
    now[0] += 3600
    assert pool.choose() == []  # discover changed instance settings again


def test_instance_defaults_are_preserved_when_no_engine_was_observed():
    pool = engines.EnginePool()
    for _ in range(3):
        assert pool.choose() == []
        pool.observe({'results': []}, [])


def test_all_known_engines_cooling_never_fall_back_to_defaults():
    pool = engines.EnginePool()
    pool.choose()
    pool.observe({'results': [], 'unresponsive_engines': [['custom', 'CAPTCHA']]}, [])
    assert pool.choose() is None
    pool.observe({'results': [{'engines': ['previously empty']} ]}, [])
    assert pool.choose() == ['previously empty']


def test_explicit_engines_always_win(monkeypatch):
    monkeypatch.setenv('OSINT_SEARXNG_ENGINES', 'google cse,yahoo')
    class Client:
        def get(self, url, **kwargs):
            assert kwargs['params']['engines'] == 'google cse,yahoo'
            return httpx.Response(200, json={'results': []})
    backend = SearxngBackend('http://example.org', Client())
    backend._engine_pool.choose = lambda: pytest.fail('Explicit selection must bypass adaptation')
    assert backend.search('Dana Kim') == []
