from osintpwd.discovery.metrics import query_yield_report
from osintpwd.discovery.models import Candidate


def test_yield_deduplicates_aliases_counts_only_evidenced_hits_and_keeps_outages():
    url = 'https://linkedin.com/in/example'
    page = 'https://news.example/article'
    report = query_yield_report([
        {'sequence': 2, 'query': 'second', 'status': 'ok', 'results': 3,
         'result_urls': [url, page, 'https://vk.com/']},
        {'sequence': 1, 'query': 'first', 'status': 'ok', 'results': 1,
         'result_urls': ['https://www.linkedin.com/in/example/?trk=search']},
        {'sequence': 3, 'query': 'blocked', 'status': 'unavailable', 'results': 0},
    ], [Candidate('linkedin', url, name_match=True, evidence=[
        {'kind': 'search_result', 'query': 'first'}, {'kind': 'search_result', 'query': 'second'}])],
        [{'url': page, 'search_evidence': [{'query': 'second'}]}])
    assert report['retained_accounts'] == 1 and report['retained_publications'] == 1
    assert report['repeated_results'] == 1 and report['unique_urls'] == 3
    assert report['unavailable_queries'] == 1 and report['productive_queries'] == 2
    first, second, blocked = report['rows']
    assert first['new_accounts'] == 1 and second['new_accounts'] == 0
    assert second['new_publications'] == 1 and second['not_displayed_urls'] == 1
    assert blocked['status'] == 'unavailable'
