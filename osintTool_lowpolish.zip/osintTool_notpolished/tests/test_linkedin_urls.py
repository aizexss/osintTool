"""LinkedIn URL recall regressions using synthetic profiles only."""

import pytest

from osintpwd.discovery.candidates import (
    _handle_from_url, canonical_candidate_key, canonical_profile_url, classify,
)
from osintpwd.discovery.enrich import extract_cross_links
from osintpwd.discovery.models import SearchResult


@pytest.mark.parametrize("url", [
    "https://www.linkedin.com/in/synthetic-example/",
    "https://kz.linkedin.com/in/Synthetic-Example?trk=search",
    "https://uk.linkedin.com/in/synthetic-example/en",
    "https://linkedin.com/%69n/synthetic%2Dexample",
])
def test_localized_and_encoded_in_urls_remain_profiles(url):
    found = classify("Synthetic Example", {}, "linkedin", [SearchResult(url)])
    assert len(found) == 1
    assert found[0].url == "https://linkedin.com/in/synthetic-example"
    assert found[0].name_match


def test_unicode_in_slug_remains_encoded_in_canonical_url():
    url = "https://kz.linkedin.com/in/%D0%BF%D1%80%D0%B8%D0%BC%D0%B5%D1%80"
    assert _handle_from_url("linkedin", url) == "пример"
    assert canonical_profile_url("linkedin", url) == url.replace("kz.", "")


def test_legacy_profile_preserves_namespace_id_and_original_evidence():
    original = "https://kz.linkedin.com/pub/Synthetic-Example/1A/2B/3C/?trk=search#about"
    found = classify("Synthetic Example", {}, "linkedin", [
        SearchResult(original, "Synthetic Example | LinkedIn"),
        SearchResult("https://www.linkedin.com/pub/synthetic-example/1a/2b/3c"),
    ])
    assert len(found) == 1
    candidate = found[0]
    assert candidate.url == "https://linkedin.com/pub/synthetic-example/1a/2b/3c"
    assert candidate.handle.casefold() == "synthetic-example/1a/2b/3c"
    assert candidate.name_match
    assert candidate.evidence[0]["source_url"] == original
    assert len(candidate.evidence) == 2


def test_legacy_profiles_with_shared_name_keep_distinct_ids_and_namespaces():
    urls = [
        "https://linkedin.com/pub/synthetic-example/1a/2b/3c",
        "https://linkedin.com/pub/synthetic-example/1a/2b/4d",
        "https://linkedin.com/in/synthetic-example",
    ]
    found = classify("Synthetic Example", {}, "linkedin", [
        SearchResult(url, "Synthetic Example") for url in urls
    ])
    assert {c.url for c in found} == set(urls)
    assert len({canonical_candidate_key(c) for c in found}) == 3


@pytest.mark.parametrize("path", [
    "/pub/dir/Synthetic/Example", "/pub/dir/1/2/3", "/pub/synthetic-example",
    "/pub/synthetic-example/1a/2b", "/pub/synthetic-example/1a/2b/3c/jobs",
    "/pub/synthetic-example/not/a/profile", "/company/synthetic-example",
    "/jobs/view/123", "/feed/", "/posts/synthetic-example",
])
def test_linkedin_directories_and_nonprofiles_are_excluded(path):
    assert _handle_from_url("linkedin", "https://linkedin.com" + path) is None


@pytest.mark.parametrize("source_host,target_host", [
    ("www.linkedin.com", "kz.linkedin.com"),
    ("kz.linkedin.com", "www.linkedin.com"),
    ("kz.linkedin.com", "uk.linkedin.com"),
])
def test_same_site_regional_profiles_are_retained_only_when_requested(source_host, target_host):
    source = f"https://{source_host}/in/source-person"
    html = f'<p>Synthetic Example <a href="https://{target_host}/in/synthetic-example">LinkedIn</a></p>'
    assert extract_cross_links(html, source) == []
    links = extract_cross_links(html, source, include_same_site=True)
    assert len(links) == 1
    assert links[0]["url"] == "https://linkedin.com/in/synthetic-example"
    assert links[0]["same_site"]
    assert links[0]["source_url"] == source
    assert links[0]["context"] == "Synthetic Example LinkedIn"


def test_regional_self_links_and_site_chrome_stay_excluded():
    html = '''<a href="https://uk.linkedin.com/in/source-person?trk=nav">Me</a>
        <a href="https://kz.linkedin.com/pub/dir/Synthetic/Example">Directory</a>
        <a href="https://kz.linkedin.com/company/example">Company</a>
        <a href="https://kz.linkedin.com/pub/synthetic-example/1a/2b/3c">Profile</a>'''
    links = extract_cross_links(html, "https://www.linkedin.com/in/source-person?trk=search",
                                include_same_site=True)
    assert [link["url"] for link in links] == [
        "https://linkedin.com/pub/synthetic-example/1a/2b/3c"
    ]
    assert extract_cross_links('<a href="https://docs.github.com/help">Docs</a>',
                               "https://github.com/source-person", include_same_site=True) == []
