"""Public document HTTP boundaries, with mocked DNS and HTTP transports only."""
from __future__ import annotations

import gzip
import socket

import httpx
import pytest

from osintpwd.discovery.enrich import enrich_candidate
from osintpwd.discovery.http import PoliteClient
from osintpwd.discovery.models import Candidate


class TrackingStream(httpx.SyncByteStream):
    def __init__(self, chunks):
        self.chunks = chunks
        self.consumed = 0
        self.closed = False

    def __iter__(self):
        for chunk in self.chunks:
            self.consumed += 1
            yield chunk

    def close(self):
        self.closed = True


@pytest.fixture(autouse=True)
def public_dns(monkeypatch):
    def resolve(host, port, **kwargs):
        address = "10.0.0.7" if host == "private.test" else "93.184.216.34"
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (address, port))]
    monkeypatch.setattr(socket, "getaddrinfo", resolve)


def make_client(handler):
    client = PoliteClient(min_interval=0, max_retries=1)
    client._client.close()
    # Deliberately retain the normal client's follow_redirects=True default:
    # get_public must override it to inspect each new destination first.
    client._client = httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)
    return client


@pytest.mark.parametrize("url", [
    "file:///etc/passwd", "https://localhost/page", "http://127.0.0.1/",
    "http://[::1]/", "http://169.254.169.254/", "http://private.test/page",
    "https://user:example-secret@example.test/page", "https://localhost./",
    "https://example.test/\x00control",
])
def test_rejects_unsafe_public_sources_before_http(url):
    calls = []
    with make_client(lambda request: calls.append(request) or httpx.Response(200)) as client:
        response = client.get_public(url)
    assert response.status_code >= 400
    assert response.extensions["read_error"].startswith("public_")
    assert not calls
    assert "example-secret" not in response.extensions["read_error"]


def test_rejects_mixed_public_private_dns_answers(monkeypatch):
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **kw: [
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443)),
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("192.168.1.1", 443)),
    ])
    calls = []
    with make_client(lambda request: calls.append(request) or httpx.Response(200)) as client:
        response = client.get_public("https://mixed.test/")
    assert response.extensions["read_error"] == "public_target_not_global"
    assert not calls


def test_redirect_cannot_reach_private_destination():
    calls = []
    def handler(request):
        calls.append(str(request.url))
        return httpx.Response(302, headers={"location": "https://private.test/metadata"})
    with make_client(handler) as client:
        response = client.get_public("https://example.test/article")
    assert response.extensions["read_error"] == "public_target_not_global"
    assert calls == ["https://example.test/article"]


def test_public_redirect_keeps_text_and_stops_redirect_loops():
    calls = []
    def handler(request):
        calls.append(str(request.url))
        if request.url.path == "/start":
            return httpx.Response(302, headers={"location": "/article"})
        return httpx.Response(200, text="Aslan Serikov", headers={"content-type": "text/plain"})
    with make_client(handler) as client:
        response = client.get_public("https://example.test/start")
    assert response.text == "Aslan Serikov"
    assert len(calls) == 2
    calls.clear()
    def loop(request):
        calls.append(str(request.url))
        return httpx.Response(302, headers={"location": "/again"})
    with make_client(loop) as client:
        response = client.get_public("https://example.test/start")
    assert response.extensions["read_error"] == "public_redirect_limit"
    assert len(calls) == 6


def test_stream_limit_stops_before_buffering_entire_body():
    stream = TrackingStream([b"abcd"] * 100)
    with make_client(lambda request: httpx.Response(200, stream=stream)) as client:
        response = client.get_public("https://example.test/page", max_bytes=5)
    assert response.status_code == 413
    assert response.extensions["read_error"] == "public_document_too_large"
    assert stream.consumed < 100 and stream.closed


def test_large_content_length_rejected_without_reading_body():
    stream = TrackingStream([b"abcd"] * 100)
    with make_client(lambda request: httpx.Response(
            200, headers={"content-length": "9999999"}, stream=stream)) as client:
        response = client.get_public("https://example.test/page", max_bytes=20)
    assert response.status_code == 413 and stream.consumed == 0 and stream.closed


def test_compressed_content_is_capped_after_decompression_and_not_decoded_twice():
    data = "Open public profile: Aslan Serikov".encode()
    stream = TrackingStream([gzip.compress(data)])
    with make_client(lambda request: httpx.Response(
            200, headers={"content-encoding": "gzip"}, stream=stream)) as client:
        response = client.get_public("https://example.test/page", max_bytes=1000)
    assert response.content == data
    assert "content-encoding" not in response.headers
    stream = TrackingStream([gzip.compress(b"x" * 1000)])
    with make_client(lambda request: httpx.Response(
            200, headers={"content-encoding": "gzip"}, stream=stream)) as client:
        response = client.get_public("https://example.test/page", max_bytes=100)
    assert response.status_code == 413


def test_reader_uses_public_fetch_and_retains_sanitized_reason():
    calls = []
    with make_client(lambda request: calls.append(request) or httpx.Response(200)) as client:
        candidate = enrich_candidate(Candidate("web", "https://private.test/page"), client)
    assert candidate.fetch_status == "error"
    assert candidate.fetch_error == "public_target_not_global"
    assert not calls


def test_regular_backend_get_can_still_use_configured_local_service():
    calls = []
    with make_client(lambda request: calls.append(str(request.url)) or httpx.Response(200, text="ok")) as client:
        response = client.get("http://127.0.0.1:8080/search")
    assert response.status_code == 200
    assert calls == ["http://127.0.0.1:8080/search"]


def test_transport_error_does_not_expose_request_url_or_exception_text():
    def fail(request):
        raise httpx.ConnectError("contains fake query token=example-secret", request=request)
    with make_client(fail) as client:
        response = client.get_public("https://example.test/?token=example-secret")
    assert response.extensions["read_error"] == "public_request_failed"
    assert "example-secret" not in str(response.extensions)
