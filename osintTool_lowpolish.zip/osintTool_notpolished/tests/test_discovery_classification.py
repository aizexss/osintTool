"""Regression coverage for recall, evidence merging and ownership boundaries."""

from osintpwd.discovery.candidates import (
    _handle_from_url, canonical_candidate_key, canonical_profile_url, classify,
    is_name_match, merge_candidate,
)
from osintpwd.discovery.identity import annotate_identity
from osintpwd.discovery.models import Candidate, SearchResult


def test_route_prefix_and_uppercase_usernames_remain_candidates():
    urls = [f"https://instagram.com/{handle}" for handle in
            ("ASLAN_SERIKOV", "explorer_aslan", "aboutanna", "myvideo")]
    found = classify("Aslan Serikov", {}, "instagram",
                     [SearchResult(url, "Aslan Serikov") for url in urls])
    assert len(found) == 4
    assert all(c.name_match for c in found)
    assert _handle_from_url("instagram", "https://instagram.com/explore/") is None
    assert _handle_from_url("vk", "https://vk.com/wall12_345") is None
    assert _handle_from_url("vk", "https://vk.com/wallace") == "wallace"


def test_later_stronger_hit_updates_display_and_preserves_every_source():
    results = [
        SearchResult("https://www.instagram.com/runner/?utm_source=web", "Aslan", "Athlete",
                     provider="one", query="Aslan"),
        SearchResult("https://instagram.com/RUNNER", "Aslan Serikov", "Almaty",
                     provider="two", query='"Aslan Serikov"'),
    ]
    found = classify("Aslan Serikov", {"city": "Almaty"}, "instagram", results)
    assert len(found) == 1
    candidate = found[0]
    assert candidate.title == "Aslan Serikov"
    assert candidate.name_match and candidate.score >= 0.5
    assert candidate.matched_hints == ["Almaty"]
    assert candidate.url == "https://instagram.com/runner"
    assert {e["provider"] for e in candidate.evidence} == {"one", "two"}
    assert {e["query"] for e in candidate.evidence} == {"Aslan", '"Aslan Serikov"'}


def test_duplicate_source_does_not_inflate_score_or_evidence_count():
    hit = SearchResult("https://github.com/aslanserikov", "Aslan Serikov", "Almaty",
                       provider="one", query='"Aslan Serikov"')
    one = classify("Aslan Serikov", {}, "github", [hit])[0]
    repeated = classify("Aslan Serikov", {}, "github", [hit] * 8)[0]
    assert one.score == repeated.score
    assert one.evidence == repeated.evidence


def test_another_owner_is_a_weak_target_mention_but_matches_their_own_search():
    hit = SearchResult("https://instagram.com/dias", "Dias Muratov",
                       "Working with Aslan Serikov in Almaty.")
    found = classify("Aslan Serikov", {"city": "Almaty"}, "instagram", [hit])
    assert len(found) == 1 and not found[0].name_match
    assert 'owner_name_conflict' in found[0].match_reasons
    associate = classify("Dias Muratov", {}, "instagram", [hit])
    assert len(associate) == 1 and associate[0].name_match


def test_name_in_owner_bio_title_suffix_is_not_owner_name():
    hit = SearchResult("https://instagram.com/dias", "Dias Muratov | Aslan Serikov collaborator")
    assert not is_name_match("Aslan Serikov", hit, "dias")
    assert is_name_match("Aslan Serikov", SearchResult("u", "Aslan Serikov | Engineer"), "runner")


def test_short_name_requires_whole_tokens_or_exact_compact_handle():
    blank = SearchResult("u")
    assert not is_name_match("Li Wang", blank, "climbingwang")
    assert not is_name_match("Li Wang", blank, "liwangjames")
    assert is_name_match("Li Wang", blank, "li_wang")
    assert is_name_match("Li Wang", blank, "wangli1994")
    assert not is_name_match("Li Wang", SearchResult("u", "Liam Wang"), "someone")


def test_name_punctuation_and_unicode_preserved_consistently():
    assert is_name_match("Anne-Marie O’Neil", SearchResult("u", "Anne Marie O'Neil - Engineer"), "engineer")
    assert is_name_match("José García", SearchResult("u", "José García | Developer"), "developer")
    assert is_name_match("Аслан Сериков", SearchResult("u", "Аслан Сериков — разработчик"), "asik")


def test_account_aliases_merge_but_distinct_namespaces_do_not():
    fb = classify("Aslan Serikov", {}, "facebook", [
        SearchResult("https://m.facebook.com/people/Aslan-Serikov/12345", "Aslan Serikov"),
        SearchResult("https://facebook.com/profile.php?id=12345&ref=search", "Aslan Serikov"),
    ])
    assert len(fb) == 1
    assert len(fb[0].evidence) == 2
    assert canonical_profile_url("x", "https://twitter.com/JACK?utm_source=web") == "https://x.com/jack"
    yt = classify("Aslan Serikov", {}, "youtube", [
        SearchResult("https://youtube.com/@runner", "Aslan Serikov"),
        SearchResult("https://youtube.com/user/runner", "Aslan Serikov"),
    ])
    assert len(yt) == 2
    assert canonical_candidate_key(yt[0]) != canonical_candidate_key(yt[1])


def test_merge_does_not_combine_different_accounts():
    first = Candidate("instagram", "https://instagram.com/a.b", handle="a.b")
    second = Candidate("instagram", "https://instagram.com/ab", handle="ab")
    try:
        merge_candidate(first, second)
    except ValueError:
        pass
    else:
        raise AssertionError("Different punctuated usernames must stay distinct")


def test_identity_keeps_conflicting_display_owners_separate():
    candidates = [
        Candidate("instagram", "https://instagram.com/sharednick", handle="sharednick",
                  title="Aslan Serikov", name_match=True),
        Candidate("x", "https://x.com/sharednick", handle="sharednick",
                  title="Dias Muratov", snippet="Friend of Aslan Serikov", name_match=False),
    ]
    assert annotate_identity("Aslan Serikov", {}, candidates) == 2
    assert candidates[0].group != candidates[1].group
    assert not any(c.confirmed for c in candidates)


def test_identity_preserves_punctuation_and_marks_groups_tentative():
    candidates = [
        Candidate("instagram", "https://instagram.com/aslan.serikov", handle="aslan.serikov",
                  title="Aslan Serikov", name_match=True),
        Candidate("instagram", "https://instagram.com/aslanserikov", handle="aslanserikov",
                  title="Aslan Serikov", name_match=True),
        Candidate("x", "https://x.com/aslanserikov", handle="aslanserikov",
                  title="Aslan Serikov", name_match=True),
    ]
    assert annotate_identity("Aslan Serikov", {}, candidates) == 2
    assert candidates[0].group != candidates[1].group
    assert candidates[1].group == candidates[2].group
    assert "possible_shared_username" in candidates[1].match_reasons
    assert not any(c.confirmed for c in candidates)


def test_hint_evidence_survives_display_hit_replacement_and_annotation():
    hits = [SearchResult("https://github.com/asik", "Aslan", "Almaty"),
            SearchResult("https://github.com/asik", "Aslan Serikov", "AcmeBank")]
    candidates = classify("Aslan Serikov", {"city": "Almaty", "employer": "AcmeBank"}, "github", hits)
    annotate_identity("Aslan Serikov", {"city": "Almaty", "employer": "AcmeBank"}, candidates)
    assert set(candidates[0].matched_hints) == {"Almaty", "AcmeBank"}


def test_invalid_or_lookalike_urls_never_become_accounts():
    for url in ("https://notinstagram.com/aslan", "javascript:alert(1)", "https://[broken/aslan", None, 123):
        assert _handle_from_url("instagram", url) is None


def test_unknown_username_platform_keys_remain_usable():
    first = Candidate("behance", "https://behance.net/aslan/", handle="aslan")
    second = Candidate("behance", "https://behance.net/aslan", handle="aslan")
    assert _handle_from_url("behance", first.url) is None
    assert canonical_candidate_key(first) == canonical_candidate_key(second)
    assert merge_candidate(first, second).url == "https://behance.net/aslan"


def test_related_discovery_upgrade_preserves_route_and_provenance():
    weak = Candidate("instagram", "https://instagram.com/asik", handle="asik", score=0.2)
    linked = Candidate("instagram", "https://instagram.com/asik", handle="asik", score=0.7,
                       name_match=True, relation="via_related", related_person="Dias Muratov")
    merge_candidate(weak, linked)
    assert weak.relation == "via_related" and weak.related_person == "Dias Muratov"
    direct = Candidate("instagram", weak.url, handle="asik", name_match=True, relation="direct")
    merge_candidate(weak, direct)
    assert weak.relation == "direct" and weak.related_person == "Dias Muratov"


def test_merge_retains_best_read_status_and_clears_recovered_error():
    old = Candidate("instagram", "https://instagram.com/asik", handle="asik")
    failed = Candidate("instagram", old.url, handle="asik", fetch_status="error", fetch_error="HTTP 403")
    merge_candidate(old, failed)
    assert old.fetch_status == "error" and old.fetch_error == "HTTP 403"
    success = Candidate("instagram", old.url, handle="asik", fetch_status="ok", public_text="Profile text")
    merge_candidate(old, success)
    assert old.fetch_status == "ok" and old.fetch_error == "" and old.public_text == "Profile text"
    merge_candidate(old, failed)
    assert old.fetch_status == "ok" and old.fetch_error == ""


def test_github_username_parenthesized_display_name_is_owner_evidence():
    hit = SearchResult("https://github.com/torvalds", "torvalds (Linus Torvalds) · GitHub")
    candidate = classify("Linus Torvalds", {}, "github", [hit])[0]
    assert candidate.name_match and "name_in_title" in candidate.match_reasons
    wrong_owner = SearchResult("https://github.com/dias", "otherhandle (Aslan Serikov) · GitHub")
    assert not is_name_match("Aslan Serikov", wrong_owner, "dias")
    discussion = SearchResult("https://github.com/dias", "dias (Aslan Serikov collaborator) · GitHub")
    assert not is_name_match("Aslan Serikov", discussion, "dias")


def test_search_query_alone_cannot_make_unrelated_profiles_candidates():
    for platform, url, title, snippet in (
        ("linkedin", "https://linkedin.com/in/neil-j-fletcher-fca-78a70014b",
         "Neil J Fletcher, FCA - Finance and governance professional", "Finance professional"),
        ("reddit", "https://reddit.com/user/mollysnowcone", "mollysnowcone (u/mollysnowcone)", "TikTok videos"),
        ("twitch", "https://twitch.tv/twitch", "Twitch - Twitch", "Watch live streams"),
        ("github", "https://github.com/zhumadilmuhammedali123-commits",
         "zhumadilmuhammedali123-commits · GitHub", "Joined Sep 12, 2026"),
    ):
        hit = SearchResult(url, title, snippet, query='"Zhumali Muhammed"')
        assert classify("Zhumali Muhammed", {}, platform, [hit]) == []


def test_partial_name_handle_and_hint_evidence_stay_reviewable():
    hits = [
        SearchResult("https://instagram.com/zhumali", "Instagram", ""),
        SearchResult("https://instagram.com/zhumali50", "Instagram", ""),
        SearchResult("https://instagram.com/runner", "Zhumali", ""),
        SearchResult("https://instagram.com/engineer", "Engineer", "Astana IT University"),
    ]
    found = classify("Zhumali Muhammed", {"school": "Astana IT University"}, "instagram", hits)
    assert {c.handle for c in found} == {"zhumali", "zhumali50", "runner", "engineer"}
    assert all(not c.name_match and not c.confirmed for c in found)
    assert all(c.score > 0 for c in found)
    assert "partial_name_in_handle" in next(c for c in found if c.handle == "zhumali50").match_reasons


def test_irrelevant_hit_does_not_blacklist_later_relevant_evidence():
    rejected = set()
    url = "https://instagram.com/runner"
    assert classify("Zhumali Muhammed", {}, "instagram", [SearchResult(url, "Instagram")],
                    rejected_urls=rejected) == []
    found = classify("Zhumali Muhammed", {}, "instagram", [SearchResult(url, "Zhumali Muhammed")],
                     rejected_urls=rejected)
    assert len(found) == 1 and found[0].name_match
