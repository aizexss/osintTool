"""A contradicted owner must not return through weaker discovery routes."""

from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient

from osintpwd.discovery import pipeline, related, username
from osintpwd.discovery.candidates import build_extra_queries, merge_candidate
from osintpwd.discovery.models import Candidate, DiscoveryResult, SearchResult
from osintpwd.web.app import app


NAME = "Асель Исаханова"
EXCLUDED = "https://github.com/sharednick"


class Backend:
    name = "fixture"
    errors = []

    def __init__(self, results):
        self.results = results

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        return self.results.get(query, [])[:max_results]


class Client:
    def __init__(self, *args, **kwargs):
        pass

    def close(self):
        pass


@pytest.mark.parametrize("conflict_first", [True, False])
def test_discovery_conflict_survives_blank_duplicates_and_username_pivot(monkeypatch, conflict_first):
    conflicting = SearchResult(EXCLUDED, "Асель Иванова", f"Mentions {NAME}")
    blank = SearchResult("https://www.github.com/sharednick/?utm_source=search")
    first, later = (conflicting, blank) if conflict_first else (blank, conflicting)
    hits = {
        f'site:instagram.com "{NAME}"': [
            SearchResult("https://instagram.com/sharednick", NAME)],
        f'"{NAME}"': [first, SearchResult("https://x.com/quietprofile", "Асель")],
        build_extra_queries(NAME, ('instagram', 'github', 'x'))[0]: [later],
    }
    monkeypatch.setattr(pipeline, "PoliteClient", Client)
    monkeypatch.setattr(pipeline, "name_variants", lambda name: [name])
    monkeypatch.setattr(username, "check_username", lambda handle: [
        {"site": "github", "url": "https://www.github.com/sharednick/?ref=expanded"},
        {"site": "gitlab", "url": "https://gitlab.com/sharednick"},
    ])
    associate = Candidate("github", EXCLUDED, title="Асель Иванова", relation="related_person")
    target_copy = Candidate("github", EXCLUDED, relation="via_related", name_match=True)
    monkeypatch.setattr(related, "discover_via_related", lambda *args, **kwargs: {
        "people": ["Асель Иванова"], "candidates": [associate, target_copy], "errors": [],
    })

    result = pipeline.discover(NAME, backend=Backend(hits), platforms=("instagram", "github", "x"),
                               fetch_pages=0, enrich_profiles=0, related_search="always")

    assert result.excluded_profile_urls == []
    assert {c.url for c in result.candidates} == {
        EXCLUDED, "https://instagram.com/sharednick", "https://x.com/quietprofile", "https://gitlab.com/sharednick",
    }
    assert result.related_accounts == [associate]
    assert result.stats["candidate_count"] == 4
    saved = next(c for c in result.candidates if c.url == EXCLUDED)
    assert not saved.name_match and 'owner_name_conflict' in saved.match_reasons


def test_linked_profile_conflict_cannot_return_as_generic_relme_link():
    rejected_urls = set()
    page = Candidate("github", "https://github.com/target", title=NAME, name_match=True)
    page.public_links = [{"site": "instagram", "url": "https://instagram.com/other",
                          "anchor": "Асель Иванова", "rel_me": True}]
    first = pipeline._linked_candidates(NAME, [NAME], {}, page, owner=page,
                                         rejected_urls=rejected_urls)[0]
    assert not first.name_match and 'owner_name_conflict' in first.match_reasons
    assert rejected_urls == set()
    page.public_links[0]["anchor"] = "Instagram"
    later = pipeline._linked_candidates(NAME, [NAME], {}, page, owner=page,
                                         rejected_urls=rejected_urls)[0]
    merged = merge_candidate(first, later)
    assert not merged.name_match and merged.title == 'Асель Иванова'


def test_enriched_owner_conflict_retains_suggestion_but_stops_username_pivot(monkeypatch):
    def enrich(candidate, client):
        candidate.title = "Асель Иванова"
        candidate.fetch_status = "ok"
        candidate.public_links = [{"site": "x", "url": "https://x.com/other",
                                   "anchor": "X", "rel_me": True}]
        return candidate

    monkeypatch.setattr(pipeline, "PoliteClient", Client)
    monkeypatch.setattr(pipeline, "name_variants", lambda name: [name])
    monkeypatch.setattr(pipeline, "enrich_candidate", enrich)
    with patch("osintpwd.discovery.username.check_username") as expand:
        result = pipeline.discover(NAME, backend=Backend({
            f'site:instagram.com "{NAME}"': [SearchResult("https://instagram.com/sharednick", NAME)],
        }), platforms=("instagram",), fetch_pages=0, enrich_profiles=1, related_search="off")
    assert len(result.candidates) == 1 and not result.candidates[0].name_match
    assert 'owner_name_conflict' in result.candidates[0].match_reasons
    assert result.excluded_profile_urls == []
    expand.assert_not_called()


def test_expand_filters_canonical_exclusions_and_keeps_legacy_requests_compatible():
    hits = [{"site": "github", "url": "https://www.github.com/sharednick/?ref=expanded"},
            {"site": "gitlab", "url": "https://gitlab.com/sharednick"}]
    client = TestClient(app)
    with patch("osintpwd.discovery.username.check_username", return_value=hits):
        response = client.post("/api/expand", json={"handle": "sharednick",
            "excluded_profile_urls": ["https://github.com/SHAREDNICK/?utm_source=search"]})
        legacy = client.post("/api/expand", json={"handle": "sharednick"})
    assert response.status_code == 200
    assert response.json()["accounts"] == [hits[1]]
    assert response.json()["count"] == 1
    assert legacy.status_code == 200
    assert legacy.json()["accounts"] == [{**hits[0], "url": EXCLUDED}, hits[1]]
    assert client.post("/api/expand", json={"handle": "sharednick",
        "excluded_profile_urls": ["file:///not-a-web-profile"]}).status_code == 422


def test_discovery_api_exposes_exclusions_without_removing_related_people():
    associate = Candidate("github", EXCLUDED, title="Асель Иванова", relation="related_person")
    result = DiscoveryResult(NAME, excluded_profile_urls=[EXCLUDED], related_accounts=[associate])
    with patch("osintpwd.discovery.discover", return_value=result):
        response = TestClient(app).post("/api/discover", json={"name": NAME})
    assert response.status_code == 200
    assert response.json()["excluded_profile_urls"] == [EXCLUDED]
    assert response.json()["related_accounts"][0]["url"] == EXCLUDED
