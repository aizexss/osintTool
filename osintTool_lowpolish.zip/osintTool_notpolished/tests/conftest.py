"""Keep process provider state isolated between independent offline fixtures."""
import pytest


@pytest.fixture(autouse=True)
def isolated_search_runtime(monkeypatch):
    monkeypatch.setenv('OSINT_SEARCH_CACHE_PATH', 'off')
    from osintpwd.discovery import search, provider_state, searxng_engines
    from osintpwd.discovery import maigret_scan
    maigret_scan._COOLDOWNS.clear()
    maigret_scan._CACHE.clear()
    searxng_engines._POOLS.clear()
    search._RESPONSE_CACHE.clear()
    provider_state._STATES.clear()
    monkeypatch.setattr(search, '_PROVIDER_INTERVALS',
                        dict.fromkeys(('searxng', 'duckduckgo', 'serper', 'google_cse'), 0))
    yield
    searxng_engines._POOLS.clear()
    search._RESPONSE_CACHE.clear()
    provider_state._STATES.clear()
