"""Reported SERP noise must never masquerade as information about the target."""
import pytest

from osintpwd.discovery import pipeline
from osintpwd.discovery.models import SearchResult

NAME = 'Zhumali Muhammed'
REPOSITORY = 'https://github.com/MuhammedZhumali/ModelComparison'
NOISE = [
    ('https://www.instagram.com/', 'Instagram', 'Create an account or log in to Instagram'),
    ('https://www.facebook.com/login.php/', 'Log into Facebook', 'Email or mobile number Password'),
    ('https://secure.facebook.com/', 'Facebook - log in or sign up', 'Connect with friends'),
    ('https://vk.ru/', 'ВКонтакте Вход | Добро пожаловать', 'Универсальное средство для общения'),
    ('https://vk.ru/im/convo/2000000082?entrypoint=list_all', 'VK | Welcome!', 'Social network'),
    ('https://www.instagram.com/p/C_tbe1jC2Ig/', 'Zhumali Muhammedali | 10 years in pursuit of a dream.', '81 likes'),
    ('https://t.me/s/kalibrated?before=32709', 'Kalibrated – Telegram', 'Map here'),
    ('https://www.tiktok.com/', 'TikTok - Make Your Day', 'TikTok trends start here'),
    ('https://t.me/s/talebrawl?before=444', 'Tale Stars – Telegram', 'Buy Tale+'),
    ('https://bsky.app/profile/did:plc:qrz3lhbyuxbeilrc6nekdqme/feed/49d024e8924d', 'Meta AI ad', 'Users mock a song'),
    ('https://fr.twitch.tv/', 'Twitch', 'Interactive livestreaming service'),
    ('https://gitlab.com/demonhorses/fivem-spoofer', 'Demon Horse / FiveM-Spoofer', 'Windows application'),
    ('https://handbook.gitlab.com/handbook/people-policies/', 'People Policies', 'GitLab team members'),
    ('https://medium.com/', 'Medium', 'Anyone can share perspectives'),
    ('https://soundcouch.soundcloud.com/', 'SoundCloud', 'Discovering and sharing music'),
    ('https://link.medium.com/', 'Welcome to Medium!', 'Send me the app'),
    ('https://x.com/Myselfwilson/status/2102257692471648627', 'Wilson on X', 'Chemistry so goated'),
    ('https://x.com/Lytherian/status/2101019261187551505', 'Lyth on X', 'School busses'),
    ('https://github.com/openclaw/openclaw', 'GitHub - openclaw/openclaw', 'Open-source AI assistant'),
    ('https://www.tiktok.com/@mizan_zhumali/video/7522930728493944120', '#қошқар | TikTok', 'Mizan_Zhumali'),
    ('https://www.youtube.com/watch?v=klElrevyx-U', 'YouTube', 'Enjoy videos and music'),
    ('https://www.youtube.com/feed', 'YouTube', 'AboutPressCopyrightContact us'),
    ('https://www.threads.com/search', 'Search • Threads', 'Log in using your Instagram account'),
    ('https://www.threads.com/login', 'Threads • Log in', 'Join Threads to share ideas'),
]


class Backend:
    name = 'fixture'
    errors = []

    def __init__(self, hits):
        self.hits = hits

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        return self.hits if query == f'"{NAME}"' else []


class Client:
    def __init__(self, *args, **kwargs):
        pass

    def close(self):
        pass


def discover(monkeypatch, hits, *, text='', related='off', fetch_pages=0):
    reads = []

    def enrich(page, client):
        reads.append(page.url)
        page.public_text = text
        page.fetch_status = 'ok'
        return page

    monkeypatch.setattr(pipeline, 'PoliteClient', Client)
    monkeypatch.setattr(pipeline, 'name_variants', lambda name: [name])
    monkeypatch.setattr(pipeline, 'enrich_candidate', enrich)
    result = pipeline.discover(NAME, backend=Backend(hits), username_scan=False,
        enrich_profiles=0, fetch_pages=fetch_pages, related_search=related)
    return result, reads


def test_reported_noise_is_removed_but_author_repository_and_linkedin_survive(monkeypatch):
    linkedin = 'https://linkedin.com/in/fixture-person'
    result, reads = discover(monkeypatch, [SearchResult(*row) for row in NOISE] + [
        SearchResult(REPOSITORY, 'GitHub - MuhammedZhumali/ModelComparison',
                     'Ready-to-use Jupyter notebooks. Author: Muhammed Zhumali'),
        SearchResult(linkedin, 'Muhammed Zhumali - LinkedIn'),
    ], fetch_pages=4)
    assert [w['url'] for w in result.web_info] == [REPOSITORY]
    assert reads == [REPOSITORY]
    assert any(c.url == linkedin and c.name_match for c in result.candidates)


@pytest.mark.parametrize('url', ['https://instagram.com/', 'https://facebook.com/login.php/',
    'https://vk.ru/im/convo/1', 'https://youtube.com/feed', 'https://threads.com/search'])
def test_navigation_is_not_evidence_even_if_search_snippet_echoes_the_query(monkeypatch, url):
    result, reads = discover(monkeypatch, [SearchResult(url, NAME, NAME)], fetch_pages=4)
    assert result.web_info == [] and reads == []


def test_name_in_query_or_url_and_partial_name_are_not_content_evidence(monkeypatch):
    result, _ = discover(monkeypatch, [
        SearchResult('https://news.example/Zhumali-Muhammed', 'Home', 'Welcome'),
        SearchResult('https://news.example/one', 'Zhumali Muhammedali', 'Sports'),
        SearchResult('https://news.example/two', 'Zhumali', 'Muhammedali'),
    ])
    assert result.web_info == []


def test_relevant_public_post_and_personal_homepage_are_retained(monkeypatch):
    urls = ['https://instagram.com/p/observedPost/', 'https://personal.example/']
    result, _ = discover(monkeypatch, [SearchResult(url, 'Project news',
        'Muhammed Zhumali presented the project.') for url in urls])
    assert {w['url'] for w in result.web_info} == set(urls)


@pytest.mark.parametrize('body,expected', [('Project by Muhammed Zhumali.', True),
                                          ('Generic project documentation.', False)])
def test_one_unproven_article_can_be_read_but_requires_body_evidence(monkeypatch, body, expected):
    url = 'https://news.example/project'
    result, reads = discover(monkeypatch, [SearchResult(url, 'Project report', 'Project details')],
                             text=body, related='auto', fetch_pages=1)
    assert reads == [url]
    assert bool(result.web_info) is expected
    if expected:
        assert result.web_info[0]['excerpt'] == body


def test_unrelated_sources_cannot_fill_the_display_limit_ahead_of_a_named_source(monkeypatch):
    junk = [SearchResult(f'https://news.example/item/{i}', 'Unrelated article') for i in range(120)]
    result, _ = discover(monkeypatch, junk + [SearchResult(REPOSITORY, 'Code', 'Author: Muhammed Zhumali')])
    assert [w['url'] for w in result.web_info] == [REPOSITORY]


@pytest.mark.parametrize('body,expected', [('Author: Muhammed Zhumali', True),
                                          ('Generic project documentation.', False)])
def test_named_url_is_only_a_read_lead_even_when_linkedin_was_found(monkeypatch, body, expected):
    result, reads = discover(monkeypatch, [
        SearchResult('https://linkedin.com/in/fixture-person', NAME),
        SearchResult(REPOSITORY, 'GitHub - MuhammedZhumali/ModelComparison', 'Model comparison code'),
        SearchResult('https://github.com/MuhammedZhumali/Other', 'More code'),
    ], text=body, fetch_pages=4)
    assert reads == [REPOSITORY]  # at most one unproven source, within the page budget
    assert bool(result.web_info) is expected
    assert any(c.platform == 'linkedin' and c.name_match for c in result.candidates)
    if expected:
        assert result.web_info[0]['name_context'] == body
