"""Offline integration checks for source retention and account attribution."""

from osintpwd.discovery import pipeline
from osintpwd.discovery.candidates import build_extra_query
from osintpwd.discovery.models import Candidate, SearchResult


class Backend:
    name = "fixture"
    errors = []

    def __init__(self, results):
        self.results = results

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        return self.results.get(query, [])[:max_results]


class Client:
    def __init__(self, *args, **kwargs):
        pass

    def close(self):
        pass


def run_offline(monkeypatch, results, *, fetch_pages=0, page_text="Public source text"):
    reads = []

    def enrich(candidate, client):
        reads.append(candidate.url)
        candidate.fetch_status = "ok"
        candidate.public_text = page_text
        return candidate

    monkeypatch.setattr(pipeline, "PoliteClient", Client)
    monkeypatch.setattr(pipeline, "name_variants", lambda name: [name])
    monkeypatch.setattr(pipeline, "enrich_candidate", enrich)
    result = pipeline.discover("Aslan Serikov", backend=Backend(results),
        username_scan=False, fetch_pages=fetch_pages, enrich_profiles=0, related_search="off")
    return result, reads


def test_site_and_extra_results_keep_nonprofile_source_pages(monkeypatch):
    post = "https://linkedin.com/posts/aslan_startup"
    article = "https://news.example/people"
    result, _ = run_offline(monkeypatch, {
        'site:linkedin.com/in "Aslan Serikov"': [SearchResult(post, "Aslan Serikov and Dias Muratov")],
        build_extra_query("Aslan Serikov"): [SearchResult(article, "Aslan Serikov profile")],
    })
    assert {post, article} <= {source["url"] for source in result.web_info}


def test_profile_url_alias_does_not_consume_article_read_budget(monkeypatch):
    article = "https://news.example/interview"
    result, reads = run_offline(monkeypatch, {'"Aslan Serikov"': [
        SearchResult("https://www.instagram.com/aslan.serikov/?utm_source=web", "Aslan Serikov"),
        SearchResult(article, "Aslan Serikov interview"),
    ]}, fetch_pages=1)
    assert result.candidates
    assert reads == [article]
    assert [source["url"] for source in result.web_info] == [article]


def test_malformed_external_hit_does_not_lose_valid_candidates(monkeypatch):
    result, _ = run_offline(monkeypatch, {'"Aslan Serikov"': [
        SearchResult("https://instagram.com/aslan.serikov", "Aslan Serikov"),
        SearchResult("https://[broken", "Malformed result"),
    ]})
    assert len(result.candidates) == 1
    assert result.candidates[0].name_match
    assert not any(source["url"] == "https://[broken" for source in result.web_info)


def test_news_headline_does_not_make_publishers_relme_account_the_target():
    page = Candidate("web", "https://news.example/interview", title="Aslan Serikov interviewed")
    page.public_links = [{"site": "x", "url": "https://x.com/newsdesk", "anchor": "News Desk",
                          "context": "News Desk", "rel_me": True}]
    found = pipeline._linked_candidates("Aslan Serikov", ["Aslan Serikov"], {}, page)
    assert not any(candidate.name_match for candidate in found)


def test_name_attached_contact_link_survives_a_generic_anchor():
    page = Candidate("web", "https://news.example/team", title="Project team")
    page.public_links = [{"site": "instagram", "url": "https://instagram.com/asik", "anchor": "@asik",
                          "context": "Contact Aslan Serikov: @asik", "rel_me": False}]
    found = pipeline._linked_candidates("Aslan Serikov", ["Aslan Serikov"], {}, page)
    assert len(found) == 1
    assert found[0].url == "https://instagram.com/asik"
    assert found[0].evidence[0]["source_url"] == page.url


def test_named_profiles_relme_link_can_support_a_target_proposal():
    profile = Candidate("github", "https://github.com/aslanserikov", title="Aslan Serikov", name_match=True)
    profile.public_links = [{"site": "instagram", "url": "https://instagram.com/asik", "anchor": "Instagram",
                             "context": "Instagram", "rel_me": True}]
    found = pipeline._linked_candidates("Aslan Serikov", ["Aslan Serikov"], {}, profile, owner=profile)
    assert len(found) == 1 and found[0].name_match
    assert found[0].evidence[0]["kind"] == "profile_link"


def test_short_target_name_does_not_attach_another_persons_contact_link():
    page = Candidate("web", "https://news.example/team", title="Project team")
    page.public_links = [{"site": "instagram", "url": "https://instagram.com/asik", "anchor": "@asik",
                          "context": "Ali Wang: @asik", "rel_me": False}]
    found = pipeline._linked_candidates("Li Wang", ["Li Wang"], {}, page)
    assert not found


def test_manual_continuation_receives_comentions_late_in_article(monkeypatch):
    article = "https://news.example/interview"
    late_mention = "Aslan Serikov met Dias Muratov."
    body = "Background information. " * 70 + "\n" + late_mention
    result, _ = run_offline(monkeypatch, {'"Aslan Serikov"': [
        SearchResult(article, "Aslan Serikov interview"),
    ]}, fetch_pages=1, page_text=body)
    assert len(body) > 800
    assert late_mention in result.web_info[0]["excerpt"]
    assert len(result.web_info[0]["excerpt"]) <= 24_000
