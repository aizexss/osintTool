// Run: node --test tests/test_discovery_precision_ui.js
// Exercise the shipped dashboard handlers without network or browser dependencies.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const {test} = require('node:test');

const html = fs.readFileSync(path.join(__dirname, '../osintpwd/web/static/index.html'), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];

function dashboard() {
  const elements = new Map(), requests = [], replies = [], downloads = [];
  const element = id => {
    if (!elements.has(id)) elements.set(id, {
      value: '', textContent: '', innerHTML: '', style: {}, open: false, hidden: false,
      disabled: false, children: new Map(), classList: {toggle() {}},
      addEventListener() {}, setAttribute() {}, click() {}, remove() {}, prepend() {},
      querySelector(selector) {
        if (!this.children.has(selector)) this.children.set(selector, element(id + selector));
        return this.children.get(selector);
      },
      querySelectorAll() { return []; }, insertAdjacentHTML() {},
    });
    return elements.get(id);
  };
  class DownloadURL extends URL {
    static createObjectURL(blob) { downloads.push(blob); return 'blob:fixture'; }
    static revokeObjectURL() {}
  }
  const context = vm.createContext({
    console, URL: DownloadURL, Blob, setTimeout, clearTimeout, alert() {},
    document: {getElementById: element, createElement: () => ({click() {}})},
    async fetch(url, options) {
      requests.push({url, body: JSON.parse(options.body)});
      assert.ok(replies.length, 'Unexpected network request');
      const result=replies.shift();
      return {ok: true, json: async () => url==='/api/discovery-jobs'?
        {id:'fixture',status:'completed',input:JSON.parse(options.body),updated:1,result}:result};
    },
  });
  context.window = context;
  vm.runInContext(script, context, {filename: 'dashboard-inline.js'});
  return {context, element, requests, replies, downloads,
    run(code) { return vm.runInContext(code, context); }};
}

function populate(d) {
  d.run(`
    lastSearch={name:'Dana Kim'};
    showDiscovery({
      candidates:[{platform:'linkedin',url:'https://linkedin.com/in/dana-kim',
        handle:'dana-kim',title:'Dana Kim',name_match:true,confirmed:false,score:.8}],
      uncertain_candidates:[{platform:'instagram',url:'https://instagram.com/dana',
        handle:'dana',title:'Dana',name_match:false,confirmed:false,score:.4,
        evidence:[{kind:'search',source_url:'https://example.org',excerpt:'Dana'}]}],
      related_accounts:[],excluded_profile_urls:[],stats:{seconds:2,search_queries:3}
    });
  `);
}

test('all account matches share one list and select all includes every card', () => {
  assert.doesNotMatch(html, /uncertainSection|uncertainCandidates|uncertainCount/);
  const d = dashboard(); populate(d);
  assert.match(d.element('candidates').innerHTML, /Dana Kim/);
  assert.match(d.element('candidates').innerHTML, /instagram/);
  assert.match(d.element('candidates').innerHTML, /возможное совпадение/);
  assert.equal(d.element('candCount').textContent, 2);
  assert.match(d.element('searchStatus').textContent, /Всего аккаунтов: 2/);
  assert.doesNotMatch(d.element('searchStatus').textContent, /Неполных совпадений|В основном списке/);
  d.element('selAll').onclick();
  assert.equal(d.run('JSON.stringify([...selected])'), '[0,1]');
  assert.equal(d.run('found[0].confirmed || found[1].confirmed'), false);
  d.element('selNone').onclick();
  assert.equal(d.run('selected.size'),0);
});

test('name matches rank first and a selected account survives reordering', () => {
  const d=dashboard(); populate(d);
  d.run(`toggleCand(1); showDiscovery({candidates:[
    {platform:'github',url:'https://github.com/dana',handle:'dana',name_match:true,score:.7},
    {platform:'linkedin',url:'https://linkedin.com/in/dana-kim',handle:'dana-kim',name_match:true,score:.8}],
    uncertain_candidates:[{platform:'instagram',url:'https://instagram.com/dana',handle:'dana',
      name_match:false,confirmed:false,score:.99}],stats:{}});`);
  assert.equal(d.run('JSON.stringify(found.map(c=>c.platform))'),'["linkedin","github","instagram"]');
  assert.equal(d.run('JSON.stringify([...selected].map(i=>found[i].platform))'),'["instagram"]');
  assert.equal(d.run('found[2].name_match || found[2].confirmed'),false);
});

test('username-only matches are visible without an empty-account message', () => {
  const d=dashboard();
  d.run(`showDiscovery({candidates:[],uncertain_candidates:[{platform:'steam',
    url:'https://steamcommunity.com/id/dana',handle:'dana',relation:'username',score:.25}],stats:{}});`);
  assert.equal(d.element('candCount').textContent,1);
  assert.match(d.element('candidates').innerHTML,/совпадение ника/);
  assert.doesNotMatch(d.element('candidates').innerHTML,/не найдены/);
});

test('publication evidence shows comment context and escapes provider content', () => {
  const d=dashboard();
  d.run(`renderInfo([{url:'https://vk.com/wall-1_2?reply=3',title:'Discussion',
    source_type:'comment',name_context:'Dana Kim: thanks',fetch_status:'error',
    profile_connection:{profile_url:'https://linkedin.com/in/dana',excerpt:'Contact @dana'},
    search_evidence:[{provider:'fixture',query:'site:vk.com "Dana Kim"',excerpt:'<script>bad()</script>'}]}]);`);
  const rendered=d.element('webInfo').innerHTML;
  assert.match(rendered,/Комментарий/);
  assert.match(rendered,/Dana Kim: thanks/);
  assert.match(rendered,/Ссылка на найденный профиль/);
  assert.match(rendered,/Страница недоступна/);
  assert.match(rendered,/Как найдено/);
  assert.match(rendered,/&lt;script&gt;/);
  assert.doesNotMatch(rendered,/<script>/);
});

test('one analysis request returns name, username and related results without follow-up controls', async () => {
  const d=dashboard();
  d.element('first_name').value='Dana'; d.element('last_name').value='Kim';
  d.replies.push({candidates:[{platform:'github',url:'https://github.com/dana',handle:'dana',name_match:true,keywords:['software']}],
    uncertain_candidates:[{platform:'steam',url:'https://steamcommunity.com/id/dana',handle:'dana',
      relation:'username',name_match:false,confirmed:false,evidence:[{provider:'maigret',kind:'username'}]}],
    related_accounts:[],stats:{username_scans:[{handle:'dana'}],search_mode:'keyless'}});
  await d.element('discoverBtn').onclick();
  assert.equal(d.requests.length,1);
  assert.equal(d.requests[0].url,'/api/discovery-jobs');
  assert.equal(d.requests[0].body.name,'Dana Kim');
  assert.equal(d.requests[0].body.search_mode,undefined);
  assert.equal(d.run('lastDiscovery.candidates.length'),1);
  assert.equal(d.run('lastDiscovery.uncertain_candidates[0].confirmed'),false);
  assert.doesNotMatch(html,/id="(?:searchMode|searchPlatform|relatedBtn|analyzeBtn)"/);
  assert.doesNotMatch(html,/expandCand/);
  d.run('toggleCand(0)');
  assert.equal(d.requests.length,1,'Selection must use the completed analysis locally');
  assert.equal(d.run('tokens.includes("software")'),true);
  d.element('discoveryExportBtn').onclick();
  const exported=JSON.parse(await d.downloads[0].text());
  assert.equal(exported.uncertain_candidates[0].relation,'username');
  assert.equal(exported.uncertain_candidates[0].evidence[0].provider,'maigret');
});

test('new analysis clears previous selected data but preserves manual tokens', async () => {
  const d=dashboard(); populate(d);
  d.run("tokens=['manual'];manualTokens.add('manual');toggleCand(0)");
  assert.equal(d.run("tokens.includes('dana-kim')"),true);
  d.element('first_name').value='New'; d.element('last_name').value='Person';
  d.replies.push({candidates:[],uncertain_candidates:[],stats:{},related_accounts:[]});
  await d.element('discoverBtn').onclick();
  assert.equal(d.run('JSON.stringify(tokens)'), '["manual"]');
  assert.equal(d.element('candCount').textContent,0);
  assert.equal(d.run('selected.size'),0);
  assert.equal(d.element('discoverBtn').disabled,false);
});

test('failed analysis releases the button and does not restore previous results', async () => {
  const d=dashboard(); populate(d);
  d.element('first_name').value='Dana';
  await d.element('discoverBtn').onclick(); // the network fixture deliberately fails
  assert.equal(d.element('discoverBtn').disabled,false);
  assert.equal(d.run('lastDiscovery'),null);
  assert.equal(d.run('found.length'),0);
  assert.equal(d.element('discoveryExportBtn').disabled,true);
});

test('empty provider outage is visible alongside cache age and cooldown', () => {
  const d=dashboard();
  d.run(`renderSearchStatus({candidates:[],stats:{search_degraded:true,stale_results:2,
    provider_statuses:[{provider:'searxng',status:'cooldown',retry_after_seconds:60}]}})`);
  assert.match(d.element('searchStatus').innerHTML, /Поиск неполный/);
  assert.match(d.element('searchStatus').innerHTML, /пауза ещё 60 с/);
  const evidence=d.run(`renderEvidence({evidence:[{source_url:'https://example.org',
    cached:true,cache_age_seconds:660,stale:true}]})`);
  assert.match(evidence, /11 мин/);
  assert.match(evidence, /источник сейчас недоступен/);
});

test('publication panel distinguishes running work from an incomplete empty search', () => {
  const d=dashboard();
  d.run('renderInfo([],{},true)');
  assert.match(d.element('webInfo').innerHTML,/ещё не завершены/);
  d.run(`renderInfo([],{publication_diagnostics:{queries:12,read_pages:6,retained_sources:0,
    vk_queries:5,vk_results:0,unavailable_queries:3,partial:true}})`);
  const text=d.element('webInfo').innerHTML;
  assert.match(text,/12 запросов/);
  assert.match(text,/VK: 5 запросов/);
  assert.match(text,/Поиск неполный/);
  assert.doesNotMatch(text,/нет страниц с упоминанием полного имени/);
});
