"""Offline checks for honest, platform-aware evaluation denominators."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from osintpwd.discovery.evaluate import account_key, labelled_keys, score_result, summarize


def test_same_handle_other_platform_is_not_a_hit():
    case = {"expect": [{"platform": "instagram", "url": "https://instagram.com/anna"}]}
    result = {"candidates": [{"platform": "github", "url": "https://github.com/anna"}]}
    assert score_result(case, result)["known_recall"] == 0


def test_punctuation_is_identity_relevant():
    assert account_key({"url": "https://instagram.com/anna.smith"}) != account_key({"url": "https://instagram.com/annasmith"})


def test_url_alias_tracking_and_facebook_id_forms():
    assert account_key({"url": "http://www.twitter.com/ANNA/?utm_source=x#about"}) == account_key({"url": "https://x.com/anna"})
    assert account_key({"url": "https://facebook.com/people/Anna-Smith/123456/"}) == account_key({"url": "https://m.facebook.com/profile.php?id=123456&ref=abc"})


def test_platform_mismatch_and_lookalike_not_a_label():
    assert account_key({"platform": "github", "url": "https://instagram.com/anna"}) is None
    assert account_key({"url": "https://notgithub.com/anna"}) is None
    assert account_key({"platform": "github", "url": "https://notgithub.com/anna"}) is None
    assert account_key({"platform": "github", "url": "https://[broken/anna"}) is None


def test_youtube_channel_id_remains_case_sensitive():
    assert account_key({"url": "https://youtube.com/channel/UCabc"}) != account_key({"url": "https://youtube.com/channel/UCABC"})


def test_legacy_handle_requires_explicit_platform():
    keys, warnings = labelled_keys({"expect": ["anna"]})
    assert not keys and warnings
    keys, warnings = labelled_keys({"expect": ["anna"], "legacy_platform": "github"})
    assert keys == {("github", "https://github.com/anna")} and warnings


def test_unknown_is_not_a_negative_and_precision_reports_coverage():
    case = {"expect": [{"url": "https://github.com/anna"}]}
    result = {"candidates": [{"url": "https://github.com/anna"}, {"url": "https://github.com/unknown"}]}
    score = score_result(case, result)
    assert score["precision_at_k"] is None
    assert score["precision_among_judged_at_k"] == 1
    assert score["label_coverage_at_k"] == 0.5


def test_related_accounts_do_not_count_as_target_hits():
    label = {"url": "https://github.com/anna"}
    score = score_result({"expect": [label], "expect_related": [label]}, {"related_accounts": [label]})
    assert score["known_recall"] == 0 and score["related_recall"] == 1


def test_weak_rejected_proposal_is_not_an_ownership_claim():
    label = {"url": "https://github.com/anna"}
    score = score_result({"reject": [label]}, {"candidates": [label]})
    assert score["false_target_promotions"] == 0
    assert score["rejected_in_primary"] == 1
    score = score_result({"reject": [label]}, {"candidates": [{**label, "name_match": True}]})
    assert score["false_target_promotions"] == 1


def test_attempted_fallback_is_independent_of_people_found():
    score = score_result({}, {"related_searched": True, "related_people": []})
    assert score["fallback_attempted"] is True and score["related_people"] == 0
    assert score_result({}, {})["fallback_attempted"] is None


def test_failed_case_remains_in_recall_denominator():
    label = {"url": "https://github.com/anna"}
    good = score_result({"expect": [label]}, {"candidates": [label]})
    bad = score_result({"expect": [label]}, {})
    bad["error"] = "provider unavailable"
    summary = summarize([good, bad])
    assert summary["known_recall"] == 0.5 and summary["errors"] == 1


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for test in tests:
        test()
        print("ok", test.__name__)
    print(f"{len(tests)}/{len(tests)} passed")
