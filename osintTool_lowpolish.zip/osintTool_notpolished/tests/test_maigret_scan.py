from types import SimpleNamespace

import pytest

from osintpwd.discovery import maigret_scan as scan


def item(state, html='', url='https://github.com/dana', code=200, error=None):
    return {'status': SimpleNamespace(status=SimpleNamespace(name=state), error=error),
            'response_text': html, 'url_user': url, 'http_status': code}


def test_claimed_handle_needs_profile_evidence_and_is_not_identity_proof():
    raw = {'GitHub': item('CLAIMED', '<title>dana (Dana Kim)</title><p>@dana</p>')}
    result = scan._normalize('dana', raw, {'GitHub': None}, [])
    assert len(result['accounts']) == 1
    assert result['accounts'][0]['provider'] == 'maigret'
    assert 'владелец не подтверждён' in result['accounts'][0]['note']
    assert not result['partial']


@pytest.mark.parametrize('raw', [
    item('CLAIMED', '<title>Just a moment</title>Verify you are human dana'),
    item('CLAIMED', '<title>Sign in · dana</title>'),
    item('CLAIMED', '<title>Generic welcome</title>'),
    item('CLAIMED', '<title>dana</title>', url='https://evil.example/dana'),
    item('CLAIMED', '<title>dana</title>', code=403),
    item('UNKNOWN', '<title>dana</title>'),
    item('AVAILABLE', '<title>dana</title>'),
])
def test_challenges_absence_and_wrong_hosts_never_become_profiles(raw):
    assert not scan._normalize('dana', {'GitHub': raw}, {'GitHub': None}, [])['accounts']


def test_partial_results_survive_timeout_or_missing_site():
    result = scan._normalize('dana', {'GitHub': item('CLAIMED', '<title>dana</title>')},
                             {'GitHub': None, 'Threads': None}, [])
    assert result['partial'] and len(result['accounts']) == 1
    assert result['checks'][1]['status'] == 'unavailable'


def test_public_api_parsed_identity_is_accepted_without_html():
    raw = item('CLAIMED')
    raw['status'].ids_data = {'uid': '123', 'fullname': 'Dana Kim'}
    result = scan._normalize('dana', {'GitHub': raw}, {'GitHub': None}, [])
    assert result['accounts'][0]['title'] == 'Dana Kim'


def test_absent_optional_package_uses_existing_curated_scan(monkeypatch):
    scan._CACHE.clear()
    async def missing(_):
        raise ImportError()
    monkeypatch.setattr(scan, '_scan_async', missing)
    monkeypatch.setattr(scan, 'check_username', lambda h: [{'site': 'github', 'url': f'https://github.com/{h}'}])
    result = scan.scan_username('dana')
    assert result['provider'] == 'curated' and result['accounts']
    assert result['partial']
    assert scan.scan_username('dana')['cached']
