"""Offline regressions for LinkedIn recovery and qualified provider fallback."""

import pytest

from osintpwd.discovery import pipeline
from osintpwd.discovery.candidates import classify
from osintpwd.discovery.models import SearchResult
from osintpwd.discovery.retrieval import SearchRun
from osintpwd.discovery.search import FallbackBackend


NAME = "Aslan Serikov"
QUOTED = f'site:linkedin.com/in "{NAME}"'
RECOVERY = (
    'site:linkedin.com/in "Aslan" "Serikov"',
    f"site:linkedin.com {NAME}",
    f"{NAME} LinkedIn",
)
LINKEDIN_URL = "https://linkedin.com/in/aslan-serikov"
GITHUB_URL = "https://github.com/aslanserikov"
WEAK_URL = "https://linkedin.com/in/member-847"


class Backend:
    def __init__(self, name="fixture", results=None, error=None):
        self.name = name
        self.results = results or {}
        self.error = error
        self.calls = []

    def is_available(self):
        return True

    def search(self, query, max_results=20):
        self.calls.append((query, max_results))
        if self.error:
            raise self.error
        hits = self.results.get(query, []) if isinstance(self.results, dict) else self.results
        return hits[:max_results]


class Client:
    def __init__(self, *args, **kwargs):
        pass

    def close(self):
        pass


def discover_offline(monkeypatch, results, *, platforms=("linkedin", "github"), variants=None):
    monkeypatch.setattr(pipeline, "PoliteClient", Client)
    monkeypatch.setattr(pipeline, "name_variants", lambda name: variants or [name])
    backend = Backend(results=results)
    result = pipeline.discover(
        NAME, backend=backend, platforms=platforms, username_scan=False,
        fetch_pages=0, enrich_profiles=0, related_search="off",
    )
    return result, [query for query, _ in backend.calls]


def github_seed():
    return {f'"{NAME}"': [SearchResult(GITHUB_URL, NAME)]}


def named_linkedin(result):
    return [c for c in result.candidates if c.platform == "linkedin" and c.name_match]


def test_other_platform_name_match_does_not_stop_linkedin_recovery(monkeypatch):
    results = {**github_seed(), RECOVERY[0]: [SearchResult(LINKEDIN_URL, NAME)]}
    result, queries = discover_offline(monkeypatch, results)
    assert any(c.platform == "github" and c.name_match for c in result.candidates)
    assert [c.url for c in named_linkedin(result)] == [LINKEDIN_URL]
    assert RECOVERY[0] in queries
    assert not set(RECOVERY[1:]) & set(queries)


@pytest.mark.parametrize("platform,fragment,url", [
    ("instagram", "site:instagram.com", "https://instagram.com/aslanserikov"),
    ("facebook", "site:facebook.com", "https://facebook.com/aslanserikov"),
    ("vk", "(site:vk.com OR site:vk.ru)", "https://vk.com/aslanserikov"),
])
def test_missing_network_recovers_despite_named_github(monkeypatch, platform, fragment, url):
    query = f"{fragment} {NAME}"
    result, queries = discover_offline(monkeypatch, {
        **github_seed(), query: [SearchResult(url, NAME)],
    }, platforms=(platform, "github"))
    assert any(c.platform == "github" and c.name_match for c in result.candidates)
    assert any(c.platform == platform and c.name_match and c.url == url for c in result.candidates)
    assert queries.count(query) == 1


def test_weak_linkedin_hit_does_not_count_as_platform_coverage(monkeypatch):
    results = {
        **github_seed(), QUOTED: [SearchResult(WEAK_URL, "Aslan")],
        RECOVERY[0]: [SearchResult(LINKEDIN_URL, NAME)],
    }
    result, queries = discover_offline(monkeypatch, results)
    assert RECOVERY[0] in queries
    assert [c.url for c in named_linkedin(result)] == [LINKEDIN_URL]
    assert any(c.url == WEAK_URL and not c.name_match for c in result.candidates)


def test_existing_named_linkedin_hit_avoids_recovery_queries(monkeypatch):
    result, queries = discover_offline(monkeypatch, {
        **github_seed(), QUOTED: [SearchResult(LINKEDIN_URL, NAME)],
    })
    assert named_linkedin(result)
    assert not set(RECOVERY) & set(queries)


@pytest.mark.parametrize("phase", [1, 2], ids=["broad-domain", "plain-keyword"])
def test_recovery_relaxes_query_until_named_profile_found(monkeypatch, phase):
    results = {**github_seed(), RECOVERY[phase]: [SearchResult(LINKEDIN_URL, NAME)]}
    result, queries = discover_offline(monkeypatch, results)
    assert [c.url for c in named_linkedin(result)] == [LINKEDIN_URL]
    assert [q for q in queries if q in RECOVERY] == list(RECOVERY[:phase + 1])


def test_weak_result_in_recovery_phase_does_not_stop_later_phases(monkeypatch):
    result, queries = discover_offline(monkeypatch, {
        **github_seed(), RECOVERY[0]: [SearchResult(WEAK_URL, "Public member")],
        RECOVERY[1]: [SearchResult(LINKEDIN_URL, NAME)],
    })
    assert [c.url for c in named_linkedin(result)] == [LINKEDIN_URL]
    assert [q for q in queries if q in RECOVERY] == list(RECOVERY[:2])


def test_excluded_linkedin_platform_has_no_linkedin_queries(monkeypatch):
    result, queries = discover_offline(monkeypatch, github_seed(), platforms=("github",))
    assert not named_linkedin(result)
    assert not any("linkedin" in query.lower().replace('-site:linkedin.com', '') for query in queries)


def test_recovery_is_bounded_to_three_variants_and_runs_in_phases(monkeypatch):
    variants = [NAME, "Aslan Serikow", "Aslan Serikoff", "Aslan Serykov"]
    _, queries = discover_offline(monkeypatch, github_seed(), variants=variants)
    phases = [
        ['site:linkedin.com/in ' + ' '.join(f'"{part}"' for part in variant.split()) for variant in variants],
        [f"site:linkedin.com {variant}" for variant in variants],
        [f"{variant} LinkedIn" for variant in variants],
    ]
    expected = {query for phase in phases for query in phase[:3]}
    observed = [query for query in queries if query in {q for phase in phases for q in phase}]
    assert len(observed) == 9
    assert set(observed) == expected
    for earlier, later in zip(phases, phases[1:]):
        assert max(queries.index(q) for q in earlier[:3]) < min(queries.index(q) for q in later[:3])


def test_qualified_fallback_preserves_partial_hits_and_finds_named_profile():
    query = RECOVERY[0]
    noise = SearchResult("https://news.example/team", "Public team directory")
    weak = SearchResult(WEAK_URL, "Public member")
    first = Backend("first", [noise, weak])
    second = Backend("second", [SearchResult(LINKEDIN_URL, NAME)])
    unused = Backend("unused", [SearchResult("https://linkedin.com/in/extra", NAME)])
    fallback = FallbackBackend([first, second, unused])
    hits = fallback.search_profiles(query, max_results=2, platform="linkedin", name=NAME)
    assert any(c.name_match for c in classify(NAME, {}, "linkedin", hits))
    assert WEAK_URL in {hit.url for hit in hits}
    assert not unused.calls
    assert all(hit.query == query for hit in hits)
    assert {hit.provider for hit in hits} == {"first", "second"}


@pytest.mark.parametrize("unqualified", [
    SearchResult("https://linkedin.com/company/example", NAME),
    SearchResult(GITHUB_URL, NAME),
    SearchResult(WEAK_URL, "Public member"),
], ids=["company-page", "other-platform", "weak-profile"])
def test_nonempty_unqualified_results_do_not_stop_provider_fallback(unqualified):
    first = Backend("first", [unqualified])
    second = Backend("second", [SearchResult(LINKEDIN_URL, NAME)])
    hits = FallbackBackend([first, second]).search_profiles(
        RECOVERY[0], platform="linkedin", name=NAME,
    )
    assert second.calls
    assert any(c.name_match for c in classify(NAME, {}, "linkedin", hits))


def test_qualified_fallback_keeps_engine_metadata_and_query():
    first = Backend("searxng", [SearchResult(
        WEAK_URL, "Public member", provider="searxng:bing",
    )])
    second = Backend("google", [SearchResult(LINKEDIN_URL, NAME, provider="google:organic")])
    hits = FallbackBackend([first, second]).search_profiles(
        RECOVERY[0], platform="linkedin", name=NAME,
    )
    assert {hit.url: hit.provider for hit in hits} == {
        WEAK_URL: "searxng:bing", LINKEDIN_URL: "google:organic",
    }
    assert all(hit.query == RECOVERY[0] for hit in hits)


def test_provider_error_still_returns_weak_partial_results():
    first = Backend("first", [SearchResult(WEAK_URL, "Public member")])
    failing = Backend("failed", error=RuntimeError("synthetic provider unavailable"))
    fallback = FallbackBackend([first, failing])
    hits = fallback.search_profiles(RECOVERY[0], platform="linkedin", name=NAME)
    assert [hit.url for hit in hits] == [WEAK_URL]
    assert hits[0].provider == "first" and hits[0].query == RECOVERY[0]
    assert failing.calls
    assert any("failed" in error and "RuntimeError" in error for error in fallback.errors)


def test_pipeline_uses_qualified_provider_fallback(monkeypatch):
    monkeypatch.setattr(pipeline, "PoliteClient", Client)
    monkeypatch.setattr(pipeline, "name_variants", lambda name: [name])
    first = Backend("first", [SearchResult(WEAK_URL, "Public member")])
    second = Backend("second", [SearchResult(LINKEDIN_URL, NAME)])
    result = pipeline.discover(
        NAME, backend=FallbackBackend([first, second]), platforms=("linkedin",),
        username_scan=False, fetch_pages=0, enrich_profiles=0, related_search="off",
    )
    assert [c.url for c in named_linkedin(result)] == [LINKEDIN_URL]
    assert second.calls
    assert any(e.get("provider") == "second" for c in named_linkedin(result) for e in c.evidence)


def test_smaller_qualified_cache_request_keeps_named_profile_ahead_of_noise():
    first = Backend("first", [
        SearchResult("https://news.example/team", "Public team directory"),
        SearchResult(WEAK_URL, "Public member"),
    ])
    second = Backend("second", [SearchResult(LINKEDIN_URL, NAME)])
    run = SearchRun(FallbackBackend([first, second]))
    run.search_profiles(RECOVERY[0], max_results=20, platform="linkedin", name=NAME)
    cached = run.search_profiles(RECOVERY[0], max_results=1, platform="linkedin", name=NAME)
    assert any(c.name_match for c in classify(NAME, {}, "linkedin", cached))
    assert len(first.calls) == len(second.calls) == 1


def test_generic_search_still_stops_at_first_nonempty_provider():
    first = Backend("first", [SearchResult(WEAK_URL, "Public member")])
    second = Backend("second", [SearchResult(LINKEDIN_URL, NAME)])
    hits = FallbackBackend([first, second]).search(RECOVERY[0])
    assert [hit.url for hit in hits] == [WEAK_URL]
    assert not second.calls


def test_generic_cache_does_not_satisfy_qualified_search():
    first = Backend("first", [SearchResult(WEAK_URL, "Public member")])
    second = Backend("second", [SearchResult(LINKEDIN_URL, NAME)])
    run = SearchRun(FallbackBackend([first, second]))
    assert [hit.url for hit in run.search(RECOVERY[0])] == [WEAK_URL]
    hits = run.search_profiles(RECOVERY[0], platform="linkedin", name=NAME)
    assert any(c.name_match for c in classify(NAME, {}, "linkedin", hits))
    # The provider's raw response is reusable, while qualification still reaches
    # the second provider rather than reusing the stopped generic chain.
    assert len(first.calls) == 1
    assert len(second.calls) == 1


class QualifiedBackend(Backend):
    def __init__(self):
        super().__init__()
        self.qualified_calls = []

    def search_profiles(self, query, max_results=20, *, platform, name):
        self.qualified_calls.append((query, max_results, platform, name))
        if platform == "github":
            url = GITHUB_URL
        elif name == NAME:
            url = LINKEDIN_URL
        else:
            url = "https://linkedin.com/in/aslan-serikow"
        return [SearchResult(url, name, provider="fixture:qualified")]


@pytest.mark.parametrize("second_platform,second_name", [
    ("linkedin", "Aslan Serikow"), ("github", NAME),
], ids=["target-name", "target-platform"])
def test_qualified_cache_is_isolated_by_target(second_platform, second_name):
    backend = QualifiedBackend()
    run = SearchRun(backend)
    first = run.search_profiles("same query", platform="linkedin", name=NAME)
    second = run.search_profiles("same query", platform=second_platform, name=second_name)
    assert first[0].url != second[0].url
    assert len(backend.qualified_calls) == 2
    assert not backend.calls


def test_qualified_cache_reuses_same_target_and_preserves_provenance():
    backend = QualifiedBackend()
    run = SearchRun(backend)
    run.search_profiles(RECOVERY[0], max_results=20, platform="linkedin", name=NAME)
    cached = run.search_profiles(RECOVERY[0], max_results=10, platform="linkedin", name=NAME)
    assert len(backend.qualified_calls) == 1
    assert cached[0].provider == "fixture:qualified"
    assert cached[0].query == RECOVERY[0]
    cached[0].title = "Caller mutation"
    fresh_copy = run.search_profiles(RECOVERY[0], max_results=10, platform="linkedin", name=NAME)
    assert fresh_copy[0].title == NAME


def test_search_run_supports_generic_only_custom_backends():
    backend = Backend("custom", [SearchResult(LINKEDIN_URL, NAME)])
    hits = SearchRun(backend).search_profiles(RECOVERY[0], platform="linkedin", name=NAME)
    assert [hit.url for hit in hits] == [LINKEDIN_URL]
    assert hits[0].provider == "custom" and hits[0].query == RECOVERY[0]
    assert len(backend.calls) == 1
