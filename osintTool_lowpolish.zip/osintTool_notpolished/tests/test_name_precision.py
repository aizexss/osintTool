"""Synthetic precision/recall cases; no real account ownership is assumed."""

import pytest

from osintpwd.discovery.candidates import classify, is_name_match
from osintpwd.discovery.models import SearchResult
from osintpwd.discovery.translit import name_variants


WRONG_OWNERS = [
    ('Elena Kim', 'Oleg Kim'),
    ('Елена Ким', 'ОЛЕГ КИМ'),
    ('Елена КИМ', 'олег ким'),
    ('Anna Tsoy', 'Oleg Tsoy'),
    ('Анна ЦОй', 'Олег Цой'),
    ('Анна Цой', 'олег цой'),
    ('Aibar Ibragimov', 'Timur Ibragimov'),
    ('Li Wang', 'Liam Wang'),
]
EQUIVALENT_OWNERS = [
    ('Aibar Ibragimov', 'Aybar Ibragimov'),
    ('Aybar Ibragimov', 'Aibar Ibragimov'),
    ('Aibar Ibragimov', 'Айбар Ибрагимов'),
    ('Анна ЦОй', 'Anna Tsoy'),
    ('Елена Ким', 'Elena Kim'),
]


@pytest.mark.parametrize('name,owner', WRONG_OWNERS)
def test_same_surname_with_different_given_name_is_a_flagged_suggestion(name, owner):
    found = classify(name, {}, 'linkedin', [
        SearchResult('https://linkedin.com/in/synthetic-member', owner),
    ])
    assert len(found) == 1 and not found[0].name_match
    assert 'owner_name_conflict' in found[0].match_reasons


@pytest.mark.parametrize('name,owner', EQUIVALENT_OWNERS)
def test_common_script_and_romanization_variants_match_both_names(name, owner):
    found = classify(name, {}, 'linkedin', [
        SearchResult('https://linkedin.com/in/synthetic-member', owner),
    ])
    assert len(found) == 1
    assert found[0].name_match
    assert 'name_in_title' in found[0].match_reasons


@pytest.mark.parametrize('owner', ['Oleg Kim', 'kim oleg', 'Ким Олег'])
def test_matching_handle_cannot_override_different_given_name(owner):
    hit = SearchResult('https://linkedin.com/in/elena-kim', owner, 'Elena Kim in Almaty')
    assert not is_name_match('Elena Kim', hit, 'elena-kim')
    found = classify('Elena Kim', {'city': 'Almaty'}, 'linkedin', [hit])
    assert len(found) == 1 and not found[0].name_match


@pytest.mark.parametrize('owner', ['Elena Kim', 'Kim Elena', 'Elena Sergeevna Kim',
                                    'Kim Elena Sergeevna', 'ЕЛЕНА КИМ'])
def test_matching_full_owner_with_reordered_or_middle_name_stays(owner):
    found = classify('Elena Kim', {}, 'linkedin', [SearchResult('https://linkedin.com/in/member', owner)])
    assert len(found) == 1
    assert found[0].name_match


@pytest.mark.parametrize('owner', ['', 'Kim', 'Elena', 'E. Kim', 'Elena K.', 'Public member'])
def test_incomplete_owner_is_not_a_full_name_match(owner):
    found = classify('Elena Kim', {}, 'linkedin', [SearchResult('https://linkedin.com/in/member', owner)])
    if owner in {'', 'Public member'}:
        assert found == []  # no name, handle or contextual evidence
        return
    assert len(found) == 1
    assert not found[0].name_match


@pytest.mark.parametrize('owner', ['Sergey', 'Ekim', 'Kimura'])
def test_short_name_substrings_do_not_match(owner):
    assert not is_name_match('Elena Kim', SearchResult('u', owner), 'elena-kimura')


def test_romanization_query_variants_are_symmetric_bounded_and_original_first():
    for typed, expected in [('Aibar Ibragimov', 'Aybar Ibragimov'),
                            ('Aybar Ibragimov', 'Aibar Ibragimov'),
                            ('Anna Tsoi', 'Anna Tsoy')]:
        variants = name_variants(typed)
        assert variants[0] == typed
        assert expected in variants
        assert len(variants) <= 4
        assert len({v.casefold() for v in variants}) == len(variants)


@pytest.mark.parametrize('name,handle', [
    ('Aibar Ibragimov', 'aybar-ibragimov'),
    ('Айбар Ибрагимов', 'aibar-ibragimov'),
    ('Анна ЦОй', 'anna_tsoi'),
])
def test_full_handle_aliases_do_not_require_using_query_variant_as_target(name, handle):
    assert is_name_match(name, SearchResult('u', ''), handle)


def test_romanization_does_not_fuzz_short_surname_letters():
    assert not is_name_match('Elena Kim', SearchResult('u', 'Elena Kym'), 'elena-kym')
    assert 'Elena Kym' not in name_variants('Elena Kim')


@pytest.mark.parametrize('title', ['Oleg Kim Engineer', 'Oleg Kim Photography (@elena_kim)',
                                    'Oleg Kim LinkedIn', 'Oleg Kim | Elena Kim collaborator'])
def test_role_or_bio_suffix_does_not_erase_wrong_owner(title):
    found = classify('Elena Kim', {}, 'linkedin', [
        SearchResult('https://linkedin.com/in/elena-kim', title),
    ])
    assert len(found) == 1 and not found[0].name_match
    assert 'owner_name_conflict' in found[0].match_reasons


def test_correct_owner_with_role_suffix_is_not_rejected():
    found = classify('Aslan Serikov', {}, 'linkedin', [
        SearchResult('https://linkedin.com/in/member', 'Aslan Serikov public project'),
    ])
    assert len(found) == 1 and found[0].name_match


def test_surname_alone_does_not_turn_first_name_nickname_into_match():
    found = classify('Elena Kim', {}, 'linkedin', [
        SearchResult('https://linkedin.com/in/member', 'Lena Kim'),
    ])
    assert len(found) == 1 and not found[0].name_match


def test_single_name_search_keeps_existing_partial_search_behavior():
    assert classify('Kim', {}, 'linkedin', [SearchResult('https://linkedin.com/in/member', 'Oleg Kim')])
