"""Critical local guarantees: restart recovery, backoff and page isolation."""
import time
import httpx

from osintpwd.discovery import searxng_engines as engines
from osintpwd.discovery.provider_state import ProviderState, ProviderError
from osintpwd.discovery.retrieval import SearchRun
from osintpwd.discovery.search import SearxngBackend, FallbackBackend
from osintpwd.discovery.models import SearchResult
from osintpwd.web.discovery_jobs import JobStore, QueryJournal


def test_inventory_keeps_empty_web_engine_excludes_images_and_persists_pause(tmp_path, monkeypatch):
    monkeypatch.setenv('OSINT_SEARCH_CACHE_PATH', str(tmp_path / 'cache.db'))
    class Client:
        def get(self, *args, **kwargs):
            return httpx.Response(200, json={'engines': [
                {'name': 'empty web', 'enabled': True, 'categories': ['general', 'web'], 'paging': False},
                {'name': 'web', 'enabled': True, 'categories': ['general', 'web'], 'paging': True},
                {'name': 'images', 'enabled': True, 'categories': ['images', 'web'], 'paging': True}]})
    pool = engines.EnginePool('fixture')
    pool.refresh_inventory(Client(), 'http://local')
    pool.observe({'results': [], 'unresponsive_engines': [['web', 'CAPTCHA']]}, ['empty web', 'web'])
    assert pool.choose() == ['empty web']
    assert pool.choose(page=2) is None
    restored = engines.EnginePool('fixture')
    restored.refresh_inventory(Client(), 'http://local')
    assert restored.choose() == ['empty web']
    assert restored.snapshot()['engines'][1]['retry_after_seconds'] > 3500
    state = ProviderState(scope='provider')
    state.failed(ProviderError('rate_limited', cooldown=180))
    assert ProviderState(scope='provider').snapshot()['retry_after_seconds'] >= 179


def test_paging_has_separate_cache_and_never_uses_nonpaging_engine():
    class Client:
        def __init__(self):
            self.pages = []
        def get(self, url, **kwargs):
            if url.endswith('/config'):
                return httpx.Response(200, json={'engines': [
                    {'name': name, 'enabled': True, 'categories': ['general', 'web'], 'paging': paging}
                    for name, paging in [('web', True), ('first only', False)]]})
            page = kwargs['params'].get('pageno', 1)
            self.pages.append(page)
            if page > 1:
                assert kwargs['params']['engines'] == 'web'
            return httpx.Response(200, json={'results': [{'url': f'https://example.org/{page}', 'engine': 'web'}]})
    client = Client()
    def run():
        return SearchRun(FallbackBackend([SearxngBackend('http://local', client)]), max_queries=4)
    first = run()
    assert first.search('Dana Kim')[0].url.endswith('/1')
    assert first.search_page('Dana Kim', page=2)[0].url.endswith('/2')
    assert run().search_page('Dana Kim', page=2)[0].cached
    assert client.pages == [1, 2]


def test_interrupted_job_resumes_completed_queries_without_refetching(tmp_path):
    requests = []
    class Backend:
        name = 'fixture'
        def search(self, query, max_results=20):
            requests.append(query)
            return [SearchResult('https://example.org/' + query)]
    def runner(payload, journal, progress):
        run = SearchRun(Backend(), max_queries=4, journal=journal)
        hits = run.search('first') + run.search('second')
        progress({'urls': [h.url for h in hits]}, 'public_pages')
        return {'urls': [h.url for h in hits], 'stats': run.stats()}
    path = tmp_path / 'jobs.db'
    old = JobStore(path, runner)
    queued = old.submit({'name': 'Dana Kim'})
    assert old.submit({'name': 'Dana Kim'})['id'] == queued['id']
    job = old.claim()
    SearchRun(Backend(), max_queries=4, journal=QueryJournal(old, job['id'])).search('first')
    # Simulate a killed process with an expired heartbeat.
    with old.connect() as db:
        db.execute('UPDATE jobs SET lease=?', (time.time() - 1,))
    restarted = JobStore(path, runner)
    job = restarted.claim()
    assert job['attempts'] == 2
    assert old.claim() is None  # a different worker owns the resumed job
    restarted.execute(job)
    result = restarted.get(job['id'])
    assert result['status'] == 'completed'
    assert result['result']['stats']['resumed_queries'] == 1
    assert requests == ['first', 'second']


def test_partial_results_are_not_replayed_as_completed_queries(tmp_path):
    store = JobStore(tmp_path / 'jobs.db', None)
    job = store.submit({'name': 'Dana Kim'})
    journal = QueryJournal(store, job['id'])
    key = ('query', 20, '', '', 1)
    journal.save(key, {'status': 'ok', 'sequence': 1}, [SearchResult('https://example.org', partial=True)])
    assert journal.lookup(key) is None
    journal.save(key, {'status': 'unavailable', 'sequence': 2}, [])
    assert journal.lookup(key) is None
    journal.save(key, {'status': 'empty', 'partial_query': True, 'sequence': 3}, [])
    assert journal.lookup(key) is None


def test_job_api_enforces_keyless_mode_and_returns_durable_result(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from osintpwd.web import discovery_jobs
    from osintpwd.web.app import app
    store = JobStore(tmp_path / 'jobs.db', lambda payload, journal, progress: {'mode': payload['search_mode']})
    monkeypatch.setattr(discovery_jobs, '_store', store)
    monkeypatch.setattr(store, 'start', lambda: None)
    client = TestClient(app)
    response = client.post('/api/discovery-jobs', json={'name': 'Dana Kim', 'search_mode': 'auto'})
    assert response.status_code == 202
    job_id = response.json()['id']
    store.execute(store.claim())
    saved = client.get('/api/discovery-jobs/' + job_id).json()
    assert saved['status'] == 'completed'
    assert saved['result']['mode'] == 'keyless'
    assert saved['result']['stats']['analysis_attempts'] == 1
    assert client.get('/api/discovery-jobs/missing').status_code == 404
