"""Public discovery separates owner-name matches from incomplete retrieval hits."""
from unittest.mock import patch

from fastapi.testclient import TestClient

from osintpwd.discovery.models import Candidate, DiscoveryResult
from osintpwd.web.app import _discovery_response, app


def test_discovery_response_separates_weak_matches_without_discarding_evidence():
    evidence = [{'kind': 'search', 'source_url': 'https://example.org/reference',
                 'excerpt': 'Aibar mentioned this profile', 'provider': 'fixture'}]
    strong = Candidate(platform='linkedin', url='https://linkedin.com/in/aibar-ibragimov',
                       name_match=True, confirmed=False)
    weak = Candidate(platform='instagram', url='https://instagram.com/aibar',
                     score=.99, name_match=False, evidence=evidence)
    confirmed = Candidate(platform='github', url='https://github.com/selected', confirmed=True)
    associate = Candidate(platform='linkedin', url='https://linkedin.com/in/associate',
                          relation='related_person', related_person='Dana Kim')
    result = DiscoveryResult(
        query_name='Aibar Ibragimov', candidates=[weak, strong, confirmed],
        related_accounts=[associate], excluded_profile_urls=['https://instagram.com/other'],
        stats={'candidate_count': 99, 'search_queries': 7}, errors=['fixture unavailable'])

    response = _discovery_response(result)

    assert [c['url'] for c in response['candidates']] == [strong.url, confirmed.url]
    assert response['candidates'][0]['confirmed'] is False
    assert response['uncertain_candidates'][0]['evidence'] == evidence
    assert response['uncertain_candidates'][0]['confirmed'] is False
    assert response['related_accounts'][0]['url'] == associate.url
    assert response['excluded_profile_urls'] == result.excluded_profile_urls
    assert response['notes'] == result.errors
    assert response['stats']['candidate_count'] == 2
    assert response['stats']['uncertain_count'] == 1
    assert response['stats']['retrieved_candidate_count'] == 3
    assert response['stats']['linkedin_candidates'] == 1
    assert response['stats']['linkedin_name_matches'] == 1
    assert response['stats']['search_queries'] == 7
    assert result.stats['candidate_count'] == 99  # serialization does not mutate the run


def test_weak_linkedin_hit_is_not_reported_as_an_owner_name_match():
    result = DiscoveryResult(query_name='Aibar Ibragimov', candidates=[Candidate(
        platform='linkedin', url='https://linkedin.com/in/aibar', title='Aibar')])
    with patch('osintpwd.discovery.discover', return_value=result) as discover:
        response = TestClient(app).post('/api/discover', json={'name': 'Aibar Ibragimov'})
    assert response.status_code == 200
    data = response.json()
    assert data['candidates'] == []
    assert len(data['uncertain_candidates']) == 1
    assert data['stats']['linkedin_name_matches'] == 0
    assert data['stats']['retrieved_candidate_count'] == 1
    discover.assert_called_once_with('Aibar Ibragimov', {}, username_scan=True,
                                    username_provider='maigret', enrich_profiles=4,
                                    query_budget=24, search_mode='keyless')


def test_related_continuation_uses_the_same_precision_split():
    result = DiscoveryResult(query_name='Dana Kim', candidates=[Candidate(
        platform='instagram', url='https://instagram.com/dana', name_match=False)],
        related_accounts=[Candidate(platform='github', url='https://github.com/associate',
                                    relation='related_person')])
    with patch('osintpwd.discovery.pipeline.discover_related', return_value=result):
        response = TestClient(app).post('/api/discover/related', json={'name': 'Dana Kim'})
    data = response.json()
    assert data['candidates'] == []
    assert len(data['uncertain_candidates']) == 1
    assert len(data['related_accounts']) == 1
