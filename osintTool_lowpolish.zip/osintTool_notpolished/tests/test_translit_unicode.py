"""Unicode source titles must not crash the complete search pipeline."""
from osintpwd.discovery.candidates import classify
from osintpwd.discovery.models import SearchResult
from osintpwd.discovery.translit import to_cyrillic


def test_length_expanding_lowercase_keeps_original_character_offsets():
    assert to_cyrillic('Deniz İ') == 'Дениз İ'
    assert to_cyrillic('İbrahim Smith') == 'İбрахим Смитх'


def test_unicode_title_does_not_discard_other_linkedin_results():
    results = classify('Zhumali Muhammed', {}, 'linkedin', [
        SearchResult('https://linkedin.com/in/unrelated-fixture', 'Deniz İ'),
        SearchResult('https://linkedin.com/in/target-fixture', 'Zhumali Muhammed'),
    ])
    assert any(c.url.endswith('/target-fixture') and c.name_match for c in results)
