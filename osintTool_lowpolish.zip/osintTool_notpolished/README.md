# osintTool — personalized password auditing (defensive)

A corporate password-hygiene tool. It builds a **per-person** password
wordlist from OSINT-derived information and judges whether a proposed
password is guessable from that same information — so an employee can't set
`khabibNurmagomedov777` when their public profile is all about Khabib.

Two ways it plugs in:

| Mode | When | How |
|------|------|-----|
| **Proactive** | at password-change time | AD password filter / self-service portal calls `evaluate_password()` and rejects weak choices |
| **Reactive** | scheduled audit | `generate_wordlist()` → hashcat/john against NT hashes dumped from the domain → report weak users |

> Passwords are never readable from AD (only NTLM hashes). Reactive =
> hash cracking; proactive = intercept the plaintext at the moment of change.

## Architecture

```
discovery/   ONLINE   find public profiles + pull public data
ml/          LOCAL    NER on text, optional image analysis, EXIF
osintpwd/    LOCAL    the offline password engine                    (done)
  models.py       Profile + Config
  transforms.py   leet / de-leet, affixes, case, combinations
  generator.py    Profile -> wordlist        (reactive)
  evaluator.py    password + Profile -> Verdict (proactive)
```

All ML inference runs **locally** (employee photos never leave the machine);
only the collection layer touches the network.

## Usage (offline engine)

```bash
# self-contained demonstration
python -m osintpwd demo

# generate a wordlist for hashcat/john
python -m osintpwd wordlist examples/profile.example.json -o words.txt

# check a single password (exit code 1 = rejected)
python -m osintpwd check examples/profile.example.json "khabibNurmagomedov777"
```

A profile is a JSON file; keys match the `Profile` dataclass in
`osintpwd/models.py`. See `examples/profile.example.json`.

## Tests

```bash
python tests/test_core.py        # or: python -m pytest tests/ -q
```

## Discovery (online)

```powershell
python -m osintpwd discover "Aslan Serikov" --city Almaty --employer AcmeBank
python -m osintpwd web
```

Open the dashboard at http://localhost:7020. Search proposes unconfirmed
accounts; select the appropriate profiles before analysing them.

### Direct search and evidence

The classifier recognises 18 platforms: LinkedIn, Instagram, Facebook, VK, X,
GitHub, Telegram, TikTok, YouTube, Threads (.com and .net), Steam, Reddit,
Bluesky, Twitch, GitLab, Medium, SoundCloud and OK. The same registry handles
public profile links extracted from pages. Steam `/id/` and `/profiles/` remain
distinct; posts, groups, repositories and video URLs are not profiles.
Name variants are searched in Latin/Cyrillic;
city/employer/school hints add queries without removing the broad name search.
There are dedicated queries for the four primary networks, general web queries,
small combined queries for the other networks, and targeted queries for uncovered
networks. Weak profile candidates remain visible. A name mentioned in someone
else's snippet is a weak lead, not an owner-name match.
An explicitly different owner no longer deletes an otherwise relevant suggestion:
it receives `owner_name_conflict`, a low rank, and cannot stop the related-person
fallback or seed automatic username expansion. Duplicate hits preserve this flag.
Root/login/navigation URLs and profiles with no observed matching evidence are
still discarded; appearing in a search response alone is not a match.

Missing primary networks each get an unquoted recovery query even if another
network already matched. LinkedIn additionally tries a broader domain query
and a plain name + LinkedIn query, stopping at the first named profile (at most
three spelling variants per wave). Legacy `/pub/` and regional LinkedIn URLs
retain their observed account identifiers. No profile URL is invented from a name.
When no LinkedIn name match is retrieved, the dashboard says so and links to
LinkedIn's own people search; absence from a public index is not absence of an account.

Duplicate accounts merge their excerpts, query/provider provenance and matched
hints. Scores are heuristic ranks, not probabilities. Same-username groups are
explicitly hypotheses; punctuation-distinct usernames and contradictory owner
names are kept separate. JSON export contains the suggestions, evidence,
related-person chains, source excerpts and run statistics.

After the first search wave, up to two adaptive queries use an actually found
name-matching profile: its observed username together with name components,
and its exact profile address to seek backlinks. These replace long-tail retries
within the shared query budget; partial names and username-only suggestions do
not seed this step. Backlink leads get priority for bounded page reads, but a
query match alone never admits a source: the page must name the target or carry
an explicit non-navigation link to a named profile.
When an engine ignores exact-query terms, a pivot hit needs the observed handle
in its returned title, snippet or URL even to receive a speculative body read.
With a larger budget, optional follow-up queries use further observed accounts
and stop after two consecutive queries add no account or named source. This
plateau rule applies only to optional pivots, not initial coverage or co-mentions.

The dashboard's **Что дали поисковые запросы** and JSON `stats.query_yield`
report retained accounts/publications, new findings, repeated URLs, provider
failures, cache use and elapsed time per query. Counts require retained source
evidence and deduplicate known profile aliases. They measure retrieval yield,
not identity precision/recall; direct username checks are counted separately.

Sources are retained from every search pass, including public posts. The dashboard reads up to four
source pages and four profile pages, with at most three
parallel page reads. The source list favours accessible non-social pages and
varied hosts. Main HTML text plus metadata is extracted using Trafilatura with
a BeautifulSoup fallback. Text PDFs use pypdf (up to five pages); scanned PDFs
are not OCRed. The public reader streams at most 2 MiB and retains at most
24,000 text characters per document. It checks public HTTP(S) destinations and
redirects before requests; DNS preflight is not a network sandbox.

### Search through co-mentioned people

Automatic continuation runs when no owner-name candidate has been found;
weak suggestions do not stop it. This continuation is part of the single
dashboard analysis, without a separate button. The legacy related-search API
remains available for programmatic callers.

1. Extract up to two other names from short contexts containing the target's
   name or a spelling variant. spaCy is optional; multilingual rules supplement it.
2. Search their profiles and joint-name queries in rounds, giving each person
   a general and joint-name search before deeper per-network retries.
3. Read up to two associate profiles in total. Follow only one hop through
   name-attached account links or platform-scoped mentions. Partial matching
   anchors, handles or local contexts remain weak proposals with source evidence.
4. Preserve the original co-mention, intermediate account and final link as
   evidence. Keep associate accounts separate from target-account proposals.

Co-mention does not establish friendship or ownership. Publisher/footer links
are not treated as the target's accounts. Search and reader failures remain
visible with the partial results. A failed fallback and a successful fallback
with no people/accounts are distinguishable via flags, errors and counts.
`related_queries` counts actual logical queries, `related_query_reuses` counts
reused queries, and `related_queries_skipped` records budget skips. The UI uses
`related_search_status` to distinguish incomplete work from a completed search.

`POST /api/discover` accepts name plus optional city/country/employer/job_title/
school. `POST /api/discover/related` accepts those fields and prior `web_info`.
Both use the same discovery code as the Python API. Responses include
`candidates`, `related_accounts`, `related_people`, `related_searched`,
`related_evidence`, `web_info`, `stats` and `notes`. Candidate records include
`evidence`, `match_reasons`, `relation`, `fetch_status` and `fetch_error`.

### Backends and bounded expansion

The dashboard defaults to **keyless search**: configured local SearXNG, then
DuckDuckGo. Queries go from your server to public search engines; no Serper or
Google API key is used in this mode. SearXNG is a metasearch service, not a local
copy of the web index, and upstream CAPTCHA/rate limits still apply. Its deployment
now enables Yahoo as an additional keyless engine. No challenge bypass is used.

The dashboard has one **Начать анализ** action and always uses the keyless
pipeline by default. It automatically searches names, reads bounded public
pages, expands up to two matching handles using Maigret, and searches through
co-mentions when no owner-name candidates remain. There are no source-mode,
platform-mode, separate expansion or secondary analysis controls in the UI.
Selection after analysis only applies already-retrieved handle/keyword data to
the editable profile locally; it performs no additional profile-reading request.
Accounts remain unconfirmed until reviewed; nothing is selected automatically.
All account suggestions appear in one list, with owner-name matches first and
other matches ordered by rank. Each card retains its match basis and evidence.
The counter and Select All cover the entire list. API/export evidence classes
remain separate for compatibility; merging the display does not confirm ownership.

The dashboard query ceiling is now **48** (previously hardcoded to 24). Set
`OSINT_QUERY_BUDGET=96` in the server environment or `.env`, then restart the
server, to raise it. Supported range: 12–200; invalid text uses 48. This is a
maximum, not a target or a promise of that many network requests. One quarter
of the budget, capped at 12, is held for co-mention discovery until profile
reading and username checks finish, including late owner contradictions.
Unused reserve need not be spent when a named account was found. Existing
cache, pacing, provider cooldowns and two-worker concurrency remain active.
A separate reserve of up to six queries (one eighth of the ceiling) is released
for publication recovery before public-page reading; account retries cannot
consume it. The co-mention reserve remains protected during this recovery.
Useful queries can fetch pages 2–3, with at most six additional page requests
inside the same budget. Only engines declaring pagination support are used.
The next page is skipped when the previous one adds no retained account or
target-related material. Raising the ceiling does not remove upstream restrictions.

Programmatic callers may explicitly request `search_mode="auto"` to retain the
legacy Serper / Google CSE / SearXNG / DuckDuckGo chain. CLI callers that omit a
mode retain `OSINT_SEARCH_MODE` (default `auto`). Configure keys/URLs with `SERPER_API_KEY`, `GOOGLE_CSE_KEY`,
`GOOGLE_CSE_CX`, `SEARXNG_URL`. General web queries stop at the first nonempty
provider. Platform-specific queries continue past directories and unrelated
owners until a name-matching profile is retrieved or configured providers are
exhausted. Partial hits retain query/provider evidence. Query counts and provider
attempt counts are reported separately. This implementation does not use RRF.
Repeated equivalent queries within a run reuse their results;
generic and profile-qualified lookups have separate caches. HTTP pacing and at most
two simultaneous requests per provider are shared across UI runs. Account failures,
HTTP throttling and outages trigger a shared, persisted cooldown (with
Retry-After support for API/SearXNG responses). Successful responses are reusable
for 10 minutes. On a provider error only, successful responses up to one hour old
may be shown with original retrieval time, cache age and a stale flag. Healthy
empty refreshes invalidate the old answer; errors and empty replies are not cached.
Successful search responses are also saved in `.cache/search.sqlite3` (SQLite,
maximum 512 entries, one-hour retention). This cache survives server restarts;
original source/time and partial-response flags are retained. Set
`OSINT_SEARCH_CACHE_PATH` to choose another path, or `off` to disable disk caching.
Deleting this cache file clears saved search snippets; it contains public query
results, not API keys. Failed disk access falls back to process memory. Engine
and provider backoff deadlines are stored in a separate health table in this
database. `off` also disables health persistence. Request pacing and username
scan caches remain process-local.

SearXNG's actual enabled web-engine inventory is read from `/config` and refreshed
every ten minutes. This includes healthy engines whose last query returned no
results; image/video/translation adapters are excluded. At most three ready
engines are selected, combining successful sources with a less-used source.
Failed engines receive increasing pauses; deadlines survive app restarts. When
all eligible engines are cooling, no search is sent to instance defaults.
`OSINT_SEARXNG_ENGINES` explicitly overrides adaptive selection and is intended
for manual diagnostics. Selection and per-engine state are visible in the UI/API.

The single dashboard action creates a local job (`POST /api/discovery-jobs`).
The UI polls `GET /api/discovery-jobs/{id}` and shows saved partial findings.
Refreshing the tab restores the analysis. After a killed/restarted server, a
job is reclaimed once its 20-second worker lease expires and replays the query
plan using completed query checkpoints. Failed, stale or partial responses are
not recorded as completed query checkpoints; public-page reads and username
checks may run again. At most three process-interruption attempts are made.
A normal run with unavailable sources finishes as partial; it does not run
forever waiting for external CAPTCHA recovery. A subsequent analysis reuses the
response cache and respects current pauses.

Jobs run one at a time, with at most three queued/running jobs. Identical active
requests reuse the same job. Input, evidence, partial/final output and query
checkpoints live in `.cache/discovery-jobs.sqlite3`; completed/failed jobs are
pruned on submission after seven days or beyond the latest 30. Override the path
with `OSINT_DISCOVERY_JOBS_PATH`. No extra queue service, new API key or paid
dependency is required. Jobs always use keyless mode. The synchronous
`POST /api/discover` remains available for existing integrations. Query counts
refer to the resumed plan; provider-request counts refer to its latest process
attempt. The UI's elapsed job time includes queueing and interruptions.

The UI/API expose degraded search, provider status and retry delay, separately
from actual empty answers. The API accepts `search_mode: "keyless" | "auto"`
and an optional `platforms` list for existing programmatic integrations.
The direct web search uses the configured query ceiling and manual related search has a
12-query ceiling. The broader Python API retains its optional `query_budget`.
Provider quotas and public indexes
change, so more requests do not guarantee more correct accounts.

Ranking favours owner-title and supplied context matches. A full name in the
handle adds little weight; self-described verification/follower counts add none.
General name-query retrieval is a small, explained ranking signal, never identity
proof. Search hits require at least partial name, handle or supplied-hint evidence;
a profile URL returned for the query alone is discarded. Explicit source-page
links and checked username pivots keep their own evidence path. Fan/parody labels
remain visible as caveats on cards in the unified list. Publication discovery
runs independently of account success: six initial queries use separate quoted
name terms, another script, simple VK wall scopes, PDF documents and open-web/context
search. Up to six recovery queries change name order and use simpler/broader
VK and web scopes when material coverage is thin. All share the configured
query ceiling. A nonempty response of unrelated pages no longer stops the
provider chain for these publication searches; names must match on an eligible
document. Weaker document leads can still be read, but are not displayed without
body-name or explicit-profile-link evidence. Generic and publication-qualified
queries have separate run caches and share raw provider responses.

Dashboard jobs read up to six source pages. When snippets provide few named
materials, the otherwise unused reading slots inspect document bodies, instead
of stopping after two probes. Probes prefer visible name/handle evidence and
use at most two pages per host; VK topic category pages are navigation, not
discussions. Library and synchronous endpoint defaults remain four source reads.
VK overlay URLs retain the post and reply ID; public document reading includes
comments and tables. A query or URL alone never admits a result: the card requires
a full-name context or a non-navigation link to a named candidate profile.
The UI exposes the source query/excerpt under “Как найдено”; unavailable pages
retain only the search evidence. Publication diagnostics separately show query,
VK-result and page-reading counts, unavailable requests and rejected read sources.
An empty panel distinguishes ongoing work from an incomplete or completed search.
This is a reviewable connection, not proof of
identity or authorship. Related-person accounts still stay in the related section.
See [the September 29 work plan and verification](docs/search-improvements-2026-09-29.md).

`OSINT_BACKEND_ORDER` overrides the order. Optional Playwright/Bing search is
available through that setting; it is not a default provider or a page-rendering
stage. No Selenium dependency is needed. `OSINT_SEARXNG_ENGINES` configures the
engines requested from the configured SearXNG instance.

Username expansion uses up to two strong-name candidates by default and keeps
cross-network username matches weak and unconfirmed. The dashboard uses Maigret
0.6.6 on a bounded allowlist of actual public profile sites, with four connections,
five seconds per site and a 25-second deadline per handle. No recursive scan,
login, guest-token activation, CAPTCHA solving or paid provider is enabled.
Positive account data must accompany a claimed profile; login/challenge shells,
unknown answers and pages without account evidence are not accepted. A stated
contradictory owner removes the profile even if it appeared in search results.
The installed database currently supplies 16 eligible sites; third-party tracker
entries are excluded. If Maigret is absent, the existing curated username scan
remains available and the result is marked incomplete. Repeated scans reuse a
short process cache; failed sites receive a cooldown. A matching username does
not prove a shared owner. Python callers can set `username_scan=False`, `fetch_pages=0`,
`enrich_profiles=0`, or `related_search="off"`; `related_search="always"` forces
the co-mention path. These controls are independent of ranking.

### Quality evaluation

```powershell
.venv\Scripts\python.exe -m pytest tests/test_discovery.py tests/test_discovery_classification.py tests/test_discovery_related.py tests/test_discovery_evaluate.py tests/test_discovery_pipeline.py tests/test_discovery_api.py tests/test_public_reader.py -q
.venv\Scripts\python.exe tests/discovery_benchmark.py --output after.json
.venv\Scripts\python.exe -m osintpwd.discovery.evaluate examples/discovery_eval.json --output live-quality.json
```

The fixed benchmark is synthetic and network-free. Live identity labels use
platform plus canonical URL, never a bare handle. Unknown candidates remain
unjudged, and precision is reported alongside label coverage. See
[the before/after report](docs/discovery-quality-report.md) and
[current design and limits](docs/discovery-research.md). The latest unified
keyless analysis, live checks and restart test are recorded in
[the September 29 report](docs/keyless-unified-analysis-2026-09-29.md).

## Local ML enrichment

```bash
# offline: enrich a profile from harvested text and/or a photo folder
python -m osintpwd enrich profile.json --text-file posts.txt --images ./photos
```

Runs entirely on this machine (no cloud). Layers, each optional & lazy:

| Signal | Backend | Install | Status |
|--------|---------|---------|--------|
| EXIF / GPS / date | Pillow | (installed) | on |
| Interest gazetteer | built-in | — | on (Latin seed) |
| NER (rules) | built-in | — | on |
| NER (PERSON/LOC/ORG) | spaCy `xx_ent_wiki_sm` | `spacy` + model | on (multilingual) |
| Object tags | YOLOv8 | `ultralytics` | optional (GPU) |

`python -m osintpwd discover ... --enrich` pipes harvested text straight
through this layer into the draft profile.

### Identity confirmation via nomad face_recog (loose coupling)

Reuses the existing `nomad_mvp/modules/image-analyzer/face_recog` stack
(InsightFace + ArcFace + HDBSCAN) **without importing its heavy deps** — we
only read its `output/` folder. Purpose: confirm several discovered profiles
belong to the *same* person, fixing name-only ambiguity.

```bash
# 1. download each candidate's public profile photo
python -m osintpwd discover "Aslan Serikov" --city Almaty --photos-out ./photos

# 2. run the nomad face_recog pipeline on ./photos (its own Docker/env)
#    -> produces output/clusters/person_XXXX/

# 3. confirm they cluster as one identity
python -m osintpwd confirm ./face_recog/output --photos ./photos
#    same person across profiles: YES  (instagram_asik -> person_0000, ...)
```

> The sibling `object_part` module is threat/NSFW/violence detection — not
> relevant to password profiling, so it is intentionally not integrated.

## Status

- [x] Offline engine: wordlist + password evaluation (6/6 tests)
- [x] Online discovery: multi-backend search + classify + enrich
- [x] Article/PDF/DOCX text, source links and bounded co-mention fallback
- [x] Confidence ranking: results ordered top→bottom by corroboration (no filtering)
- [x] Name-only web search, source reading and evidence-backed account suggestions
- [x] Username pivoting: additional public profile suggestions, with ownership left unconfirmed
- [x] Cyrillic→Latin transliteration (RU/KZ names searched in both scripts)
- [x] Bounded automatic Maigret username expansion in the unified analysis
- [x] Local ML enrichment: EXIF, gazetteer, rule+spaCy NER (7/7 tests)
- [x] Identity confirmation via nomad face_recog output reader (4/4 tests)
- [x] Web dashboard (FastAPI): unified account analysis → select relevant data → live check → wordlist
- [x] SearXNG discovery backend (Docker, free, no key)
- [ ] Active Directory integration (password filter / hash audit)
- [ ] Reporting (JSON / HTML)

## Web dashboard

```bash
.venv\Scripts\Activate.ps1             # activate the venv first (Windows PowerShell)
# source .venv/bin/activate            #   ... or on macOS/Linux
cd deploy && docker compose up -d      # start SearXNG (free search backend)
cd ..
python -m osintpwd web                  # http://localhost:7020 (auto-attaches SearXNG)
```

> The dashboard on `:7020` is served by this `python -m osintpwd web` process, **not**
> by Docker — Docker only runs SearXNG on `:8080`. Activate the venv and keep the
> `web` command running; then open http://localhost:7020 (not `:8080`).

Flow: enter a name and surname, optionally city/employer/school → **Начать
анализ** → inspect the unified account list, source pages and
related people. All retrieval stages run automatically. Tick appropriate accounts
to use their already-read data in the editable profile. The web command detects
local SearXNG on port 8080; the application itself runs on port 7020.

### Legacy Instagram session support

Anonymous Instagram is blocked, so post/bio reading needs a logged-in session.
Use a **throwaway/burner** IG account (never a personal one — IG may ban it):

```powershell
python -m osintpwd ig-login <burner_username>   # password entered locally, not stored
$env:IG_USERNAME = "<burner_username>"
python -m osintpwd web
```

The password is read via getpass and never logged; only the session token is
saved (under %APPDATA%\osintpwd\ig_sessions or `IG_SESSION_DIR`). This session
is used by the compatibility `/api/analyze` endpoint. The dashboard's unified
analysis reads anonymous public pages and does not use this session or fetch
private posts. Login walls and inaccessible pages remain marked unavailable.

## Scope

The discovery component implements public-account suggestions and a bounded
co-mention fallback. See the current discovery section and quality report above;
old quick/balanced/deep, RRF, browser-page rendering and rejection-state controls
are not part of the current interface.

Defensive use only: auditing your own organisation's password hygiene with
authorization. Not for compromising third-party accounts.
